import collections,json,re,statistics
from pathlib import Path
ROOT=Path('/tmp/morphiq-american-residual-evidence')
assert json.loads((ROOT/'complete.json').read_text())['complete']
summary={}
for case in ('flat','cash','bermudan','piecewise','piecewise-cash','greeks','iv','hard'):
 counts=collections.Counter();leaves=collections.Counter();sites=collections.Counter();bytes_=[];processes=[]
 for i in range(3):
  name=f'profile-{i}-{case}';data=json.loads((ROOT/(name+'.json')).read_text());bytes_.append(data['allocated_bytes_per_call']);sample_counts=collections.Counter()
  for part in (ROOT/(name+'.log')).read_text().split('SAMPLES ')[1:]:
   n,stack=part.split('\n',1);n=int(n);leaf=stack.splitlines()[0];leaves[leaf]+=n
   early=[line for line in stack.splitlines() if 'Morphiq_risk__Early_exercise.' in line]
   sites[early[0] if early else leaf]+=n
   if '.interpolate ' in stack:owner='cash interpolation'
   elif '.prepare ' in stack:owner='spatial preparation'
   elif '.slab_constant ' in stack:owner='time slabs and boundaries'
   elif '.grid ' in stack:owner='grids'
   else:owner='other'
   counts[owner]+=n;sample_counts[owner]+=n
  processes.append(dict(round=i,samples=dict(sample_counts),total=sum(sample_counts.values())))
 total=sum(counts.values())
 summary[case]=dict(allocated_bytes_per_call=bytes_,median_allocated_bytes=statistics.median(bytes_),samples=total,owners={k:dict(samples=v,percent=100*v/total) for k,v in counts.most_common()},processes=processes,leaves=dict(leaves.most_common()),first_early_exercise_frames=dict(sites.most_common()))
 print(case,round(statistics.median(bytes_)/1e6,3),'MB',total,'samples',', '.join(f'{k} {100*v/total:.1f}%' for k,v in counts.most_common()))
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
