import json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/tmp/morphiq-american-residual-allocation')
OUT=Path('/tmp/morphiq-american-residual-evidence')
sys.path.insert(0,str(ROOT/'scripts'))
from measure_american_workloads import child,require_child,source_snapshot,sha,atomic_json
cases=('flat','cash','bermudan','piecewise','piecewise-cash','greeks','iv','hard')
source=source_snapshot(ROOT)
binaries={mode:ROOT/'_build/default/bench'/('american_remaining_allocation.'+suffix) for mode,suffix in [('native','exe'),('bytecode','bc.exe')]}
hashes={str(p):sha(p) for p in binaries.values()}
atomic_json(OUT/'manifest.json',dict(source=source,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),binaries=hashes,compiler=subprocess.check_output(['opam','exec','--switch=morphiq-risk-ml','--','ocamlopt','-config'],text=True)))
expected={}
prior=json.loads(Path('/tmp/morphiq-american-backends-evidence/qualification/qualification.json').read_text())['outcomes']
def run(name,case,mode,calls):
 assert source_snapshot(ROOT)==source and all(sha(Path(p))==h for p,h in hashes.items()),'source/binary drift'
 record=child(['env','-u','MORPHIQ_CAPTURE_CELLS',str(binaries[mode]),'--case',case,'--calls',str(calls)],OUT/(name+'.log'),OUT/(name+'.stderr'),180)
 atomic_json(OUT/(name+'.json'),record);require_child(record)
 text=(OUT/(name+'.log')).read_text();lines=text.splitlines();base=lines[0].split('\t')
 assert len(base)==5 and base[:3]==['BASELINE',case,str(calls)] and lines[-1]==f'COMPLETE\t{case}\t{calls}','incomplete profile'
 digest=base[3]
 if case in expected:assert expected[case]==digest,'request replay changed'
 else:expected[case]=digest
 previous=prior.get('outcomes-native-'+case+'-1')
 if previous:assert digest==previous['rows']['0']['digest'],'differs from #147'
 record.update(case=case,mode=mode,calls=calls,digest=digest,allocated_bytes_per_call=float(base[4]))
 atomic_json(OUT/(name+'.json'),record)
 print(name,'complete',record['allocated_bytes_per_call'],flush=True)
for case in cases:
 for mode in binaries:run('qualification-'+case+'-'+mode,case,mode,1)
for i in range(3):
 for case in (reversed(cases) if i%2 else cases):run(f'profile-{i}-{case}',case,'native',20)
assert source_snapshot(ROOT)==source and all(sha(Path(p))==h for p,h in hashes.items())
atomic_json(OUT/'complete.json',dict(complete=True,profile_processes=24,qualification_processes=16,source_unchanged=True))
