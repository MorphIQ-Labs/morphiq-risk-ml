import hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
R=Path('/tmp/morphiq-american-residual-allocation')
E=Path('/tmp/morphiq-american-residual-evidence')
D=R/'docs/evidence/american-remaining-allocation/exponential'
C=E/'exponential-campaign'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R)
summary=json.loads((C/'summary.json').read_text())
complete=json.loads((C/'complete.json').read_text())
assert complete['complete'] and complete['processes']==140 and complete['criteria_pass']
measured=json.loads((C/'manifest.json').read_text())
qualified=json.loads((E/'qualification/manifest.json').read_text())
assert json.loads((E/'qualification/complete.json').read_text())['complete']
head=git('rev-parse','HEAD').decode().strip()
assert head==measured['commits']['candidate']
assert not git('status','--porcelain')
for name,h in measured['sources']['candidate'].items():
 if name.startswith(('lib/','test/','oracle/')):
  assert h==qualified['candidate']['source'][name],name
for name,h in measured['sources']['baseline'].items():
 if name.startswith(('lib/','test/','oracle/')):
  assert h==qualified['baseline']['source'][name],name
D.mkdir(parents=True,exist_ok=False)
shutil.copyfile(C/'summary.json',D/'summary.json')
paths=list(C.rglob('*'))
paths.extend(p for p in (E/'qualification').rglob('*') if not any(x.endswith('-bin') for x in p.relative_to(E).parts))
# Preserve initial catalog-count failures alongside corrected successful checks.
for pattern in ('baseline-*.log','candidate-*.log','development*.log','release*.log','mutations*.log','final-*.log','exponential-format.log','format-mutant.log','qualification.log','exponential-campaign.log'):
 paths.extend(E.glob(pattern))
paths.extend(E/n for n in ('candidate-profile.json','qualify.py','publish_exponential.py'))
paths=sorted({p for p in paths if p.is_file()})
changed=git('diff','--name-only',measured['commits']['baseline'],head).decode().splitlines()
changed+=['test/enclosure_exponential.ml','docs/evidence/american-remaining-allocation/exponential-protocol.md','bench/american_remaining_allocation.ml']
files={};payloads={}
for p in paths:
 name=str(p.relative_to(E))
 assert not p.name.endswith(('.exe','.a','.o','.pdf')),name
 payloads[name]=p.read_bytes()
for name in changed:
 payloads['source/'+name]=git('show',head+':'+name)
payloads['source/runtime.patch']=git('diff',measured['commits']['baseline'],head,'--','lib')
with tarfile.open(D/'raw.tar.gz','w:gz') as archive:
 for name,data in sorted(payloads.items()):
  assert not name.startswith('/') and '..' not in Path(name).parts
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data))
  files[name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
manifest=dict(baseline_commit=measured['commits']['baseline'],source_commit=head,
 qualification_candidate_commit=qualified['candidate']['commit'],
 qualification_runtime_test_oracle_sources_match=True,
 archive_sha256=sha(D/'raw.tar.gz'),files=files)
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(D/'raw.tar.gz') as archive:
 assert set(archive.getnames())==set(files)
 for member in archive:
  assert member.isfile()
  data=archive.extractfile(member).read()
  assert hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print('verified',len(files),'members; archive bytes',(D/'raw.tar.gz').stat().st_size)
