# Same-binary diagnostic limitation

Both complete A/B campaigns began after task-owned builds, ordinary tests,
reference campaigns, targeted mutations and profiling had finished. During the
separate twelve-process same-binary diagnostic, one lightweight Python pooling
control run overlapped collection (tool-reported wall duration approximately
0.11 seconds). The confirmatory A/B campaign started after that control finished.
This is a deviation from the diagnostic's no-owned-compute condition. Retain all
same-binary observations; they show observed variability, not an isolated-host
comparison or proof assigning every A/B stall to external work. The original,
repeat and pooled A/B latency failures independently prevent adoption.
