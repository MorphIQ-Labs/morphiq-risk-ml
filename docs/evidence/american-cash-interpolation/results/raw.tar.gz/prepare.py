from pathlib import Path
R=Path('/tmp/morphiq-american-cash-interpolation')
api='''  type interpolation = Endpoint of float | Interpolated of t | Unresolved_weight

  val linear_interpolate :
    t -> lower:float -> upper:float -> left:float -> right:float -> interpolation
  (** Original-input convex linear interpolation. Exact endpoints return the
      supplied scalar unchanged. Interior weights must be strictly enclosed in
      (0,1); otherwise [Unresolved_weight]. Arithmetic may raise [Unresolved].
      Returned enclosures own immutable fields; no scratch escapes. *)

'''
for name in ('lib/enclosure.ml','lib/enclosure.mli'):
 p=R/name;s=p.read_text();assert s.count('  val add_error :')==1;s=s.replace('  val add_error :',api+'  val add_error :',1);p.write_text(s)
p=R/'lib/enclosure.ml';s=p.read_text();needle='  let sqrt a =';assert s.count(needle)==1
body='''  type interpolation = Endpoint of float | Interpolated of t | Unresolved_weight

  let linear_interpolate point ~lower ~upper ~left ~right =
    if compare_float point lower = Zero then Endpoint left
    else if compare_float point upper = Zero then Endpoint right
    else
      let width = sub (exact upper) (exact lower) in
      let weight = div (sub point (exact lower)) width in
      match (compare_float weight 0., compare_float weight 1.) with
      | Positive, Negative ->
          Interpolated
            (add (mul (sub (exact 1.) weight) (exact left))
               (mul weight (exact right)))
      | _ -> Unresolved_weight

'''
p.write_text(s.replace(needle,body+needle))
p=R/'test/dune';s=p.read_text();s='''(test
 (name enclosure_interpolation)
 (modules enclosure_interpolation)
 (modes byte_complete exe)
 (libraries morphiq_risk zarith))

'''+s;p.write_text(s)
