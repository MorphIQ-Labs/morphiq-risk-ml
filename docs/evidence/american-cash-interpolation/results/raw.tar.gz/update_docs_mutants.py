from pathlib import Path
R=Path('/tmp/morphiq-american-cash-interpolation')
p=R/'scripts/mutation/mutation.ml';s=p.read_text();old='''      snippet = "pack_array terms (na + 2) (a.error +^ 0.0)";''';new='''      snippet = "pack_array terms (na + 2) (a.error +^ 0.0)\\n\\n  let sub a b";''';assert s.count(old)==1;s=s.replace(old,new);s=s.replace('''         + 2) (a.error +^ 0.0)";''','''         + 2) (a.error +^ 0.0)\\n\\n  let sub a b";''',1)
anchor='''    {
      id = "enclosure-exponential-prefix";'''
new='''    {
      id = "enclosure-interpolation-prefix";
      file = "lib/enclosure.ml";
      snippet = "pack_array terms (na + 2) (a.error +^ 0.0)\\n\\n  let sub_float a b";
      replacement = "pack_array terms (Float.Array.length terms) (a.error +^ 0.0)\\n\\n  let sub_float a b";
      killer = "enclosure_interpolation";
      mechanism = "interpolation subtraction must exclude stale packing slots";
    };
    {
      id = "enclosure-interpolation-complement";
      file = "lib/enclosure.ml";
      snippet = "(sub_using allocate (exact 1.) weight)";
      replacement = "weight";
      killer = "enclosure_interpolation";
      mechanism = "linear interpolation retains the complementary left weight";
    };
''';assert anchor in s;s=s.replace(anchor,new+anchor,1);anchor='  | "terminal_cash" -> [ [ "terminal_cash" ] ]';assert anchor in s;s=s.replace(anchor,'  | "enclosure_interpolation" -> [ [ "--numerical-only" ] ]\n'+anchor);p.write_text(s)
p=R/'scripts/mutation/test_selection.py';s=p.read_text();assert 'len(full), 177' in s;p.write_text(s.replace('len(full), 177','len(full), 179'))
p=R/'docs/mutation-policy.md';s=p.read_text().replace('catalog currently contains **177','catalog currently contains **179',1);s=s.replace('The total catalog is 177; the default core remains seven.','That pass brought the catalog to 177; the default core remains seven.',1);anchor='## Zero-volatility boundary regressions';new='''The cash interpolation storage pass adds `enclosure-interpolation-prefix` and
`enclosure-interpolation-complement`. Their `enclosure_interpolation` guard uses
`--numerical-only`: independent exact-rational containment/availability must
reject the fault; full-field replay comparisons are excluded from this guard.
Ordinary tests additionally compare the original composition, endpoints,
refusals, retained results and independent domains. The scalar quotient prefix
locator is scoped to its original addition helper now that scalar subtraction
also accepts private scratch. The optional catalog is 179; the default core
remains seven.

''';assert anchor in s;s=s.replace(anchor,new+anchor,1);p.write_text(s)
p=R/'docs/runtime-enclosures.md';s=p.read_text();anchor='`test/enclosure_scalar.ml` checks full fields';new='''### Interpolation-owned scratch

`linear_interpolate` is an internal, model-independent composition of enclosed
endpoint comparisons, `(point-lower)/(upper-lower)`, strict convex-weight
checks and `(1-weight)*left + weight*right`. Exact endpoints return the original
scalar directly, including its zero sign. An unresolved weight is a distinct
result; the cash owner retains its original failure message, diagnostics and
local arithmetic limit. Binary grid search, event sides, mapping refinements,
work accounting and cancellation checkpoints stay in that owner.

The primitive owns one array of `max 8 (2*w*w)` floats. The exponential bounds
above also cover this composition and general division: its denominator lower
part needs `w-1` terms, quotient suboperations eight, and geometric correction
products at most `2*w*w`. Each operation overwrites its used prefix and copies
retained fields. General division's ordinary entry point still allocates fresh
storage and retains its original scalar-quotient ownership; only this composition
supplies the interpolation array. The geometric tail and validation are unchanged.

Scalar subtraction/multiplication insert the same logical exact-scalar words
and zero signs as their generic counterparts. The first endpoint comparison
already constructs `point-lower`; this immutable enclosure is reused as the
numerator after the upper endpoint check. Both inputs and all five stored fields
are unchanged, so reevaluating that pure subtraction cannot supply new evidence
or a different failure. This is within-call common-expression reuse, with no
cross-point/cache dependency. Width is still enclosed from the original nodes;
the expression is not rewritten into slope form or reassociated. Explicit
inlining removes argument boxing without changing arithmetic.

`test/enclosure_interpolation.ml` checks both precisions against the original
composition and an independent exact-rational linear formula. For uncertain
points inside ordered finite nodes, the affine image is bounded by the two
rational endpoint values (including decreasing interpolants). The numerical-only
mutation guard checks containment and availability; ordinary compatibility also
covers unresolved weights, arithmetic failures, signed endpoints, extreme nodes,
retained results and independent domains. No result or callback borrows scratch.

''';assert anchor in s;s=s.replace(anchor,new+anchor,1);p.write_text(s)
p=R/'docs/american-cash-dividends.md';s=p.read_text();anchor='Both event differences must meet the same epsilon/8 criterion';new='''The internal enclosed interpolation primitive reuses bounded call-owned packing
storage and the immutable original `point-lower` numerator. It preserves exact
endpoint shortcuts, strict convex-weight checks, the weighted-sum order and
all fields/radii. Grid search, tick counts, diagnostics and rejection limits
remain in the cash solver; this introduces no cross-point cache or borrowed
result. See the [storage argument](runtime-enclosures.md#interpolation-owned-scratch).

''';assert anchor in s;s=s.replace(anchor,new+anchor,1);p.write_text(s)
p=R/'CHANGELOG.md';s=p.read_text();anchor='### Enclosed exponential scratch (#119)';new='''### Cash interpolation storage (#119)

- Reuse bounded private packing storage and the immutable point-to-lower-node
  difference inside enclosed linear interpolation. Preserve endpoints, convex
  checks, arithmetic order, errors, diagnostics, event semantics and work limits.
- The internal primitive is shared by both enclosure precisions; public pricing
  signatures and complete numerical outcomes are unchanged.

''';assert anchor in s;s=s.replace(anchor,new+anchor,1);p.write_text(s)
