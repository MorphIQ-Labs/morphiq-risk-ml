from pathlib import Path
R=Path('/tmp/morphiq-american-cash-interpolation')
p=R/'lib/enclosure.ml';s=p.read_text()
start=s.index('  let sub_float a b =');end=s.index('  let[@inline always] frexp_exponent',start)
part=s[start:end].replace('let sub_float a b =','let sub_float_using allocate a b =').replace('Float.Array.create (na + 2)','allocate (na + 2)').replace('pack_array terms (Float.Array.length terms)','pack_array terms (na + 2)')
part+='  let sub_float a b = sub_float_using Float.Array.create a b\n\n';s=s[:start]+part+s[end:]
start=s.index('  let div a b =');end=s.index('  let scale a k =',start)
part=s[start:end].replace('let div a b =','let div_using allocate divide_float a b =').replace('div_float ','divide_float ').replace('Float.Array.create (word_count b - 1)','allocate (word_count b - 1)').replace('pack_array terms (Float.Array.length terms)','pack_array terms (word_count b - 1)').replace('power := mul !power','power := mul_using allocate !power').replace('inverse := add !inverse','inverse := add_using allocate !inverse').replace('add_error (mul quotient !inverse)','add_error (mul_using allocate quotient !inverse)')
part+='  let div a b = div_using Float.Array.create div_float a b\n\n';s=s[:start]+part+s[end:]
start=s.index('  let linear_interpolate point');end=s.index('  let sqrt a =',start)
part='''  let linear_interpolate point ~lower ~upper ~left ~right =
    (* All arithmetic completes into immutable fields before another operation
       overwrites this call's checked prefix. No result borrows this array. *)
    let capacity = max 8 (2 * Config.words * Config.words) in
    let scratch = Float.Array.create capacity in
    let allocate count =
      require (count <= capacity) "interpolation scratch bound";
      scratch
    in
    let subtract a b = sub_float_using allocate a b in
    let compare a b = sign (subtract a b) in
    if compare point lower = Zero then Endpoint left
    else if compare point upper = Zero then Endpoint right
    else
      let width = subtract (exact upper) lower in
      let weight =
        div_using allocate (div_float_using allocate) (subtract point lower) width
      in
      match (compare weight 0., compare weight 1.) with
      | Positive, Negative ->
          Interpolated
            (add_using allocate
               (mul_float_using allocate (sub_using allocate (exact 1.) weight) left)
               (mul_float_using allocate weight right))
      | _ -> Unresolved_weight

''';s=s[:start]+part+s[end:];p.write_text(s)
p=R/'lib/early_exercise.ml';s=p.read_text();start=s.index('            if E.compare_float point nodes.(!low)');end=s.index('              c.mapping_width <-',start)
part='''            match
              E.linear_interpolate point ~lower:nodes.(!low) ~upper:nodes.(!high)
                ~left:values.(!low) ~right:values.(!high)
            with
            | E.Endpoint value -> value
            | E.Unresolved_weight -> fail "cash interpolation weight unresolved"
            | E.Interpolated ball ->
              let value, error = enclosed ball in
''';s=s[:start]+part+s[end:];p.write_text(s)
