import concurrent.futures,hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/tmp/morphiq-american-cash-interpolation');OUT=Path('/tmp/morphiq-american-cash-evidence/qualification')
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts'))
from measure_american_workloads import source_snapshot,atomic_json,sha
roots={'baseline':Path('/tmp/morphiq-cash-baseline'),'candidate':ROOT}
names=['american_pricing','american_cash','bermudan','american_piecewise','american_greeks','american_iv']
binaries={};identities={}
for variant,root in roots.items():
 directory=OUT/(variant+'-bin');directory.mkdir();binaries[variant]={}
 identities[variant]=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source=source_snapshot(root),binaries={})
 for name in names:
  source=root/'_build/default/test'/(name+'.exe');dest=directory/(name+'.exe');shutil.copyfile(source,dest);dest.chmod(0o755)
  assert sha(source)==sha(dest)
  binaries[variant][name]=dest;identities[variant]['binaries'][name]=sha(dest)
atomic_json(OUT/'manifest.json',identities)
families=[('american','check_american_runtime.py','american_pricing'),('cash','check_american_cash.py','american_cash'),('bermudan','check_bermudan.py','bermudan'),('piecewise','check_american_piecewise.py','american_piecewise'),('greeks','check_american_greeks.py','american_greeks')]
def run(family,script,binary,mode,refined,variant):
 name=f'{family}-{mode}-{refined}-{variant}';dest=OUT/name
 command=['python3',str(ROOT/'scripts'/script),'--executable',str(binaries[variant][binary]),'--mode',mode,'--output',str(dest)]
 if refined:command+=['--refined']
 with (OUT/(name+'.log')).open('w') as log:
  subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=2400)
 report=json.loads((dest/'results.json').read_text());assert report['complete']
 print(name,'complete',flush=True)
 return name,report
jobs=[(f,s,b,m,g,v) for f,s,b in families for m in ('primary','loose') for g in (False,True) for v in roots]
results={}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 pending=[pool.submit(run,*j) for j in jobs]
 for future in concurrent.futures.as_completed(pending):
  name,report=future.result();results[name]=dict(counts=report['counts'],rows=len(report['rows']))
comparisons={}
for f,s,b in families:
 for m in ('primary','loose'):
  for g in (False,True):
   key=f'{f}-{m}-{g}';a=OUT/(key+'-baseline');b=OUT/(key+'-candidate')
   for file in ('stdout.tsv','stdout.tsv.stderr'):
    assert (a/file).read_bytes()==(b/file).read_bytes(),(key,file)
   left=json.loads((a/'results.json').read_text());right=json.loads((b/'results.json').read_text())
   assert left['rows']==right['rows'] and left['counts']==right['counts'],key
   comparisons[key]=dict(rows=len(left['rows']),counts=left['counts'],full_payloads_match=True)
for label,width,expansions in [('initial','0.05','2'),('refined','0.05','3'),('tight','0.005','3')]:
 logs=[]
 for v in roots:
  log=OUT/(f'iv-{label}-{v}.log');err=OUT/(f'iv-{label}-{v}.stderr');logs.append(log)
  with log.open('w') as o,err.open('w') as e:
   subprocess.run([str(binaries[v]['american_iv']),str(ROOT/'docs/evidence/american-iv/references.tsv'),'all',width,expansions],stdout=o,stderr=e,check=True,timeout=2400)
 subprocess.run(['python3',str(ROOT/'scripts/american_iv_campaign.py'),'--same',*[str(p) for p in logs]],stdout=(OUT/(f'iv-{label}-comparison.json')).open('w'),check=True)
 print('iv',label,'complete',flush=True)
for v in roots:
 for name,path in binaries[v].items():assert sha(path)==identities[v]['binaries'][name]
atomic_json(OUT/'complete.json',dict(complete=True,comparisons=comparisons,iv_campaigns=3))
