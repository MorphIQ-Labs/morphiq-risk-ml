import json,subprocess,sys
from pathlib import Path
R=Path('/tmp/morphiq-american-cash-interpolation');B=Path('/tmp/morphiq-cash-baseline');O=Path('/tmp/morphiq-american-cash-evidence/same-binary');O.mkdir(exist_ok=False)
sys.path.insert(0,str(R/'scripts'))
from measure_american_workloads import source_snapshot,sha,child,require_child,atomic_json
from check_american_backends import requests
roots={'baseline':B,'candidate':R};sources={k:source_snapshot(r) for k,r in roots.items()};bins={k:r/'_build/default/bench/backend_requests.exe' for k,r in roots.items()};hashes={k:sha(p) for k,p in bins.items()}
def guard():
 assert all(source_snapshot(r)==sources[k] for k,r in roots.items())
 assert all(sha(p)==hashes[k] for k,p in bins.items())
atomic_json(O/'manifest.json',dict(sources=sources,binaries=hashes,commits={k:subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip() for k,r in roots.items()}));rows=[];identity=None
for i in range(3):
 for variant in (('baseline','candidate') if i%2==0 else ('candidate','baseline')):
  for label in ('first','second'):
   guard();name=f'{i}-{variant}-{label}';cmd=['env','-u','MORPHIQ_CAPTURE_CELLS','-u','MORPHIQ_POLICY_BACKEND','-u','MORPHIQ_POLICY_TRACE','-u','MORPHIQ_POLICY_ACCOUNT',str(bins[variant]),'--case','piecewise-cash','--size','4']
   if i%2:cmd.append('--reverse')
   r=child(cmd,O/(name+'.log'),O/(name+'.stderr'),600);atomic_json(O/(name+'.json'),r);require_child(r)
   result=requests((O/(name+'.log')).read_text(),'piecewise-cash',4)
   key={k:result[k] for k in ('rows','values')}
   if identity is None:identity=key
   assert key==identity
   r.update(round=i,variant=variant,label=label,result=result);atomic_json(O/(name+'.json'),r);rows.append(r);print(name,'complete',flush=True)
guard();atomic_json(O/'complete.json',dict(complete=True,processes=len(rows),unchanged_replay=True))
