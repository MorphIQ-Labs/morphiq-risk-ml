import hashlib,io,json,shutil,subprocess,tarfile,tempfile,os
from pathlib import Path
R=Path('/tmp/morphiq-american-cash-interpolation')
E=Path('/tmp/morphiq-american-cash-evidence')
DEST=R/'docs/evidence/american-cash-interpolation/results'
D=Path(tempfile.mkdtemp(prefix='publication-',dir=E))
C=E/'repeat'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R)
summary=json.loads((C/'summary.json').read_text())
complete=json.loads((C/'complete.json').read_text())
assert complete['complete'] and complete['processes']==140
first=json.loads((E/'campaign/complete.json').read_text())
assert first['complete'] and first['processes']==140
pooled=json.loads((E/'pooled.json').read_text())
assert pooled['processes']==280
disposition='adopt' if complete['criteria_pass'] and pooled['criteria_pass'] else 'defer'
assert json.loads((E/'same-binary/complete.json').read_text())['processes']==12
assert '17 of 17 mutants killed as catalogued' in (E/'mutations-final.log').read_text()
measured=json.loads((C/'manifest.json').read_text())
qualified=json.loads((E/'qualification/manifest.json').read_text())
assert json.loads((E/'qualification/complete.json').read_text())['complete']
head=measured['commits']['candidate']
changes=git('diff','--name-only',head).decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()
assert all(n.startswith('docs/') or n=='CHANGELOG.md' for n in changes),changes
for name,h in measured['sources']['candidate'].items():
 if not name.startswith('docs/') and name!='CHANGELOG.md':assert sha(R/name)==h,name
for name,h in measured['sources']['candidate'].items():
 if name.startswith(('lib/','test/','oracle/')):
  assert h==qualified['candidate']['source'][name],name
for name,h in measured['sources']['baseline'].items():
 if name.startswith(('lib/','test/','oracle/')):
  assert h==qualified['baseline']['source'][name],name
assert D.is_dir()
(D/'summary.json').write_text(json.dumps(dict(disposition=disposition,first=json.loads((E/'campaign/summary.json').read_text()),repeat=summary,pooled=pooled,same_binary=json.loads((E/'same-binary/summary.json').read_text())),indent=2)+'\n')
paths=[p for folder in ('campaign','repeat','same-binary') for p in (E/folder).rglob('*')]
paths.extend(p for p in (E/'qualification').rglob('*') if not any(x.endswith('-bin') for x in p.relative_to(E).parts))
# Preserve the initial guard-dispatch and formatting failures alongside successful checks.
for pattern in ('*.log','*-source.patch','exploratory-manifest.json','baseline-bridge.json','baseline-freeze.patch','followup-protocol.md','diagnostic-note.md','pooled.json'):
 paths.extend(E.glob(pattern))
paths.extend(E/n for n in ('qualify.py','publish.py','prepare.py','optimize.py','update_docs_mutants.py','write_report.py','same_binary.py','pool.py'))
paths=sorted({p for p in paths if p.is_file()})
changed=git('diff','--name-only',measured['commits']['baseline'],head).decode().splitlines()
changed+=['test/enclosure_interpolation.ml','docs/evidence/american-cash-interpolation/protocol.md']
files={};payloads={}
for p in paths:
 name=str(p.relative_to(E))
 assert not p.name.endswith(('.exe','.a','.o','.pdf')),name
 payloads[name]=p.read_bytes()
for name in changed:
 payloads['source/'+name]=git('show',head+':'+name)
payloads['source/runtime.patch']=git('diff',measured['commits']['baseline'],head,'--','lib')
with tarfile.open(D/'raw.tar.gz','w:gz') as archive:
 for name,data in sorted(payloads.items()):
  assert not name.startswith('/') and '..' not in Path(name).parts
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data))
  files[name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
manifest=dict(disposition=disposition,baseline_commit=measured['commits']['baseline'],source_commit=head,
 qualification_candidate_commit=qualified['candidate']['commit'],
 qualification_baseline_commit=qualified['baseline']['commit'],
 baseline_rebase=json.loads((E/'baseline-bridge.json').read_text()),
 qualification_runtime_test_oracle_sources_match=True,
 archive_sha256=sha(D/'raw.tar.gz'),files=files)
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(D/'raw.tar.gz') as archive:
 assert set(archive.getnames())==set(files)
 for member in archive:
  assert member.isfile()
  data=archive.extractfile(member).read()
  assert hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print('verified',len(files),'members; archive bytes',(D/'raw.tar.gz').stat().st_size)

DEST.mkdir(parents=True,exist_ok=True)
for name in ('summary.json','manifest.json','raw.tar.gz'):os.replace(D/name,DEST/name)
D.rmdir()
shutil.copyfile(E/'followup-protocol.md',DEST.parent/'followup-protocol.md')
