"""Fixed ten-process pooled gates; retain every sample from both campaigns."""
import argparse,json,statistics,sys
from pathlib import Path
R=Path('/tmp/morphiq-american-cash-interpolation');sys.path.insert(0,str(R/'scripts'))
from measure_exponential_scratch import JOBS
from measure_cash_interpolation import TARGETS
import benchmark_enclosure_consumers as european

def stats(xs):return dict(median=statistics.median(xs),minimum=min(xs),maximum=max(xs),samples=xs)
def summarize(rows):
 expected={(c,i,k,n,v) for c in ('first','repeat') for i in range(5) for k,n in JOBS+[('european',0)] for v in ('baseline','candidate')}
 keys=[(r['campaign'],r['round'],r['case'],r['size'],r['variant']) for r in rows]
 if len(keys)!=len(expected) or set(keys)!=expected:raise ValueError('incomplete/duplicate pooled campaign')
 failures=[];american={}
 for case,size in JOBS:
  selected=[r for r in rows if (r['case'],r['size'])==(case,size)]
  identities=[{k:r['result'][k] for k in ('rows','values')} for r in selected]
  if any(x!=identities[0] for x in identities):raise ValueError('changed pooled American replay')
  result={}
  methods=selected[0]['result']['times']
  for v in ('baseline','candidate'):
   rs=[r for r in selected if r['variant']==v]
   result[v]=dict(time={m:stats([r['result']['times'][m]['wall_s'] for r in rs]) for m in methods},memory={m:stats([r['result']['memory'][m] for r in rs]) for m in methods})
  for method in methods:
   if method=='admission':continue
   b,c=result['baseline'],result['candidate']
   limit=TARGETS.get(case,1.05) if size==1 and method=='scalar' else 1.05
   if c['memory'][method]['median']>limit*b['memory'][method]['median']:failures.append(f'{case}/{size}/{method}: allocation criterion')
   if c['time'][method]['median']>1.1*b['time'][method]['median']:failures.append(f'{case}/{size}/{method}: latency criterion')
  american[f'{case}/{size}']=result
 ers=[r for r in rows if r['case']=='european'];es=[]
 for r in ers:european.same_checks(ers[0]['result']['checks'],r['result']['checks'])
 for key in sorted({k for k,_ in european.SLOTS}):
  result={'key':key}
  for v in ('baseline','candidate'):
   rs=[r for r in ers if r['variant']==v]
   result[v]={metric:stats([statistics.mean(s[metric] for s in r['result']['samples'] if s['key']==key) for r in rs]) for metric in ('ns','allocation')}
  if not key.endswith('/admission'):
   b,c=result['baseline'],result['candidate']
   if c['ns']['median']>1.1*b['ns']['median']:failures.append(key+': European latency criterion')
   if c['allocation']['median']>1.05*b['allocation']['median']:failures.append(key+': European allocation criterion')
  es.append(result)
 return dict(american=american,european=es,criteria_pass=not failures,failures=failures,processes=len(rows))

def controls():
 from test_exponential_scratch_campaign import records
 def fixture():return [dict(r,campaign=c) for c in ('first','repeat') for r in records()]
 good=fixture();assert summarize(good)['criteria_pass']
 for bad in (good[:-1],good[:-1]+[good[0]]):
  try:summarize(bad)
  except ValueError as e:assert 'incomplete/duplicate' in str(e)
  else:raise AssertionError('incomplete accepted')
 bad=fixture();bad[0]['result']['rows']={'0':'altered'}
 try:summarize(bad)
 except ValueError as e:assert 'changed pooled American replay' in str(e)
 else:raise AssertionError('changed replay accepted')
 bad=fixture()
 for r in bad:
  if (r['case'],r['size'],r['variant'])==('cash',1,'candidate'):r['result']['memory']['scalar']=91
 assert 'cash/1/scalar: allocation criterion' in summarize(bad)['failures']
 bad=fixture()
 for r in bad:
  if (r['case'],r['size'],r['variant'])==('cash',4,'candidate'):r['result']['times']['planner1']['wall_s']=1.11
 assert 'cash/4/planner1: latency criterion' in summarize(bad)['failures']
 bad=fixture()
 for r in bad:
  if r['case']=='european' and r['variant']=='candidate':
   for s in r['result']['samples']:s['allocation']=106
 assert any('European allocation criterion' in x for x in summarize(bad)['failures'])
 print('Pooled completeness, replay, allocation, latency and European rejection controls pass.')

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--controls',action='store_true');p.add_argument('--first',type=Path);p.add_argument('--repeat',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
 if a.controls:controls();return
 if not all((a.first,a.repeat,a.output)):p.error('first/repeat/output required')
 rows=[];manifests=[]
 for label,d in (('first',a.first),('repeat',a.repeat)):
  complete=json.loads((d/'complete.json').read_text());assert complete['complete'] and complete['processes']==140 and complete['source_unchanged']
  manifests.append(json.loads((d/'manifest.json').read_text()))
  rows.extend(dict(json.loads(x.read_text()),campaign=label) for x in sorted(d.glob('[0-4]-*.json')))
 for key in ('sources','binaries','commits'):assert manifests[0][key]==manifests[1][key],key
 s=summarize(rows);a.output.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(dict(criteria_pass=s['criteria_pass'],failures=s['failures'])))
 if not s['criteria_pass']:raise SystemExit(1)
if __name__=='__main__':main()
