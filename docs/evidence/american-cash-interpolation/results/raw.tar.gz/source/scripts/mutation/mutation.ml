(* The mutation catalog: every numerical mechanism the docs claim, removed.

   The type system already rejects the structural mistakes (test/types). What
   it cannot see is a well-typed numerical mistake: [Split.two_sum a b] and
   [(a +. b, 0.0)] have the same type. Each mutant here removes one such
   mechanism and names the test that must fail without it.

   A mutant replaces one exact snippet (it must occur exactly once, so a
   catalog that drifts from the code fails loudly). It counts as killed only
   when it compiles (a compiler rejection proves nothing about the tests) and
   the named test fails (so the kill comes from the oracle or property that
   guards the mechanism).

   The full baseline runs once; each compiled mutant runs its named guard.
   Everything uses the [mutation] dune profile, which disables the
   determinism digest (any numerical change trips it) and leaves warnings
   non-fatal. Work happens in a temporary copy of the tracked files; the
   checkout is never modified.

     dune exec scripts/mutation/mutation.exe              run the catalog
     dune exec scripts/mutation/mutation.exe -- --core    run the CI core
     dune exec scripts/mutation/mutation.exe -- --list    print it
     dune exec scripts/mutation/mutation.exe -- ID ...    run the named mutants *)

type mutant = {
  id : string;
  file : string;
  snippet : string;
  replacement : string;
  killer : string;  (** The test that must fail. *)
  mechanism : string;
}

(* The quotient remainder has a direct coordinate oracle: near S/K = 1,
   rounding rho once loses relative accuracy even when the final price happens
   to round identically. The intrinsic branch guard remains an explicit probe,
   not a claim of universal indistinguishability (error-analysis §5.1). *)
let catalog =
  [
    {
      id = "american-compiled-today-cash";
      file = "lib/planner.ml";
      snippet = "List.filter (fun (x : dividend) -> x.day >= day)";
      replacement = "List.filter (fun (x : dividend) -> x.day > day)";
      killer = "american_compiled";
      mechanism = "retain current cash event and its valuation side";
    };
    {
      id = "american-compiled-today-right";
      file = "lib/planner.ml";
      snippet = "List.filter (fun x -> compare_instant x now >= 0)";
      replacement = "List.filter (fun x -> compare_instant x now > 0)";
      killer = "american_compiled";
      mechanism = "retain exercise at the current instant";
    };
    {
      id = "american-compiled-knot";
      file = "lib/planner.ml";
      snippet = "if d <= day then initial := x";
      replacement = "if d < day then initial := x";
      killer = "american_compiled";
      mechanism = "right-continuous coefficients activate at the knot";
    };
    {
      id = "american-compiled-identity";
      file = "lib/american_batch.ml";
      snippet = "C.float b cfg.tolerance;";
      replacement = "C.float b 0.;";
      killer = "american_compiled";
      mechanism = "numerical tolerance participates in identity";
    };
    {
      id = "american-compiled-workspace";
      file = "lib/planner.ml";
      snippet = "B.output_workspace o <= limits.max_solver_workspace_bytes";
      replacement = "B.output_workspace o <= max_int";
      killer = "american_compiled";
      mechanism = "enforce caller PDE workspace policy";
    };
    {
      id = "american-compiled-buffer";
      file = "lib/planner.ml";
      snippet =
        "(buffered_results <= limits.max_buffered_results)\n\
        \        \"in-flight output limit exceeded\"";
      replacement =
        "(buffered_results <= max_int)\n\
        \        \"in-flight output limit exceeded\"";
      killer = "american_compiled";
      mechanism = "bound all in-flight result slots";
    };
    {
      id = "american-compiled-cancel";
      file = "lib/american_batch.ml";
      snippet = "A.price ~cancel ~premium:p.premium";
      replacement = "A.price ~cancel:(fun () -> false) ~premium:p.premium";
      killer = "american_compiled";
      mechanism = "forward cancellation into the scalar solve";
    };
    {
      id = "american-compiled-prefix";
      file = "lib/planner.ml";
      snippet = "emit_to sink (Row row);\n      incr committed;";
      replacement = "incr committed;\n      emit_to sink (Row row);";
      killer = "american_compiled";
      mechanism = "count only sink-accepted rows";
    };
    {
      id = "american-compiled-cash-copy";
      file = "lib/planner.ml";
      snippet = "cash = Option.map Array.copy p.cash;";
      replacement = "cash = p.cash;";
      killer = "american_compiled";
      mechanism = "snapshot caller-owned cash arrays";
    };
    {
      id = "american-policy-fma";
      file = "lib/american_policy_stubs.c";
      snippet =
        "fma(Double_field(hi, i), Double_field(v, i + 1), -Double_field(rhs, \
         i))";
      replacement =
        "(Double_field(hi, i) * Double_field(v, i + 1) - Double_field(rhs, i))";
      killer = "american_policy";
      mechanism = "preserve the explicit fused policy residual";
    };
    {
      id = "american-policy-product";
      file = "lib/american_policy_stubs.c";
      snippet = "Double_field(d, i) - mult * prev_hi";
      replacement = "fma(-mult, prev_hi, Double_field(d, i))";
      killer = "american_policy";
      mechanism = "preserve separately rounded elimination product";
    };
    {
      id = "american-policy-mask";
      file = "lib/american_policy_stubs.c";
      snippet =
        "Bool_val(Field(mask, i)) ? 0. : Double_field(lo, i) / Double_field(d, \
         i - 1)";
      replacement = "Double_field(lo, i) / Double_field(d, i - 1)";
      killer = "american_policy";
      mechanism = "identity rows have zero lower coefficient";
    };
    {
      id = "american-policy-upper";
      file = "lib/american_policy_stubs.c";
      snippet = "Bool_val(Field(mask, i - 1)) ? 0. : Double_field(hi, i - 1)";
      replacement = "Double_field(hi, i - 1)";
      killer = "american_policy";
      mechanism = "previous identity row has zero upper coefficient";
    };
    {
      id = "american-policy-pivot";
      file = "lib/american_policy_stubs.c";
      snippet = "if (Double_field(d, i - 1) <= 0.)";
      replacement = "if (0)";
      killer = "american_policy";
      mechanism = "reject nonpositive forward pivot before division";
    };
    {
      id = "american-policy-back-pivot";
      file = "lib/american_policy_stubs.c";
      snippet = "if (Double_field(d, i) <= 0.)";
      replacement = "if (0)";
      killer = "american_policy";
      mechanism = "reject nonpositive backward pivot before division";
    };
    {
      id = "american-policy-finite";
      file = "lib/american_policy_stubs.c";
      snippet = "if (!isfinite(solved_rhs))";
      replacement = "if (0)";
      killer = "american_policy";
      mechanism = "retain first nonfinite RHS failure";
    };
    {
      id = "american-policy-visit";
      file = "lib/american_policy_stubs.c";
      snippet = "Field(state, 4) = Val_long(visited);";
      replacement = "Field(state, 4) = Val_long(visited - (status != 0));";
      killer = "american_policy";
      mechanism = "include the failing row in logical work";
    };
    {
      id = "american-policy-alias";
      file = "lib/american_policy_stubs.c";
      snippet = "if (Field(bands, k) == Field(bands, j)) invalid();";
      replacement = "if (0) invalid();";
      killer = "american_policy";
      mechanism = "reject writable band aliases";
    };
    {
      id = "american-policy-budget";
      file = "lib/early_exercise.ml";
      snippet =
        "let visited = American_policy.visited policy_state in\n\
        \        c.visits <- c.visits + visited - 1;";
      replacement =
        "let visited = American_policy.visited policy_state in\n\
        \        c.visits <- c.cfg.limits.max_row_visits + visited;";
      killer = "american_pricing";
      mechanism = "preserve logical visits and cancellation ordering";
    };
    {
      id = "terminal-cash-window";
      file = "lib/early_exercise.ml";
      snippet = "&& p.opens_at = p.time_to_expiry ->";
      replacement = "&& true ->";
      killer = "terminal_cash";
      mechanism = "earlier exercise cannot become terminal-only";
    };
    {
      id = "terminal-cash-date";
      file = "lib/early_exercise.ml";
      snippet = "when p.time_to_expiry > 0. && time = p.time_to_expiry";
      replacement = "when p.time_to_expiry > 0. && true";
      killer = "terminal_cash";
      mechanism = "earlier cash cannot be collapsed into terminal strike";
    };
    {
      id = "terminal-cash-side";
      file = "lib/early_exercise.ml";
      snippet = "| Side.Call, Some spec, [ (time, amount) ]";
      replacement = "| _, Some spec, [ (time, amount) ]";
      killer = "terminal_cash";
      mechanism = "cash puts have a different payoff";
    };
    {
      id = "terminal-cash-phase";
      file = "lib/early_exercise.ml";
      snippet = "if spec.opening_side = Before_cash then exact p.strike";
      replacement = "if spec.opening_side = After_cash then exact p.strike";
      killer = "terminal_cash";
      mechanism = "pre-cash exercise dominates the post-cash call";
    };
    {
      id = "terminal-cash-lowword";
      file = "lib/early_exercise.ml";
      snippet = "~strike:strike.hi ~strike_low:strike.lo";
      replacement = "~strike:strike.hi ~strike_low:0.";
      killer = "terminal_cash";
      mechanism = "retain the effective strike low word";
    };
    {
      id = "terminal-cash-greek";
      file = "lib/early_exercise.ml";
      snippet = "~terminal_reductions:false";
      replacement = "~terminal_reductions:true";
      killer = "terminal_cash";
      mechanism = "price reduction does not qualify spatial Greeks";
    };
    {
      id = "terminal-cash-amount";
      file = "lib/early_exercise.ml";
      snippet = "else E.add (exact p.strike) amount)";
      replacement = "else exact p.strike)";
      killer = "terminal_cash";
      mechanism = "after-cash payoff includes the joint payment";
    };
    {
      id = "american-iv-progress";
      file = "lib/early_exercise.ml";
      snippet = "if phase = 2 then midpoint a b";
      replacement = "if false && phase = 2 then midpoint a b";
      killer = "american_iv";
      mechanism =
        "low-vega proposals need periodic bracket contraction within the price \
         budget";
    };
    {
      id = "american-iv-spacing";
      file = "lib/early_exercise.ml";
      snippet = "Float.min (cfg.width *. 0.25) ((hi -. lo) *. 0.25)";
      replacement = "0.";
      killer = "american_iv";
      mechanism =
        "near-endpoint interpolation must not oversolve one endpoint while \
         exhausting the price budget";
    };
    {
      id = "american-iv-quote";
      file = "lib/early_exercise.ml";
      snippet = "let quote x =\n      if Float.is_finite x && x >= 0. then Ok x";
      replacement = "let quote x =\n      if Float.is_finite x then Ok x";
      killer = "american_iv";
      mechanism = "negative quotes cannot enter the private validated type";
    };
    {
      id = "american-iv-uncertainty";
      file = "lib/early_exercise.ml";
      snippet =
        "raise (B.Unresolved \"inverse price indicator\");\n      result";
      replacement =
        "raise (B.Unresolved \"inverse price indicator\");\n      0.";
      killer = "american_iv";
      mechanism = "price indicators must participate in every sign decision";
    };
    {
      id = "american-iv-width";
      file = "lib/early_exercise.ml";
      snippet = "B.compare_float distance cfg.width";
      replacement = "B.Zero";
      killer = "american_iv";
      mechanism = "entire accepted volatility width must meet the target";
    };
    {
      id = "american-iv-budget";
      file = "lib/early_exercise.ml";
      snippet =
        "if !evaluations >= cfg.max_evaluations then stop Evaluation_limit;";
      replacement =
        "if false && !evaluations >= cfg.max_evaluations then stop \
         Evaluation_limit;";
      killer = "american_iv";
      mechanism = "maximum price calls includes attempted evaluations";
    };
    {
      id = "american-iv-cash-put";
      file = "lib/early_exercise.ml";
      snippet =
        "if side = Side.Put && Option.is_some cash then stop \
         Unsupported_cash_put;";
      replacement =
        "if false && side = Side.Put && Option.is_some cash then stop \
         Unsupported_cash_put;";
      killer = "american_iv";
      mechanism = "cash put monotonicity cannot be assumed";
    };
    {
      id = "american-iv-volatility";
      file = "lib/early_exercise.ml";
      snippet =
        "let replace_volatility admitted volatility =\n\
        \      match admitted with\n\
        \      | Admitted p -> Admitted { p with volatility }";
      replacement =
        "let replace_volatility admitted volatility =\n\
        \      match admitted with\n\
        \      | Admitted p -> Admitted p";
      killer = "american_iv";
      mechanism = "inverse varies the candidate rather than the admitted seed";
    };
    {
      id = "american-iv-exercise";
      file = "lib/early_exercise.ml";
      snippet = "Bermudan ({ p with volatility }, cash, dates)\n\n    let solve";
      replacement = "Admitted { p with volatility }\n\n    let solve";
      killer = "american_iv";
      mechanism = "finite exercise rights must survive volatility replacement";
    };
    {
      id = "american-iv-opening-floor";
      file = "lib/early_exercise.ml";
      snippet = "if cash = None && p.opens_at = 0. then";
      replacement = "if cash = None then";
      killer = "american_iv";
      mechanism = "delayed exercise does not have an immediate-payoff floor";
    };
    {
      id = "american-iv-global-cap";
      file = "lib/early_exercise.ml";
      snippet = "B.mul (exact (max 0. (-.rate))) (exact p.time_to_expiry)";
      replacement = "B.mul (exact (max 0. rate)) (exact p.time_to_expiry)";
      killer = "american_iv";
      mechanism = "negative rates and yields enlarge the true financial cap";
    };
    {
      id = "american-iv-cancel";
      file = "lib/early_exercise.ml";
      snippet = "let checkpoint () = if cancel () then stop Cancelled in";
      replacement =
        "let checkpoint () = if false && cancel () then stop Cancelled in";
      killer = "american_iv";
      mechanism = "cancellation before evaluation is observable";
    };
    {
      id = "american-certified-cash";
      file = "lib/early_exercise.ml";
      snippet = "Error (Unsupported_capability Cash_specification)";
      replacement = "Ok Terminal_only";
      killer = "american_certification";
      mechanism = "cash semantics cannot be discarded by certification";
    };
    {
      id = "american-certified-window";
      file = "lib/early_exercise.ml";
      snippet = "p.opens_at = p.time_to_expiry then Ok Terminal_only";
      replacement = "p.opens_at <= p.time_to_expiry then Ok Terminal_only";
      killer = "american_certification";
      mechanism = "only terminal-only rights reduce arbitrary puts to Europe";
    };
    {
      id = "american-certified-side";
      file = "lib/early_exercise.ml";
      snippet =
        "else if side = Side.Call && p.dividend_yield = 0. && p.rate >= 0. then\n\
        \            Ok No_early_exercise_call";
      replacement =
        "else if p.dividend_yield = 0. && p.rate >= 0. then\n\
        \            Ok No_early_exercise_call";
      killer = "american_certification";
      mechanism = "no-early-exercise theorem is for calls";
    };
    {
      id = "american-certified-rate";
      file = "lib/early_exercise.ml";
      snippet =
        "else if side = Side.Call && p.dividend_yield = 0. && p.rate >= 0. then\n\
        \            Ok No_early_exercise_call";
      replacement =
        "else if side = Side.Call && p.dividend_yield = 0. && true then\n\
        \            Ok No_early_exercise_call";
      killer = "american_certification";
      mechanism = "no-early-exercise call proof requires nonnegative rate";
    };
    {
      id = "american-certified-yield";
      file = "lib/early_exercise.ml";
      snippet =
        "else if side = Side.Call && p.dividend_yield = 0. && p.rate >= 0. then\n\
        \            Ok No_early_exercise_call";
      replacement =
        "else if side = Side.Call && p.rate >= 0. then\n\
        \            Ok No_early_exercise_call";
      killer = "american_certification";
      mechanism = "no-early-exercise call proof retains zero yield";
    };
    {
      id = "american-certified-bound";
      file = "lib/early_exercise.ml";
      snippet = "else Ok { value; absolute_error; reduction }";
      replacement = "else Ok { value; absolute_error = 0.; reduction }";
      killer = "american_certification";
      mechanism = "certificate retains outward arithmetic radius";
    };
    {
      id = "american-certified-limit";
      file = "lib/early_exercise.ml";
      snippet =
        "else if absolute_error > max_error then Error Accuracy_exceeded";
      replacement =
        "else if false && absolute_error > max_error then Error \
         Accuracy_exceeded";
      killer = "american_certification";
      mechanism = "boundary certificate enforces the caller error limit";
    };
    {
      id = "american-certified-accuracy";
      file = "lib/early_exercise.ml";
      snippet =
        "let absolute_error_limit x =\n\
        \      if Float.is_finite x && x >= 0. then Ok x";
      replacement =
        "let absolute_error_limit x =\n      if Float.is_finite x then Ok x";
      killer = "american_certification";
      mechanism = "validated accuracy type rejects negative limits";
    };
    {
      id = "american-residual-fma";
      file = "lib/american_residual_stubs.c";
      snippet =
        "fma(Double_field(hi, i), Double_field(v, i + 1), -Double_field(rhs, \
         i))";
      replacement =
        "(Double_field(hi, i) * Double_field(v, i + 1) - Double_field(rhs, i))";
      killer = "american_residual";
      mechanism = "residual retains explicit fused multiplication and addition";
    };
    {
      id = "american-residual-screen";
      file = "lib/american_residual_stubs.c";
      snippet = "0x1p-48 * magnitude";
      replacement = "0x1p-49 * magnitude";
      killer = "american_residual";
      mechanism = "residual retains the derived roundoff screen";
    };
    {
      id = "american-greek-boundary-inputs";
      file = "lib/early_exercise.ml";
      snippet = "if same_boundary_inputs then boundary_reuse";
      replacement = "if true then boundary_reuse";
      killer = "american_greek_reuse";
      mechanism = "rate shifts cannot reuse volatility-shift boundary values";
    };
    {
      id = "american-greek-boundary-error";
      file = "lib/early_exercise.ml";
      snippet = "| Some errors -> accept_boundary c value errors.(i)";
      replacement = "| Some _ -> value";
      killer = "american_greek_reuse";
      mechanism =
        "each solve must retain cached boundary arithmetic uncertainty";
    };
    {
      id = "american-greek-gamma";
      file = "lib/early_exercise.ml";
      snippet = "E.div (E.mul_float (E.sub r l) 2.) span";
      replacement = "E.div (E.mul_float (E.sub r l) 1.) span";
      killer = "american_greeks";
      mechanism = "nonuniform second derivative has its factor two";
    };
    {
      id = "american-greek-theta";
      file = "lib/early_exercise.ml";
      snippet = "                365.\n          in\n          let a = x.(i)";
      replacement =
        "                (-.365.)\n          in\n          let a = x.(i)";
      killer = "american_greeks";
      mechanism = "theta is forward calendar passage with fixed future events";
    };
    {
      id = "american-greek-parallel";
      file = "lib/early_exercise.ml";
      snippet = "segments = Array.map (fun (t, v) -> (t, shift v)) c.segments;";
      replacement = "segments = c.segments;";
      killer = "american_greeks";
      mechanism = "parallel risk shifts every coefficient level";
    };
    {
      id = "american-greek-cash-kink";
      file = "lib/early_exercise.ml";
      snippet = "| Some cash -> cash.valuation_side = Before_cash";
      replacement = "| Some _ -> false";
      killer = "american_greeks";
      mechanism =
        "valuation liquidation kinks cannot be ordinary spot derivatives";
    };
    {
      id = "american-greek-one-sided";
      file = "lib/early_exercise.ml";
      snippet = "sample_stencil = abs_float slope_difference;";
      replacement = "sample_stencil = 0.;";
      killer = "american_greeks";
      mechanism =
        "central convergence alone does not establish a derivative at a kink";
    };
    {
      id = "piecewise-average-profile";
      file = "lib/early_exercise.ml";
      snippet =
        "let curve_level curve t = snd curve.segments.(curve_index curve t)";
      replacement =
        "let curve_level curve _ = let sum = ref 0. in Array.iteri (fun i \
         (t,v) -> let stop = if i + 1 < Array.length curve.segments then fst \
         curve.segments.(i+1) else curve.horizon in sum := !sum +. v *. (stop \
         -. t)) curve.segments; !sum /. curve.horizon";
      killer = "american_piecewise";
      mechanism = "time ordering of coefficients affects early exercise";
    };
    {
      id = "piecewise-left-knot";
      file = "lib/early_exercise.ml";
      snippet = "if fst curve.segments.(m) <= t then lo := m else hi := m";
      replacement = "if fst curve.segments.(m) < t then lo := m else hi := m";
      killer = "american_piecewise";
      mechanism = "rollback uses the right coefficient at each slab start";
    };
    {
      id = "piecewise-future-optimum";
      file = "lib/early_exercise.ml";
      snippet = "Array.iter (fun (t, _) -> add t) curve.segments";
      replacement = "()";
      killer = "american_piecewise";
      mechanism = "interior rate knots can maximize the future discount factor";
    };
    {
      id = "piecewise-slab-matrix";
      file = "lib/early_exercise.ml";
      snippet = "let assemble = j = 1 in";
      replacement = "let assemble = j = 1 && diag.(1) = 0. in";
      killer = "american_piecewise";
      mechanism =
        "original matrix bands must be rebuilt for every constant slab";
    };
    {
      id = "piecewise-cache-key";
      file = "lib/early_exercise.ml";
      snippet = "List.assoc_opt (key p) (snd !stencils)";
      replacement = "Option.map snd (List.nth_opt (snd !stencils) 0)";
      killer = "american_piecewise";
      mechanism = "reused stencils retain every coefficient dependency";
    };
    {
      id = "piecewise-cache-ownership";
      file = "lib/early_exercise.ml";
      snippet = "Array.copy left, Array.copy right, switched";
      replacement = "left, right, switched";
      killer = "american_piecewise";
      mechanism = "stored stencils cannot alias mutable working bands";
    };
    {
      id = "piecewise-upper-boundary-key";
      file = "lib/early_exercise.ml";
      snippet = "Option.map Int64.bits_of_float top";
      replacement = "Option.map (fun _ -> Int64.zero) top";
      killer = "american_piecewise";
      mechanism = "call upper boundaries depend on the stock-grid endpoint";
    };
    {
      id = "piecewise-stencil-key";
      file = "lib/early_exercise.ml";
      snippet = "if key p <> !current_key then (";
      replacement = "if false then (";
      killer = "american_piecewise";
      mechanism = "operator preparation changes with coefficients";
    };
    {
      id = "enclosure-scalar-radius";
      file = "lib/enclosure.ml";
      snippet =
        "let input = (centre_magnitude a *^ 0.0) +^ (abs b *^ a.error) in";
      replacement = "let input = 0.0 in";
      killer = "enclosure_scalar";
      mechanism = "scalar multiplication transports the input enclosure radius";
    };
    {
      id = "enclosure-scratch-length";
      file = "lib/enclosure.ml";
      snippet = "pack_array terms (na + 2) (a.error +^ 0.0)\n\n  let sub a b";
      replacement =
        "pack_array terms (if a.hi > 2.0 then Float.Array.length terms else na \
         + 2) (a.error +^ 0.0)\n\n\
        \  let sub a b";
      killer = "enclosure_scalar";
      mechanism = "packing must not consume stale scalar-quotient scratch slots";
    };
    {
      id = "bermudan-finite-deterministic";
      file = "lib/early_exercise.ml";
      snippet = "if regular || before then add t;";
      replacement = "if before then add t;";
      killer = "bermudan";
      mechanism = "deterministic stopping uses every listed date";
    };
    {
      id = "bermudan-valuation-projection";
      file = "lib/early_exercise.ml";
      snippet = "if before || regular then project ();";
      replacement = "if before then project ();";
      killer = "bermudan";
      mechanism = "a listed valuation right enforces its immediate payoff";
    };
    {
      id = "bermudan-boundary-slab-key";
      file = "lib/early_exercise.ml";
      snippet =
        "Int64.bits_of_float earlier,\n\
        \          Int64.bits_of_float later,\n\
        \          Option.map Int64.bits_of_float next_exercise,";
      replacement = "Int64.zero, Int64.zero, None,";
      killer = "bermudan";
      mechanism = "boundary reuse must retain the original slab and next right";
    };
    {
      id = "bermudan-next-right-boundary";
      file = "lib/early_exercise.ml";
      snippet = "| Some date -> E.sub (exact date) t_e";
      replacement = "| Some _ -> exact 0.";
      killer = "bermudan";
      mechanism = "absorbing puts discount to the next permitted exercise date";
    };
    {
      id = "american-spatial-grid-key";
      file = "lib/early_exercise.ml";
      snippet = "when l = level && d = domain -> prepared";
      replacement = "when l = level -> prepared";
      killer = "american_pricing";
      mechanism = "spatial preparation cannot cross a changed domain grid";
    };
    {
      id = "american-prepared-stencil";
      file = "lib/early_exercise.ml";
      snippet = "(left, right, g, previous_key = key p, switched)";
      replacement = "(right, left, g, previous_key = key p, switched)";
      killer = "american_pricing";
      mechanism = "both boundary solves use the same correctly oriented stencil";
    };
    {
      id = "american-cash-opening-side";
      file = "lib/early_exercise.ml";
      snippet = "rank side >= rank cash.opening_side";
      replacement = "true";
      killer = "american_cash";
      mechanism =
        "opening after a dividend excludes exercise before that dividend";
    };
    {
      id = "american-cash-liquidator";
      file = "lib/early_exercise.ml";
      snippet = "positive_part (E.sub (exact mapping_grid.(i)) amount)";
      replacement = "exact mapping_grid.(i)";
      killer = "american_cash";
      mechanism =
        "cash mapping reduces stock and preserves the absorbing zero state";
    };
    {
      id = "american-cash-refinement";
      file = "lib/early_exercise.ml";
      snippet = "Option.fold ~none:true ~some:small ec";
      replacement = "true";
      killer = "american_cash";
      mechanism = "cash mapping must independently demonstrate refinement";
    };
    {
      id = "american-stationary-stopping";
      file = "lib/early_exercise.ml";
      snippet = "| E.Positive, E.Negative -> add root";
      replacement = "| E.Positive, E.Negative -> ()";
      killer = "american_pricing";
      mechanism =
        "deterministic stopping includes admissible interior stationary points";
    };
    {
      id = "american-delayed-opening";
      file = "lib/early_exercise.ml";
      snippet = "slab 0. p.opens_at false";
      replacement = "slab 0. p.opens_at true";
      killer = "american_pricing";
      mechanism = "the obstacle is absent before the exercise window opens";
    };
    {
      id = "native-planner-chunk-offset";
      file = "lib/planner.ml";
      snippet = "first = work.first + !offset";
      replacement = "first = work.first";
      killer = "native_fast_planner";
      mechanism = "private preparation chunks preserve the original tile offset";
    };
    {
      id = "native-planner-order";
      file = "lib/planner.ml";
      snippet = "results.(!next)";
      replacement = "results.(Array.length results - 1 - !next)";
      killer = "native_fast_planner";
      mechanism =
        "native tile outputs retain original indices across expiry and invalid \
         rows";
    };
    {
      id = "native-bachelier-exponent";
      file = "lib/bachelier_operation_graph.h";
      snippet = "T hi=C(0.5)*sq;";
      replacement = "T hi=sq;";
      killer = "native_bachelier_reference";
      mechanism = "native Gaussian exponent retains its half-square scaling";
    };
    {
      id = "native-bachelier-mode";
      file = "lib/bachelier_kernel_stubs.c";
      snippet = "mode<1 || mode>2 ||";
      replacement = "0 ||";
      killer = "native_bachelier";
      mechanism = "native boundary rejects unsupported dispatch modes";
    };
    {
      id = "fast-planner-tile";
      file = "lib/planner.ml";
      snippet = "work <> tile plan work.id";
      replacement = "false";
      killer = "fast_planner";
      mechanism =
        "foreign fast tile identities cannot select another frozen plan";
    };
    {
      id = "fast-planner-side";
      file = "lib/planner.ml";
      snippet = "Batch.Fast.Price (model, inputs, position.side, sigma)";
      replacement = "Batch.Fast.Price (model, inputs, Side.Put, sigma)";
      killer = "fast_planner";
      mechanism = "scenario fast price retains original call/put side";
    };
    {
      id = "fast-batch-finite";
      file = "lib/batch.ml";
      snippet = "if Float.is_finite value && value >= 0.0 then Ok value";
      replacement = "if true then Ok value";
      killer = "fast_batch";
      mechanism = "fast batch must refuse an overflowing scalar price";
    };
    {
      id = "fast-batch-order";
      file = "lib/batch.ml";
      snippet = "| Scalar_batch entries -> Array.map price entries";
      replacement =
        "| Scalar_batch entries -> Array.init (Array.length entries) (fun i -> \
         price entries.(Array.length entries - i - 1))";
      killer = "fast_batch";
      mechanism =
        "compiled fast results preserve original item order and failures";
    };
    {
      id = "exchange-correlation-term";
      file = "lib/exchange.ml";
      snippet = "E.sub (E.exact 1.) (E.exact a.rho)";
      replacement = "E.add (E.exact 1.) (E.exact a.rho)";
      killer = "exchange_reference";
      mechanism = "correlation must subtract in the covariance cross term";
    };
    {
      id = "exchange-rounded-degeneracy";
      file = "lib/exchange.ml";
      snippet =
        "(sigma1 = 0. && sigma2 = 0.) || (a.rho = 1. && sigma1 = sigma2)";
      replacement =
        "(sigma1 *. sigma1 +. sigma2 *. sigma2 -. 2. *. a.rho *. sigma1 *. \
         sigma2) = 0.";
      killer = "exchange_reference";
      mechanism = "rounded covariance must not decide exact degeneracy";
    };
    {
      id = "exchange-discounted-leg-rounding";
      file = "lib/exchange.ml";
      snippet = "    let result =";
      replacement = "    let asset1 = E.exact asset1.hi in\n    let result =";
      killer = "exchange_reference";
      mechanism =
        "discounted legs retain their original-input low words and uncertainty";
    };
    {
      id = "exchange-deliver-yield";
      file = "lib/exchange.ml";
      snippet = "and q2 = a.deliver.dividend_yield in";
      replacement = "and q2 = a.receive.dividend_yield in";
      killer = "exchange_reference";
      mechanism = "reverse exchange swaps complete legs including their yields";
    };
    {
      id = "exchange-certificate-radius";
      file = "lib/exchange.ml";
      snippet = "let absolute_error = E.error_of_float enclosed value in";
      replacement = "let absolute_error = 0. in";
      killer = "exchange_reference";
      mechanism =
        "the certificate includes outward restoration and centering error";
    };
    {
      id = "exchange-accuracy-limit";
      file = "lib/exchange.ml";
      snippet = "else if absolute_error > max_error then";
      replacement = "else if false && absolute_error > max_error then";
      killer = "exchange_reference";
      mechanism =
        "the restored currency error must meet the requested absolute limit";
    };
    {
      id = "rho-quick-zero-threshold";
      file = "lib/black_rho.ml";
      snippet =
        "E.sign (E.sub log_upper (E.mul_float log_two (-1075.0))) = E.Negative";
      replacement =
        "E.sign (E.sub log_upper (E.mul_float log_two 1075.0)) = E.Negative";
      killer = "rho_midpoint";
      mechanism =
        "the cheap proof must compare with the actual half-subnormal threshold";
    };
    {
      id = "rho-tail-exponent";
      file = "lib/black_rho.ml";
      snippet = "-1074 )";
      replacement = "-1073 )";
      killer = "rho_midpoint";
      mechanism =
        "the normalized tail must restore the minimum-subnormal exponent";
    };
    {
      id = "rho-tail-zero-proof";
      file = "lib/black_rho.ml";
      snippet = "if below_zero_cell then";
      replacement = "if false && below_zero_cell then";
      killer = "rho_midpoint";
      mechanism = "a proved underflowed tail must retain its zero rounding cell";
    };
    {
      id = "rho-subnormal-refinement";
      file = "lib/black.ml";
      snippet = "(not c.tied) && Float.abs value <= Float.min_float";
      replacement =
        "false && (not c.tied) && Float.abs value <= Float.min_float";
      killer = "rho_midpoint";
      mechanism = "subnormal rho must retain its original-input rounding cell";
    };
    {
      id = "rho-midpoint-probability";
      file = "lib/black_rho.ml";
      snippet = "Model_enclosure.cdf argument";
      replacement = "E.exact (Model_enclosure.cdf argument).hi";
      killer = "rho_midpoint";
      mechanism =
        "rounding Phi before the scaled product loses midpoint direction";
    };
    {
      id = "smooth-theta-cancellation";
      file = "lib/black.ml";
      snippet = "terms > 0.0 && Float.abs value.hi <= noise";
      replacement = "false && terms > 0.0 && Float.abs value.hi <= noise";
      killer = "greek_cancellation";
      mechanism = "unresolved DD discount-leg subtraction cannot serve theta";
    };
    {
      id = "zero-variance-theta-cancellation";
      file = "lib/black.ml";
      snippet = "theta = Greeks.daily annual_theta;";
      replacement =
        "theta = Greeks.daily (up (on (theta *. ((q *. c.asset) -. (r *. \
         c.cash)))));";
      killer = "greek_cancellation";
      mechanism =
        "zero-variance theta must retain cancelling discount-leg terms";
    };
    {
      id = "cancelled-greek-coordinate";
      file = "lib/black.ml";
      snippet = "needs_coordinate_refinement c\n        ||";
      replacement = "false\n        ||";
      killer = "greek_cancellation";
      mechanism = "exhausted coordinates cannot serve inaccurate finite Greeks";
    };
    {
      id = "underflowed-greek-coordinate";
      file = "lib/black.ml";
      snippet = "c.x = 0.0 && c.x_low = 0.0 && not exact_atm";
      replacement = "false && c.x = 0.0 && c.x_low = 0.0 && not exact_atm";
      killer = "greek_cancellation";
      mechanism = "rounded zero carry is not an exact payoff kink";
    };
    {
      id = "cancelled-price-refinement";
      file = "lib/black.ml";
      snippet = "Float.abs c.x <= noise";
      replacement = "false && Float.abs c.x <= noise";
      killer = "carry_cancellation";
      mechanism = "severe carry cancellation must refine original inputs";
    };
    {
      id = "cancelled-price-cell";
      file = "lib/black.ml";
      snippet = "Enclosure_round.nearest ~exponent enclosed";
      replacement = "Some (Float.ldexp enclosed.hi exponent)";
      killer = "carry_cancellation";
      mechanism = "an unresolved price cell must not serve its expansion centre";
    };
    {
      id = "greek-finite-result";
      file = "lib/greeks.ml";
      snippet = "not (Float.is_finite (number value))";
      replacement = "false && not (Float.is_finite (number value))";
      killer = "finite_greeks";
      mechanism = "nonfinite Greek payloads cannot be successful results";
    };
    {
      id = "intrinsic-nonfinite-price";
      file = "lib/black.ml";
      snippet = "not (Float.is_finite i.hi && Float.is_finite i.lo)";
      replacement =
        "false && not (Float.is_finite i.hi && Float.is_finite i.lo)";
      killer = "finite_greeks";
      mechanism = "unresolved intrinsic cannot become a zero price and rho";
    };
    {
      id = "greek-live-rho-scale";
      file = "lib/black.ml";
      snippet = "Split.product_ldexp [ theta; time; c_part ] e_up";
      replacement = "up (theta *. time *. c_part)";
      killer = "finite_greeks";
      mechanism =
        "live BSM rho retains subnormal maturity until currency scaling";
    };
    {
      id = "greek-zero-rho-scale";
      file = "lib/black.ml";
      snippet = "Split.product_ldexp [ theta; c.cash; time ] e_up";
      replacement = "up (theta *. c.cash *. time)";
      killer = "finite_greeks";
      mechanism =
        "zero-volatility BSM rho retains maturity until currency scaling";
    };
    {
      id = "prepared-quotient-exponent";
      file = "lib/dd.ml";
      snippet =
        "scale (mul numerator divisor.reciprocal) (exponent - divisor.exponent)";
      replacement = "scale (mul numerator divisor.reciprocal) exponent";
      killer = "prepared_division";
      mechanism = "prepared division restores the divisor exponent";
    };
    {
      id = "prepared-reciprocal-residual";
      file = "lib/dd.ml";
      snippet = "let reciprocal = add_float d th in";
      replacement = "let reciprocal = of_float th in";
      killer = "prepared_division";
      mechanism = "prepared reciprocal retains its low-word correction";
    };
    {
      id = "prepared-numerator-scale";
      file = "lib/dd.ml";
      snippet = "else snd (Float.frexp numerator.hi) - 1";
      replacement = "else 0";
      killer = "prepared_division";
      mechanism =
        "prepared division normalizes extreme dividends before the product";
    };
    {
      id = "inverse-iteration-count";
      file = "lib/normal.ml";
      snippet = "let inverse_steps = 6";
      replacement = "let inverse_steps = 2";
      killer = "oracle_normal";
      mechanism = "bounded inverse iteration reaches its accuracy requirement";
    };
    {
      id = "inverse-dd-refinement";
      file = "lib/normal.ml";
      snippet = "if x <= Normal_dd.limit then";
      replacement = "if false then";
      killer = "oracle_normal";
      mechanism =
        "double-word correction preserves sampled inverse monotonicity";
    };
    {
      id = "erfcx-leading-residual";
      file = "lib/cody.ml";
      snippet =
        "coefficients.(0)\n\
        \    +. Float.fma !tail offset Erf_coefficients.local_low.(index)";
      replacement = "Float.fma !tail offset coefficients.(0)";
      killer = "oracle_greeks";
      mechanism = "leading coefficient residual in cancelling BSM theta";
    };
    {
      id = "erfcx-local-degree";
      file = "lib/cody.ml";
      snippet = "let coefficients = Erf_coefficients.local.(index) in";
      replacement =
        "let coefficients = Array.sub Erf_coefficients.local.(index) 0 7 in";
      killer = "oracle_normal";
      mechanism = "generated local erfcx Taylor remainder";
    };
    {
      id = "erfcx-tail-degree";
      file = "lib/cody.ml";
      snippet = "horner Erf_coefficients.tail (inverse *. inverse)";
      replacement =
        "horner (Array.sub Erf_coefficients.tail 0 4) (inverse *. inverse)";
      killer = "oracle_normal";
      mechanism = "Gaussian-integral asymptotic remainder";
    };
    {
      id = "erf-series-degree";
      file = "lib/cody.ml";
      snippet = "horner Erf_coefficients.small (x *. x)";
      replacement = "horner (Array.sub Erf_coefficients.small 0 5) (x *. x)";
      killer = "oracle_normal";
      mechanism = "odd small-erf series remainder";
    };
    {
      id = "erfc-square-split";
      file = "lib/cody.ml";
      snippet = "Split.scaled_exp_neg (erfcx_nonnegative x) hi lo";
      replacement = "Split.scaled_exp_neg (erfcx_nonnegative x) hi 0.0";
      killer = "oracle_normal";
      mechanism = "erfc tail retains the exact square residual";
    };
    {
      id = "planner-snapshot-copy";
      file = "lib/planner.ml";
      snippet =
        "let market = Array.copy market and portfolio = Array.copy portfolio in";
      replacement = "let market = market and portfolio = portfolio in";
      killer = "planner_contract";
      mechanism = "caller mutations cannot change a frozen plan";
    };
    {
      id = "planner-post-expiry";
      file = "lib/planner.ml";
      snippet = "if days < 0L then Expired else prepared";
      replacement = "if false then Expired else prepared";
      killer = "planner_contract";
      mechanism = "post-expiry valuation has an explicit settlement exclusion";
    };
    {
      id = "planner-scalar-radius";
      file = "lib/planner.ml";
      snippet = "(number q v.absolute_error)";
      replacement = "0.0";
      killer = "planner_contract";
      mechanism = "aggregation retains each scalar certificate uncertainty";
    };
    {
      id = "planner-incomplete-total";
      file = "lib/planner.ml";
      snippet = "complete = s.failed = 0 && Option.is_some successful_subset;";
      replacement = "complete = Option.is_some successful_subset;";
      killer = "planner_contract";
      mechanism = "failed items prevent complete portfolio totals";
    };
    {
      id = "greek-eager-inverse-time";
      file = "lib/model_enclosure.ml";
      snippet = "let half_inverse_time = lazy (E.div (E.exact 0.5) t) in";
      replacement =
        "let half_inverse_time = lazy (E.div (E.exact 0.5) t) in ignore \
         (Lazy.force half_inverse_time);";
      killer = "shared_greeks";
      mechanism =
        "unrequested derivative arithmetic cannot reject independent ATM vega";
    };
    {
      id = "multi-output-limit";
      file = "lib/production.ml";
      snippet =
        "evaluate_with ~greek prepare_model admitted side sigma quantity\n\
        \              ~max_error";
      replacement =
        "evaluate_with ~greek prepare_model admitted side sigma quantity \
         ~max_error:(label quantity Float.max_float)";
      killer = "production_multi";
      mechanism = "each grouped output retains its own typed acceptance limit";
    };
    {
      id = "production-accuracy-limit";
      file = "lib/production.ml";
      snippet = "else if absolute_error > limit then Error Accuracy_exceeded";
      replacement = "else if false then Error Accuracy_exceeded";
      killer = "production_boundary";
      mechanism = "a computed certificate must meet the requested accuracy";
    };
    {
      id = "production-certificate-radius";
      file = "lib/production.ml";
      snippet = "let absolute_error = E.error_of_float enclosed value in";
      replacement = "let absolute_error = 0.0 in";
      killer = "production_reference";
      mechanism = "the served leading word retains its actual absolute error";
    };
    {
      id = "production-rho-coordinate";
      file = "lib/model_enclosure.ml";
      snippet = "if rho_forward then forward_rho ()";
      replacement = "if true then forward_rho ()";
      killer = "production_greek_reference";
      mechanism = "BSM rho holds yield fixed even when its value equals rate";
    };
    {
      id = "production-time-unit";
      file = "lib/model_enclosure.ml";
      snippet = "let daily v = E.div_float v Units.days_per_year in";
      replacement = "let daily v = v in";
      killer = "production_greek_reference";
      mechanism = "runtime Greek certificates retain per-calendar-day units";
    };
    {
      id = "zero-variance-black-time";
      file = "lib/black.ml";
      snippet =
        "theta = (if smooth_time then Greeks.daily 0.0 else Greeks.kink);";
      replacement = "theta = Greeks.kink;";
      killer = "boundary_greeks";
      mechanism = "a spot payoff kink does not erase a smooth time derivative";
    };
    {
      id = "zero-variance-normal-rho";
      file = "lib/bachelier.ml";
      snippet = "rho = Ok 0.0;";
      replacement = "rho = Greeks.kink;";
      killer = "boundary_greeks";
      mechanism = "ATM zero-variance forward rho exists and is zero";
    };
    {
      id = "zero-variance-veta";
      file = "lib/boundary_greeks.ml";
      snippet = "rounded (E.div_float annual Units.days_per_year)";
      replacement = "let _ = annual in Ok 0.0";
      killer = "boundary_greeks";
      mechanism = "the maturity derivative of right vega is generally nonzero";
    };
    {
      id = "enclosure-product-guard";
      file = "lib/enclosure.ml";
      snippet = "abs a >= 0x1p-485 && abs b >= 0x1p-485";
      replacement = "abs a >= 0x1p-600 && abs b >= 0x1p-600";
      killer = "enclosure_reference";
      mechanism =
        "the product shortcut must imply a representable residual quantum";
    };
    {
      id = "iv-certification-refinement";
      file = "lib/adaptive_iv.ml";
      snippet = "Full.run inputs side ~quote ~proposal";
      replacement = "Certified_iv.Numerical_failure";
      killer = "oracle_iv";
      mechanism =
        "an inconclusive first certificate must retain full-evaluator \
         availability";
    };
    {
      id = "enclosure-interpolation-prefix";
      file = "lib/enclosure.ml";
      snippet =
        "pack_array terms (na + 2) (a.error +^ 0.0)\n\n  let sub_float a b";
      replacement =
        "pack_array terms (Float.Array.length terms) (a.error +^ 0.0)\n\n\
        \  let sub_float a b";
      killer = "enclosure_interpolation";
      mechanism = "interpolation subtraction must exclude stale packing slots";
    };
    {
      id = "enclosure-interpolation-complement";
      file = "lib/enclosure.ml";
      snippet = "(sub_using allocate (exact 1.) weight)";
      replacement = "weight";
      killer = "enclosure_interpolation";
      mechanism = "linear interpolation retains the complementary left weight";
    };
    {
      id = "enclosure-exponential-prefix";
      file = "lib/enclosure.ml";
      snippet =
        "pack_array terms (na + nb) (a.error +^ b.error)\n\n\
        \  let[@inline always] add";
      replacement =
        "pack_array terms (Float.Array.length terms) (a.error +^ b.error)\n\n\
        \  let[@inline always] add";
      killer = "enclosure_exponential";
      mechanism =
        "exponential scratch packing must exclude stale terms beyond the used \
         prefix";
    };
    {
      id = "enclosure-series-tail";
      file = "lib/enclosure.ml";
      snippet = "let result = ref (add_error !sum tail) in";
      replacement = "let result = ref (let _ = tail in !sum) in";
      killer = "enclosure_reference";
      mechanism =
        "the cheaper exponential cannot discard its analytical truncation \
         remainder";
    };
    {
      id = "certified-rounding-cell";
      file = "lib/certified_iv.ml";
      snippet = "if rounding_cell proposal then Root proposal";
      replacement = "if true then Root proposal";
      killer = "certified_iv_reference";
      mechanism = "a proposal cannot bypass exact-model rounding acceptance";
    };
    {
      id = "enclosure-sum-order";
      file = "lib/enclosure.ml";
      snippet = "if abs a >= abs b then b -. (s -. a) else a -. (s -. b)";
      replacement = "b -. (s -. a)";
      killer = "enclosure_sum";
      mechanism = "FastTwoSum requires the larger-magnitude operand first";
    };
    {
      id = "enclosure-sum-finite";
      file = "lib/enclosure.ml";
      snippet = "finite low;";
      replacement = "();";
      killer = "enclosure_sum";
      mechanism =
        "an overflowing sum must refuse rather than return an enclosure";
    };
    {
      id = "enclosure-grow-residual";
      file = "lib/enclosure.ml";
      snippet = "if residual <> 0.0 then (";
      replacement = "if false && residual <> 0.0 then (";
      killer = "enclosure_reference";
      mechanism = "grow-expansion retains every nonzero TwoSum residual";
    };
    {
      id = "enclosure-packed-word";
      file = "lib/enclosure.ml";
      snippet = "fourth = retained 3;";
      replacement = "fourth = 0.0;";
      killer = "enclosure_reference";
      mechanism = "a fixed enclosure slot cannot silently lose a retained word";
    };
    {
      id = "enclosure-normal-exponent";
      file = "lib/enclosure.ml";
      snippet = "else field - 1022";
      replacement = "else field - 1021";
      killer = "enclosure_reference";
      mechanism =
        "normal frexp exponent decoding must preserve the product quantum bound";
    };
    {
      id = "enclosure-discarded-word";
      file = "lib/enclosure.ml";
      snippet = "error := !error +^ abs x";
      replacement = "error := !error";
      killer = "enclosure_reference";
      mechanism = "discarded expansion words remain in the absolute radius";
    };
    {
      id = "iv-original-shift";
      file = "lib/black.ml";
      snippet = "original_spot_low = spot_low;";
      replacement = "original_spot_low = 0.0;";
      killer = "iv_termination";
      mechanism = "classification retains original sparse shifted input words";
    };
    {
      id = "model-normalization";
      file = "lib/model_enclosure.ml";
      snippet = "let inv_sqrt_2pi = E.div one (E.sqrt (E.mul_float pi 2.0))";
      replacement = "let inv_sqrt_2pi = E.exact 0.3989422804014327";
      killer = "enclosure_reference";
      mechanism = "normalization constant requires an enclosure of its low bits";
    };
    {
      id = "enclosure-fma-underflow";
      file = "lib/enclosure.ml";
      snippet = "let error = if ea + eb >= -968 then 0.0 else quantum in";
      replacement = "let error = if ea + eb >= -968 then 0.0 else 0.0 in";
      killer = "enclosure_reference";
      mechanism =
        "a fused product residual can underflow and is not always exact";
    };
    {
      id = "iv-iteration-cap";
      file = "lib/iv_iteration.ml";
      snippet = "else if n >= max_iterations then Error Non_convergence";
      replacement = "else if n >= max_iterations then Ok candidate";
      killer = "iv_termination";
      mechanism = "iteration exhaustion cannot manufacture a root";
    };
    {
      id = "iv-nonfinite-value";
      file = "lib/iv_iteration.ml";
      snippet =
        "let v = value candidate in\n\
        \          if not (Float.is_finite v) then Error Numerical_failure";
      replacement =
        "let v = value candidate in\n\
        \          if not (Float.is_finite v) then Ok candidate";
      killer = "iv_termination";
      mechanism = "nonfinite evaluator output is an arithmetic failure";
    };
    {
      id = "split-root-nonoverlap";
      file = "lib/split.ml";
      snippet = "let hi, lo = (sum, lo -. (sum -. hi)) in";
      replacement = "let hi, lo = (hi, lo) in";
      killer = "dd_reference";
      mechanism = "normalize the square-root correction before DD consumers";
    };
    {
      id = "dd-scale-nonoverlap";
      file = "lib/dd.ml";
      snippet =
        "if lo <> 0.0 && Float.abs lo < Float.min_float && Float.is_finite hi \
         then";
      replacement = "if false then";
      killer = "dd_reference";
      mechanism = "restore DD nonoverlap after subnormal low-word scaling";
    };
    {
      id = "scaled-exp-prefactor";
      file = "lib/split.ml";
      snippet = "(1077.0 +. float (ceiling_exponent + k)) *. ln2_hi";
      replacement = "(1100.0 +. float k) *. ln2_hi";
      killer = "numerical_regressions";
      mechanism = "a large prefactor rescues a representable exponential tail";
    };
    {
      id = "split-root-scale";
      file = "lib/split.ml";
      snippet = "else (snd (Float.frexp t) - 1) asr 1";
      replacement = "else 0";
      killer = "dd_reference";
      mechanism = "retain the square-root residual for extreme maturities";
    };
    {
      id = "split-quotient-scale";
      file = "lib/split.ml";
      snippet =
        "let en = snd (Float.frexp n) - 1 and ed = snd (Float.frexp d) - 1 in";
      replacement = "let en = 0 and ed = 0 in";
      killer = "dd_reference";
      mechanism =
        "normalize the compensated quotient before taking its residual";
    };
    {
      id = "split-quotient-nonoverlap";
      file = "lib/split.ml";
      snippet = "(hi, r -. (hi -. q))";
      replacement = "(q, r)";
      killer = "dd_reference";
      mechanism =
        "normalize the two quotient words before DD consumers use them";
    };
    {
      id = "ulp-distance-overflow";
      file = "test/float_score.ml";
      snippet = "Z.abs (Z.sub (rank a) (rank b))";
      replacement =
        "Z.of_int64 (Int64.abs (Int64.sub (Z.to_int64 (rank a)) (Z.to_int64 \
         (rank b))))";
      killer = "oracle_assurance";
      mechanism = "finite ULP distances cannot wrap signed 64-bit subtraction";
    };
    {
      id = "reference-expansion";
      file = "test/bounds.ml";
      snippet =
        "Float.abs (List.fold_left ( +. ) 0.0 (List.fold_left grow [] terms))";
      replacement = "let _ = grow in Float.abs (List.fold_left (+.) 0.0 terms)";
      killer = "numerical_regressions";
      mechanism =
        "reference discrepancy retains cancellation between high and low words";
    };
    {
      id = "sqrt-exponent-scale";
      file = "lib/dd.ml";
      snippet = "else (snd (Float.frexp a.hi) - 1) asr 1";
      replacement = "else 0";
      killer = "dd_reference";
      mechanism = "even-exponent normalization before the square-root residual";
    };
    {
      id = "intrinsic-coordinate-scale";
      file = "lib/black.ml";
      snippet =
        "if x.hi <> 0.0 && Float.abs x.hi < 0x1p-500 && x_terms <= 1.0 then";
      replacement = "if false then";
      killer = "numerical_regressions";
      mechanism =
        "retain a tiny displaced spread before restoring the currency scale";
    };
    {
      id = "rho-ulp-propagation";
      file = "test/bounds.ml";
      snippet =
        "(Float.abs time *. price_error) +. (0.5 *. ulp got) +. (0.5 *. ulp \
         reference)";
      replacement =
        "let _ = time, price_error, got in (budget +. 1.0) *. ulp reference";
      killer = "numerical_regressions";
      mechanism = "price ULP counts do not survive multiplication by T";
    };
    {
      id = "quotient-remainder";
      file = "lib/black.ml";
      snippet =
        "Dd.add (Dd.log_float q) (Dd.sub rho (Dd.mul_float (Dd.mul rho rho) \
         0.5))";
      replacement =
        "let rho = Dd.of_float (Dd.to_float rho) in\n\
        \      Dd.add (Dd.log_float q) (Dd.sub rho (Dd.mul_float (Dd.mul rho \
         rho) 0.5))";
      killer = "numerical_regressions";
      mechanism = "double-word quotient remainder near unit spot/strike ratios";
    };
    {
      id = "division-numerator-scale";
      file = "lib/dd.ml";
      snippet = "else snd (Float.frexp a.hi) - 1";
      replacement = "else 0";
      killer = "dd_reference";
      mechanism = "normalise the dividend before the reciprocal product";
    };
    {
      id = "expm1-tiny";
      file = "lib/dd.ml";
      snippet = "if Float.abs r.hi < 0x1p-104 then r";
      replacement = "if Float.abs r.hi < 0x1p-104 then of_float 0.0";
      killer = "dd_reference";
      mechanism = "retain the nonzero tiny expm1 result";
    };
    {
      id = "intrinsic-tiny-carry";
      file = "lib/black.ml";
      snippet = "c.spot = c.strike && c.spot_low = c.strike_low";
      replacement = "false && c.spot = c.strike && c.spot_low = c.strike_low";
      killer = "numerical_regressions";
      mechanism = "carry below the exponent range, restored at currency scale";
    };
    {
      id = "dd-reference-nan";
      file = "test/dd_reference.ml";
      snippet = "let e = error got exponent (f h) (f l) (f tail) in";
      replacement =
        "let _ = got in let e = error (Dd.of_float Float.nan) exponent (f h) \
         (f l) (f tail) in";
      killer = "dd_reference";
      mechanism = "nonfinite component outputs must fail the DD scorer";
    };
    {
      id = "floor-exponent";
      file = "lib/black.ml";
      snippet = "(snd (Float.frexp spot) + snd (Float.frexp strike)) asr 1";
      replacement = "(snd (Float.frexp spot) + snd (Float.frexp strike)) / 2";
      killer = "properties";
      mechanism = "floor-divided scale exponent (exact homogeneity)";
    };
    {
      id = "intrinsic-expm1";
      file = "lib/black.ml";
      snippet =
        "if Float.abs c.x <= 0.35 && c.x_terms <= 1.0 then Dd.mul cash \
         (Dd.expm1 x)";
      replacement = "if false then Dd.mul cash (Dd.expm1 x)";
      killer = "oracle_price";
      mechanism = "near-the-money intrinsic as C expm1(x)";
    };
    {
      id = "root-time-low";
      file = "lib/black.ml";
      snippet = "root_time_low = snd (Split.sqrt time);";
      replacement = "root_time_low = 0.0;";
      killer = "oracle_price";
      mechanism = "sqrt T, and so s = sigma sqrt T, in double-double";
    };
    {
      id = "subnormal-rounding";
      file = "lib/dd.ml";
      snippet =
        "if Float.abs v >= Float.min_float || a.hi = 0.0 || not \
         (Float.is_finite v)";
      replacement = "if true";
      killer = "test_morphiq_risk";
      mechanism = "one rounding into the subnormals (Dd.to_float_scaled)";
    };
    {
      id = "displaced-exact-sum";
      file = "lib/black.ml";
      snippet =
        "let f, fl = Split.two_sum i.forward i.displacement\n\
        \          and k, kl = Split.two_sum i.strike i.displacement in";
      replacement =
        "let f, fl = (i.forward +. i.displacement, 0.0)\n\
        \          and k, kl = (i.strike +. i.displacement, 0.0) in";
      killer = "oracle_price";
      mechanism = "displaced Black on the exact sums F + d, K + d";
    };
    {
      id = "bachelier-distance";
      file = "lib/bachelier.ml";
      snippet = "Split.two_sum i.forward (-.i.strike)";
      replacement = "(i.forward -. i.strike, 0.0)";
      killer = "oracle_price";
      mechanism = "Bachelier F - K with its remainder";
    };
    {
      id = "gaussian-split";
      file = "lib/normal.ml";
      snippet = "Split.scaled_exp_neg scale (0.5 *. hi) (0.5 *. lo)";
      replacement = "Split.scaled_exp_neg scale (0.5 *. hi) 0.0";
      killer = "oracle_normal";
      mechanism = "exact split of u^2 in exp(-u^2/2)";
    };
    {
      id = "log1p-remainder";
      file = "lib/elementary.ml";
      snippet = "let d, dl = two_sum 2.0 f in";
      replacement = "let d, dl = (2.0 +. f, 0.0) in";
      killer = "oracle_elementary";
      mechanism = "log1p's quotient remainder";
    };
    {
      id = "dd-exp-accumulator-low";
      file = "lib/dd.ml";
      snippet = "      lo := acc.lo\n    done;\n    let acc";
      replacement = "      lo := 0.0\n    done;\n    let acc";
      killer = "dd_reference";
      mechanism = "exponential Horner retains both accumulator words";
    };
    {
      id = "dd-log-accumulator-low";
      file = "lib/dd.ml";
      snippet = "    lo := acc.lo\n  done;\n  mul_float";
      replacement = "    lo := 0.0\n  done;\n  mul_float";
      killer = "dd_reference";
      mechanism = "logarithm Horner retains both accumulator words";
    };
    {
      id = "dd-exp-degree";
      file = "lib/dd.ml";
      snippet =
        "let initial = exp_coefficients.(21) in\n\
        \    let hi = ref initial.hi and lo = ref initial.lo in\n\
        \    for k = 20 downto 2 do";
      replacement =
        "let initial = exp_coefficients.(11) in\n\
        \    let hi = ref initial.hi and lo = ref initial.lo in\n\
        \    for k = 10 downto 2 do";
      killer = "dd_reference";
      mechanism = "degree-22 Taylor remainder in the double-word exponential";
    };
    {
      id = "normal-dd-series";
      file = "lib/normal_dd.ml";
      snippet = "Float.abs term.Dd.hi <= 0x1p-110 *. Float.abs acc.Dd.hi";
      replacement = "Float.abs term.Dd.hi <= 0x1p-60 *. Float.abs acc.Dd.hi";
      killer = "normal_dd_reference";
      mechanism = "Marsaglia's series to double-double precision";
    };
    {
      id = "iv-complement-correction";
      file = "lib/black.ml";
      snippet = "else if beta > 0.5 *. b_max then";
      replacement = "else if false then";
      killer = "numerical_regressions";
      mechanism = "the final Newton step on the complement near the maximum";
    };
    {
      id = "greeks-theta-dd";
      file = "lib/black.ml";
      snippet =
        "if\n\
        \        Float.abs d1_dd.Dd.hi <= Normal_dd.limit\n\
        \        && Float.abs d2_dd.Dd.hi <= Normal_dd.limit\n\
        \      then";
      replacement = "if false then";
      killer = "oracle_greeks";
      mechanism = "Black theta in double-double near the money";
    };
    {
      id = "greeks-charm-dd";
      file = "lib/black.ml";
      snippet = "if Float.abs d1_dd.Dd.hi <= Normal_dd.limit then charm_dd ()";
      replacement = "if false then charm_dd ()";
      killer = "oracle_greeks";
      mechanism = "Black charm's bracket in double-double";
    };
    {
      id = "greeks-veta-bracket";
      file = "lib/black.ml";
      snippet =
        "(Dd.sub (Dd.mul q_plus_d1_w rt_dd) (Dd.div (Dd.of_float 0.5) rt_dd))";
      replacement =
        "(Dd.of_float ((Dd.to_float q_plus_d1_w *. rt) -. (0.5 /. rt)))";
      killer = "oracle_greeks";
      mechanism = "veta's sqrt(T)-scaled bracket in double-double";
    };
    {
      id = "bachelier-theta-dd";
      file = "lib/bachelier.ml";
      snippet =
        "if Float.abs dh <= Normal_dd.limit then\n\
        \            let d_dd = { Dd.hi = dh; lo = dl } in";
      replacement =
        "if false then\n            let d_dd = { Dd.hi = dh; lo = dl } in";
      killer = "oracle_greeks";
      mechanism = "Bachelier theta in double-double near the money";
    };
  ]

(* Keep the required PR workload small. This is a sentinel set, not exhaustive
   coverage: shared DD preconditions, independent scoring, exponent rescue,
   inverse conditioning and cancellation in both model families. The complete
   catalog remains a separate manual/scheduled assurance run. *)
let core_ids =
  [
    "split-root-nonoverlap";
    "dd-scale-nonoverlap";
    "reference-expansion";
    "scaled-exp-prefactor";
    "certified-rounding-cell";
    "greeks-theta-dd";
    "bachelier-theta-dd";
  ]

let core_catalog () =
  List.map
    (fun id ->
      match List.filter (fun m -> m.id = id) catalog with
      | [ m ] -> m
      | _ -> failwith ("core mutant missing or ambiguous: " ^ id))
    core_ids

(* Diagnostic only: a survivor is recorded, never called impossible to kill.
   Run with --probe intrinsic-terms; exit 1 means a compiled survivor. *)
let probes =
  [
    {
      id = "iv-maximum-error";
      file = "test/iv_bounds.ml";
      snippet = "u +. (e_max /. gap_lower)";
      replacement = "u +. (0.0 /. gap_lower)";
      killer = "numerical_regressions";
      mechanism = "maximum-leg error amplified by the complement gap";
    };
    {
      id = "bachelier-iv-quantum";
      file = "test/iv_bounds.ml";
      snippet = "+. 0x1p-1074 in";
      replacement = "+. 0.0 in";
      killer = "oracle_iv";
      mechanism = "absolute rounding error for subnormal Bachelier quotes";
    };
    {
      id = "iv-rounded-bound";
      file = "lib/black.ml";
      snippet = "if p = intrinsic.hi then root 0.0 else Iv.Below_intrinsic";
      replacement = "if false then root 0.0 else Iv.Below_intrinsic";
      killer = "oracle_iv";
      mechanism = "a quote equal to the rounded intrinsic is sigma = 0 (#448)";
    };
    {
      id = "iv-beta-bar";
      file = "lib/black.ml";
      snippet = "Dd.to_float (Dd.div (Dd.sub maximum (Dd.of_float p)) m_dd)";
      replacement = "Elementary.exp (0.5 *. x) -. beta";
      killer = "oracle_iv";
      mechanism = "beta-bar from the exact distance to the maximum";
    };
    {
      id = "iv-ln-beta";
      file = "lib/black.ml";
      snippet =
        "(if intrinsic.hi > 0.0 then Elementary.log (Dd.to_float otm)\n\
        \         else Elementary.log price -. (float c.exponent *. \
         Split.ln2_hi))\n\
        \        -. Elementary.log m";
      replacement = "Elementary.log beta";
      killer = "oracle_iv";
      mechanism = "ln beta from the unscaled quote";
    };
    {
      id = "intrinsic-terms";
      file = "lib/black.ml";
      snippet =
        "if Float.abs c.x <= 0.35 && c.x_terms <= 1.0 then Dd.mul cash \
         (Dd.expm1 x)";
      replacement = "if Float.abs c.x <= 0.35 then Dd.mul cash (Dd.expm1 x)";
      killer = "oracle_price";
      mechanism =
        "intrinsic branch guard; current end-to-end corpus may not distinguish \
         it";
    };
  ]

(* Process plumbing. *)

(* A dune started from [dune exec] inherits variables that tell it it is
   nested; the child builds an independent tree, so they are dropped. *)
let child_env () =
  Unix.environment () |> Array.to_list
  |> List.filter (fun v ->
         not
           (String.starts_with ~prefix:"INSIDE_DUNE=" v
           || String.starts_with ~prefix:"DUNE_" v))
  |> Array.of_list

(* Runs [prog args] in [cwd]; returns the exit code and combined output. *)
let run ~cwd prog args =
  let log = Filename.temp_file "mutation" ".log" in
  let fd = Unix.openfile log [ O_WRONLY; O_TRUNC ] 0o600 in
  let previous = Sys.getcwd () in
  Sys.chdir cwd;
  let pid =
    Unix.create_process_env prog
      (Array.of_list (prog :: args))
      (child_env ()) Unix.stdin fd fd
  in
  Sys.chdir previous;
  Unix.close fd;
  let _, status = Unix.waitpid [] pid in
  let output = In_channel.with_open_bin log In_channel.input_all in
  Sys.remove log;
  let code =
    match status with WEXITED c -> c | WSIGNALED _ | WSTOPPED _ -> 255
  in
  (code, output)

let dune ~cwd args =
  run ~cwd "dune" (args @ [ "--root"; "."; "--profile"; "mutation" ])

let rec mkdir_p dir =
  if not (Sys.file_exists dir) then (
    mkdir_p (Filename.dirname dir);
    Sys.mkdir dir 0o755)

let read path = In_channel.with_open_bin path In_channel.input_all

let write path text =
  Out_channel.with_open_bin path (fun oc -> output_string oc text)

(* The tracked files, copied into a fresh directory. *)
let copy_tree root =
  let code, listing = run ~cwd:root "git" [ "ls-files" ] in
  if code <> 0 then failwith "git ls-files failed";
  let dest = Filename.temp_dir "mutation" "" in
  String.split_on_char '\n' listing
  |> List.iter (fun name ->
         if name <> "" then (
           let target = Filename.concat dest name in
           mkdir_p (Filename.dirname target);
           write target (read (Filename.concat root name))));
  dest

(* Occurrences of [needle] in [hay]. *)
let count needle hay =
  let n = String.length needle and m = String.length hay in
  let rec go i acc =
    if i > m - n then acc
    else if String.sub hay i n = needle then go (i + n) (acc + 1)
    else go (i + 1) acc
  in
  if n = 0 then 0 else go 0 0

let replace needle by hay =
  let n = String.length needle in
  let rec find i = if String.sub hay i n = needle then i else find (i + 1) in
  let i = find 0 in
  String.sub hay 0 i ^ by ^ String.sub hay (i + n) (String.length hay - i - n)

(* Mirror each designated test's ordinary action, including both price files.
   Missing mappings or fixtures fail before any mutant is scored. Native
   executables avoid an ambient bytecode DLL search-path dependency. *)
let guard_arguments = function
  | "american_iv" -> [ [ "american_iv" ] ]
  | "american_certification" -> [ [ "american_certification" ] ]
  | "exchange_reference" -> [ [ "exchange_reference" ] ]
  | "oracle_price" -> [ [ "european" ]; [ "displaced" ] ]
  | "native_bachelier_reference" -> [ [ "european"; "displaced" ] ]
  | "native_bachelier" | "native_fast_planner" -> [ [] ]
  | "oracle_iv" | "certified_iv_reference" -> [ [ "iv" ] ]
  | "enclosure_reference" | "dd_reference" -> [ [ "dd" ] ]
  | "oracle_normal" -> [ [ "normal" ] ]
  | "oracle_elementary" -> [ [ "elementary" ] ]
  | "oracle_greeks" -> [ [ "greeks" ] ]
  | "boundary_greeks" -> [ [ "boundary_greeks" ] ]
  | "production_reference" -> [ [ "greek_bits"; "model_enclosures" ] ]
  | "production_greek_reference" -> [ [ "greek_bits" ] ]
  | "fast_planner" | "fast_batch" | "enclosure_sum" | "enclosure_scalar"
  | "enclosure_exponential" | "shared_greeks" | "production_boundary"
  | "production_multi" | "planner_contract" | "prepared_division"
  | "carry_cancellation" | "greek_cancellation" | "rho_midpoint"
  | "american_pricing" | "american_cash" | "bermudan" | "american_piecewise"
  | "american_greeks" | "american_greek_reuse" | "american_residual"
  | "american_policy" | "american_work_order" | "american_compiled" ->
      [ [] ]
  | "enclosure_interpolation" -> [ [] ]
  | "terminal_cash" -> [ [ "terminal_cash" ] ]
  | "finite_greeks" -> [ [ "finite_greeks" ] ]
  | "numerical_regressions" -> [ [ "regressions" ] ]
  | "oracle_assurance" | "iv_termination" | "normal_dd_reference" | "properties"
  | "test_morphiq_risk" ->
      [ [] ]
  | name -> failwith ("no explicit mutation guard action for " ^ name)

type guard_result = Passed | Rejected of string | Invalid of string

let guard ~cwd name =
  let executable = "_build/default/test/" ^ name ^ ".exe" in
  let actions =
    List.map
      (List.map (fun fixture ->
           if fixture = "american_iv" then
             "_build/default/docs/evidence/american-iv/references.tsv"
           else if fixture = "american_certification" then
             "_build/default/docs/evidence/american-certification/reference-v2/references.tsv"
           else if fixture = "terminal_cash" then
             "_build/default/docs/evidence/american-forward-optimization/reference-v1/references.tsv"
           else if fixture = "exchange_reference" then
             "_build/default/test/exchange_reference.tsv"
           else "_build/default/oracle/fixtures/" ^ fixture ^ ".txt"))
      (guard_arguments name)
  in
  if
    not
      (List.for_all
         (fun file -> Sys.file_exists (Filename.concat cwd file))
         (executable :: List.concat actions))
  then Invalid ("missing executable/fixture for " ^ name)
  else
    (* This guard excludes replay identity from its kill criterion. The option
       is not a fixture and does not weaken executable/fixture preflight. *)
    let options =
      if name = "enclosure_interpolation" then [ "--numerical-only" ] else []
    in
    let results =
      List.map
        (fun fixtures -> run ~cwd executable (options @ fixtures))
        actions
    in
    if
      List.exists (fun (code, _) -> code <> 0 && code <> 1 && code <> 2) results
    then Invalid ("guard did not finish normally: " ^ name)
    else
      match List.find_opt (fun (code, _) -> code <> 0) results with
      | None -> Passed
      | Some (_, output) -> Rejected output

(* Symbolic links (dune's _build/.../latest) are removed, not followed. *)
let rec remove_tree path =
  if (Unix.lstat path).st_kind = Unix.S_DIR then (
    Array.iter
      (fun f -> remove_tree (Filename.concat path f))
      (Sys.readdir path);
    Sys.rmdir path)
  else Sys.remove path

let guard_controls () =
  List.iter (fun m -> ignore (guard_arguments m.killer)) (catalog @ probes);
  let work = Filename.temp_dir "mutation-guard-controls" "" in
  Fun.protect
    ~finally:(fun () -> remove_tree work)
    (fun () ->
      let dir = Filename.concat work "_build/default/test" in
      mkdir_p dir;
      let script name body =
        let path = Filename.concat dir (name ^ ".exe") in
        write path ("#!/bin/sh\n" ^ body ^ "\n");
        Unix.chmod path 0o700
      in
      let check message ok = if not ok then failwith message in
      check "missing guard was accepted"
        (match guard ~cwd:work "iv_termination" with
        | Invalid _ -> true
        | _ -> false);
      script "iv_termination" "exit 0";
      check "passing guard was rejected"
        (guard ~cwd:work "iv_termination" = Passed);
      List.iter
        (fun code ->
          script "iv_termination" ("exit " ^ string_of_int code);
          check "completed rejecting guard was not recorded"
            (match guard ~cwd:work "iv_termination" with
            | Rejected _ -> true
            | _ -> false))
        [ 1; 2 ];
      script "iv_termination" "exit 3";
      check "reference input error was called a kill"
        (match guard ~cwd:work "iv_termination" with
        | Invalid _ -> true
        | _ -> false);
      script "iv_termination" "kill -TERM $$";
      check "signalled guard was called a kill"
        (match guard ~cwd:work "iv_termination" with
        | Invalid _ -> true
        | _ -> false);
      script "oracle_iv" "exit 1";
      check "missing fixture was called a kill"
        (match guard ~cwd:work "oracle_iv" with
        | Invalid _ -> true
        | _ -> false);
      script "enclosure_interpolation"
        "[ \"$#\" = 1 ] && [ \"$1\" = --numerical-only ]";
      check "interpolation numerical-only argument was not passed"
        (guard ~cwd:work "enclosure_interpolation" = Passed);
      print_endline "mutation guard controls pass")

let score work m =
  let path = Filename.concat work m.file in
  let source = read path in
  match count m.snippet source with
  | 1 ->
      write path (replace m.snippet m.replacement source);
      Fun.protect
        ~finally:(fun () -> write path source)
        (fun () ->
          match dune ~cwd:work [ "build" ] with
          | c, _ when c <> 0 ->
              Error (Printf.sprintf "INVALID   %s: does not compile" m.id)
          | _ -> (
              match guard ~cwd:work m.killer with
              | Passed ->
                  Error (Printf.sprintf "SURVIVED  %s: %s" m.id m.mechanism)
              | Invalid why ->
                  Error (Printf.sprintf "INVALID   %s: %s" m.id why)
              | Rejected _ ->
                  Ok (Printf.sprintf "killed    %s by %s" m.id m.killer)))
  | n ->
      Error
        (Printf.sprintf "STALE     %s: snippet occurs %d times in %s" m.id n
           m.file)

let () =
  let args = List.tl (Array.to_list Sys.argv) in
  if args = [ "--self-test" ] then (
    guard_controls ();
    exit 0);
  let args, catalog =
    match args with
    | "--probe" :: rest -> (rest, probes)
    | "--core" :: rest -> (rest, core_catalog ())
    | _ -> (args, catalog)
  in
  if args = [ "--list" ] then
    List.iter
      (fun m ->
        Printf.printf "%-26s %-20s %-20s %s\n" m.id m.file m.killer m.mechanism)
      catalog
  else
    let unknown =
      List.filter (fun a -> not (List.exists (fun m -> m.id = a) catalog)) args
    in
    if unknown <> [] then (
      prerr_endline ("unknown mutants: " ^ String.concat ", " unknown);
      exit 2);
    let selected =
      if args = [] then catalog
      else List.filter (fun m -> List.mem m.id args) catalog
    in
    (* dune exec runs from the workspace root. *)
    let work = copy_tree (Sys.getcwd ()) in
    let status =
      Fun.protect
        ~finally:(fun () -> remove_tree work)
        (fun () ->
          let start = Unix.gettimeofday () in
          match dune ~cwd:work [ "test" ] with
          | c, output when c <> 0 ->
              print_endline
                "baseline fails under the mutation profile; fix it before \
                 scoring mutants";
              print_string output;
              1
          | _ ->
              Printf.printf "baseline passes (%.0f s)\n%!"
                (Unix.gettimeofday () -. start);
              (* Establish that the direct actions start and pass with the
                 very same arguments before attributing a failure to mutation. *)
              List.map (fun m -> m.killer) selected
              |> List.sort_uniq compare
              |> List.iter (fun name ->
                     match guard ~cwd:work name with
                     | Passed -> ()
                     | Rejected output ->
                         failwith
                           ("direct baseline guard failed: " ^ name ^ "\n"
                          ^ output)
                     | Invalid why -> failwith why);
              let bad =
                List.fold_left
                  (fun bad m ->
                    match score work m with
                    | Ok line ->
                        print_endline line;
                        flush stdout;
                        bad
                    | Error line ->
                        print_endline line;
                        flush stdout;
                        bad + 1)
                  0 selected
              in
              Printf.printf "%d of %d mutants killed as catalogued\n"
                (List.length selected - bad)
                (List.length selected);
              if bad = 0 then 0 else 1)
    in
    exit status
