import json
from pathlib import Path
R=Path('/tmp/morphiq-american-cash-interpolation');E=Path('/tmp/morphiq-american-cash-evidence/repeat')
repeat=json.loads((E/'summary.json').read_text());m=json.loads((E/'manifest.json').read_text())
s=json.loads((E.parent/'pooled.json').read_text())
adopt=repeat['criteria_pass'] and s['criteria_pass']
for row in s['american'].values():
 for v in ('baseline','candidate'):
  row[v]['time']={method:{'wall_s':stats} for method,stats in row[v]['time'].items()}
runs=[json.loads(x.read_text()) for folder in (E,E.parent/'campaign') for x in folder.glob('[0-4]-*.json')]
loads=[x for r in runs for x in (r['load_before'][0],r['load_after'][0])]
def timing(v,method):
 t=v['time'][method]['wall_s'];return f"{1000*t['median']:.3f} ({1000*t['minimum']:.3f}–{1000*t['maximum']:.3f})"
labels={'call':'Analytical call','flat':'Flat put','cash':'Cash put','bermudan':'Bermudan with cash','piecewise':'Piecewise','piecewise-cash':'Piecewise-cash','greeks':'Delta/gamma','iv':'IV work-limit refusal','certified':'Certified reduction','hard':'Strict arithmetic refusal'}
lines=['# Cash interpolation: allocation qualification','',
'''Bounded private scratch and within-call numerator reuse reduce cash allocation
with unchanged complete numerical outcomes. The first timing campaign failed
six batch-latency limits. The fixed follow-up and its disposition are recorded
below; an allocation improvement alone is insufficient for adoption.

## Scope and storage argument

The [previous allocation profile](results-american-remaining-allocation.md)
and post-#148 cash profile identify interpolation as about 45% of sampled cash
allocation. The first scratch candidate saved about 8%, and explicit inlining
raised that to about 9%; both exploratory observations fell short of the frozen
10% cash target. Their raw profiles/source patches remain in the archive.
The proposed implementation also reuses the immutable `point-lower` enclosure
already computed for endpoint comparison. No target was relaxed.

The [storage derivation](runtime-enclosures.md#interpolation-owned-scratch)
covers one checked array per call, overwritten used prefixes and immutable
returned fields. General division retains its geometric correction/tail and
ordinary fresh-storage entry point. Scalar fusions retain exact-scalar word
order. Reusing the identical point/node subtraction removes duplicate work
without changing its inputs, error or failure. Explicit inlining removes boxing.
No interpolation result borrows scratch; independent calls/domains own storage.

Grid search, exact endpoint values/zero signs, strict convex-weight checks,
weighted-sum order, local error screen, mapping diagnostics, event sides,
refinement and ticks remain unchanged. This does not introduce slope-form
arithmetic, a cache, factor reuse, FFI, weakened tolerance or new financial model.
The additive primitive lives under the unstable internal enclosure interface;
public pricing signatures are unchanged.

## Frozen campaign and provenance

The [protocol](evidence/american-cash-interpolation/protocol.md) and generic
reference composition/tests were committed before runtime optimization. Baseline
pricing still uses its original inline composition; the added generic primitive
is unused by that baseline's pricing runtime. The original freeze commit
`3291da2` (full ID in the archive) and published rebased baseline have the
same complete Git tree; the bridge record and original freeze patch are retained.
''',f"Baseline: `{m['commits']['baseline']}`. Candidate: `{m['commits']['candidate']}`.",
'''The candidate is rebased onto PR #148's identical integration merge tree
`4959ab44d861a52e9db84c3d96e0dc0c701cb3e2`. Historical qualification and timing
use identical runtime/test/oracle source hashes. Evidence publication changes
no runtime source. The initial mutation attempt stopped because its numerical-only
option was treated as a fixture; no fault was scored. The corrected dispatcher
has an explicit argument-passing control and a successful fresh mutation baseline.
Both attempt logs are retained.

[Complete summary](evidence/american-cash-interpolation/results/summary.json),
[archive inventory and hashes](evidence/american-cash-interpolation/results/manifest.json),
and [raw results/source patches](evidence/american-cash-interpolation/results/raw.tar.gz).

The unchanged #148 request corpus/drivers run ten singleton cases, three
eight-row cash cases and eight European certified cases in five alternating
fresh process pairs per campaign. The first campaign has 140 processes; the
single confirmatory repeat adds 140. Twelve separate same-binary diagnostic
processes bring the total to 292. Every first-campaign observation is retained.
Eight rows mean four positions × two dated
scenarios. Fixed batching and one/four-worker planners use tile one and a no-op
sink. Compilation/admission, first output and reused execution remain separate.
Every process and method preserves complete replay. Guards cover tracked,
staged, unstaged, untracked source and executable hashes.

Both complete A/B campaigns start after task-owned builds, reference campaigns,
mutants, ordinary tests and profiles finish. Each timed operation warms up and collects first; whole-program
allocation runs (including joined workers) are separate from latency. The
European harness contributes the mean of five inner samples per process.
''',f"Host: {m['hardware']}, {m['logical_cpus']} logical CPUs, `{m['platform']}`,",
f"OCaml 5.3.0 Flambda, release `-O3`; confirmatory campaign began `{m['started_utc']}`.",
f"Recorded one-minute load spans **{min(loads):.2f}–{max(loads):.2f}**. This is a shared host, not an isolated SLA campaign.",
'''
Frozen criteria require at least 10% less singleton cash allocation and 5% less
Bermudan/piecewise-cash allocation. Other pricing methods may grow no more than
5%; all American/European price/end-to-end medians may regress no more than 10%.
Compile/admission costs are retained without fitted thresholds.

The [fixed follow-up](evidence/american-cash-interpolation/followup-protocol.md)
was specified before its collection: exactly twelve same-binary processes, one
full repeat, and gates on both that repeat and the pooled medians of every sample
from the two campaigns. No observations are removed and no thresholds change.
Same-binary three-pair medians falsely indicate substantial slowdowns: baseline
batch 1.56× and planner1 1.54×; candidate batch 1.67×, planner1 1.45× and planner4
1.78× for the second label versus the identical first binary. This demonstrates
large timing variability; it does not prove that every A/B difference is external.
The first campaign remains failed regardless of the follow-up result. A small
Python pooling-control test overlapped the separate same-binary diagnostic
(about 0.11 seconds), a deviation from that diagnostic's isolation condition.
The archive records it explicitly; the confirmatory A/B campaign began after
the control finished. Same-binary observations are not sole-cause attribution.

## Singleton scalar observations

Times are milliseconds; parentheses give observed minimum–maximum across all ten
process observations, not tail-latency guarantees. Decimal MB is cumulative managed bytes,
not live memory. Refused IV and strict requests are not successful throughput.
''',
'| Workload | Baseline ms (range) | Candidate ms (range) | Baseline MB | Candidate MB |',
'| --- | ---: | ---: | ---: | ---: |']
for name,label in labels.items():
 r=s['american'][name+'/1'];b,c=r['baseline'],r['candidate']
 lines.append(f"| {label} | {timing(b,'scalar')} | {timing(c,'scalar')} | {b['memory']['scalar']['median']/1e6:.3f} | {c['memory']['scalar']['median']/1e6:.3f} |")
lines+=['','## Eight-row planners','',
'Whole-request latency and whole-program allocation include all eight rows.',
'Amortized time per row is not singleton latency.','',
'| Workload/workers | Baseline ms (range) | Candidate ms (range) | Baseline MB | Candidate MB |',
'| --- | ---: | ---: | ---: | ---: |']
for name in ('cash','bermudan','piecewise-cash'):
 r=s['american'][name+'/4'];b,c=r['baseline'],r['candidate']
 for w in (1,4):
  method='planner'+str(w)
  lines.append(f"| {labels[name]} / {w} | {timing(b,method)} | {timing(c,method)} | {b['memory'][method]['median']/1e6:.3f} | {c['memory'][method]['median']/1e6:.3f} |")
lines+=['', 'The complete summary retains scalar/fixed/planner, first output and compilation.']
for v in ('baseline','candidate'):
 rs=[r['peak_rss_bytes']/1e6 for r in runs if r['variant']==v]
 lines.append(f"{v.capitalize()} per-child peak RSS spans {min(rs):.2f}–{max(rs):.2f} MB across the campaign.")
lines+=['''These peaks include harness/warmups/memory experiments and do not measure
simultaneous deployment-wide memory. Cumulative allocation remains material.

## European controls

Shared division plumbing requires European regression controls even though the
new interpolation primitive is not used by these models. Price-only medians of
ten process means follow; admission/end-to-end and ranges are retained in the
summary. CHECK records, including accuracy refusal, remain identical. Fast
pricing kernels are unchanged.
''',
'| Case | Baseline μs | Candidate μs | Baseline kB | Candidate kB |',
'| --- | ---: | ---: | ---: | ---: |']
for r in s['european']:
 if r['key'].endswith('/price'):
  b,c=r['baseline'],r['candidate']
  lines.append(f"| {r['key'].split('/')[0]} | {b['ns']['median']/1000:.3f} | {c['ns']['median']/1000:.3f} | {b['allocation']['median']/1000:.3f} | {c['allocation']['median']/1000:.3f} |")
lines+=['', '''## Correctness and failure evidence

- Full development/release install, format and ordinary suites pass. The existing
  determinism digest remains
  `5ee6731f4b8a5674b949840d89e87346e18c300d99d9e863cad32185bedd8199`
  over 6,069,960 bytes; no expected value changes.
- Primitive qualification retains 1,192 complete-field/endpoint/failure cases
  per precision, identical in baseline/candidate native and bytecode. Full
  digest: `474878836d491dc2d8f9d8b46b026d14`; Fast:
  `d8adb108399cce5d3b27fed7925be314`. Signed endpoints, adjacent/subnormal/extreme
  nodes, uncertain points, invalid widths, retained results and independent
  domains are included.
- An independent exact-rational affine formula checks **992 containment cases**
  over both precisions, including uncertain points, increasing/decreasing values
  and non-single-word widths. The interval image is the ordered pair of affine
  values at the original point interval's endpoints; it does not reuse the
  production finite-expansion quotient.
- All **572 historical price outcomes, 920 Greek rows and three 30-case inverse
  campaigns** retain identical full payloads and independent scores. Refusals,
  wide references and unresolved references remain explicit, never accuracy passes.
- **17 targeted mutants** are killed after a clean compiled baseline: the two
  new interpolation prefix/complement faults, scalar radius/scratch length,
  product guard, exponential prefix/tail, sum order/finiteness, grow residual,
  retained/discarded word, normal exponent, FMA underflow, and cash liquidator,
  opening side and mapping refinement. The new guard runs `--numerical-only`;
  compatibility fingerprints cannot count as its kill. No full catalog run is claimed.
- Existing collector failure controls and two new cash-target/latency controls
  pass. The optional catalog has 179 entries; default CI remains five jobs and
  seven core mutants. Timings are manual evidence, not a new CI performance gate.

## Disposition and reproduction

The adoption decision is stated at the top and reflected in the machine-readable
summary. These observations do not establish a deployed memory/latency budget
or general American certification. #119 retains unset
deployment requirements; #120 owns final integration qualification. Further
optimization should be driven by fresh profiles against explicit workloads,
not by treating these engineering thresholds as production acceptance.

Build the recorded revisions in separate worktrees, then stop other task-owned
compute before running the collector from the candidate:

```sh
opam exec --switch=morphiq-risk-ml -- dune build --profile release \\
  bench/backend_requests.exe bench/certified_scalar.exe
python3 scripts/measure_cash_interpolation.py \\
  --baseline /path/to/baseline --output /path/outside/source-trees
```

The output path must be new. Partial failures are retained. Historical qualification
and publication scripts, changed sources and all raw observations are archived;
recorded local paths require adjustment in another workspace.
''']
decision=('**Adopt on the integration branch:** the one fixed repeat and pooled ten-process gates both pass.' if adopt else '**Defer adoption:** the fixed follow-up does not clear every latency gate. The proposed runtime change remains unmerged.')
failures=('The repeat fails '+str(len(repeat['failures']))+' latency checks; pooling every A/B sample still fails '+str(len(s['failures']))+'. All allocation gates pass. Exact failures and complete samples remain in the machine-readable summary.')
if not adopt:
 failures+='\n\n| Failed pooled gate | Baseline ms | Candidate ms | Increase |\n| --- | ---: | ---: | ---: |'
 for case,method in [('cash/4','scalar'),('cash/4','planner4'),('bermudan/4','scalar'),('bermudan/4','batch')]:
  row=s['american'][case];b=row['baseline']['time'][method]['wall_s']['median'];c=row['candidate']['time'][method]['wall_s']['median']
  failures+=f'\n| {case} / {method} | {b*1000:.2f} | {c*1000:.2f} | {100*(c/b-1):.1f}% |'

lines.insert(2,decision+'\n\n'+failures+'\n')
(R/'docs/results-american-cash-interpolation.md').write_text('\n'.join(lines))
