from pathlib import Path
import subprocess, sys
root=Path('/tmp/morphiq-american-campaign')
evidence=Path('/tmp/morphiq-american-campaign-evidence')
def run(name,args):
 with (evidence/name).open('w') as log:
  p=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode: raise SystemExit(name+' failed')
run('format-final.log',['opam','exec','--switch=morphiq-risk-ml','--','dune','build','@fmt'])
run('harness-release-final.log',['opam','exec','--switch=morphiq-risk-ml','--','dune','build','--profile','release','bench/american_workloads.exe','bench/american_workloads.bc.exe','@bench/runtest'])
for mode in ('exe','bc.exe'):
 run('collector-'+mode+'.log',['python3','scripts/test_american_workloads.py','_build/default/bench/american_workloads.'+mode])
 run('scope-'+mode+'.log',['_build/default/bench/american_workloads.'+mode,'--scope-check'])
run('diff-check.log',['git','diff','--check'])
print('final harness validation passed',flush=True)
