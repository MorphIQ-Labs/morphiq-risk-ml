let total (s:Gc.stat) = 8. *. (s.minor_words +. s.major_words -. s.promoted_words)
let local () = let a,b,c=Gc.counters() in 8.*.(a+.c-.b)
let () = List.iter (fun workers ->
 let before=total(Gc.stat()) in
 let worker () = let b=local() in
   for i=1 to 1000 do ignore(Sys.opaque_identity(Array.make 1024 (float i))) done;
   local() -. b in
 let ds=Array.init workers (fun _ -> Domain.spawn worker) in
 let measured=Array.fold_left(fun n d -> n+.Domain.join d) 0. ds in
 let after=total(Gc.stat()) in
 Printf.printf "%d %.0f %.0f %.0f\n%!" workers (after-.before) measured (float(workers*1000*1025*8))) [1;2;4]
