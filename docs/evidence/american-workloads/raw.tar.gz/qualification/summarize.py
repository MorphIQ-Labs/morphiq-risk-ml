from pathlib import Path
import collections, hashlib, json, statistics as st, tarfile
ROOT=Path('/tmp/morphiq-american-campaign'); OUT=Path(__file__).resolve().parent
RUN=OUT/'campaign'; DEST=ROOT/'docs/evidence/american-workloads'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(xs):return dict(median=st.median(xs),minimum=min(xs),maximum=max(xs),n=len(xs))
def fmt(x, scale=1):return f"{x['median']*scale:.3f} ({x['minimum']*scale:.3f}–{x['maximum']*scale:.3f})"
assert json.loads((RUN/'complete.json').read_text())['processes']==245
records=[json.loads(p.read_text()) for p in sorted(RUN.glob('[0-4]-*.json'))]
assert len(records)==245
source=json.loads((RUN/'source.json').read_text())
groups=collections.defaultdict(list)
for record in records:groups[record['case'],record['size'],record['phase']].append(record)
summary={}
for (case,size,phase),rs in groups.items():
 assert len(rs)==5 and all(r['exit']==0 and not r['timed_out'] for r in rs)
 entry=dict(check=rs[0]['check'],statuses=rs[0]['rows'],rss=stats([r['peak_rss_bytes'] for r in rs]),samples={},compilation={},cancellation={})
 for method,values in rs[0]['samples'].items():
  entry['samples'][method]={k:stats([r['samples'][method][k] for r in rs]) for k in values}
 for method in rs[0]['compilation']:entry['compilation'][method]=stats([r['compilation'][method] for r in rs])
 for method in rs[0]['cancellation']:
  cs=[r['cancellation'][method] for r in rs]
  entry['cancellation'][method]={k:stats([c[k] for c in cs]) for k in ('issued_s','controller_delay_s','return_after_issue_s','rows','slots')}
  entry['cancellation'][method]['stops']=collections.Counter(c['stop'] for c in cs)
 summary[f'{case}/{size}/{phase}']=entry
(DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
case_order=['call','flat','cash','bermudan','piecewise','piecewise-cash','greeks','curve-greeks','iv','certified','hard','mixed']
load=[r['load_before'][0] for r in records]+[r['load_after'][0] for r in records]
lines=['# American workload and worker campaign', '',
'This #119 pass measures the compiled American API from #118 without changing production pricing. The frozen twelve-workload corpus checks complete scalar/fixed/planner outcomes and separates singleton latency, compilation, portfolio execution and program-wide managed allocation. Worker and tile choices apply only to these small portfolios and this host; this is not deployment acceptance or an accuracy qualification.', '',
'## Candidate and protocol', '',
f"Measured source: `{source['source_commit']}`; binary SHA-256 `{source['binary_sha256']}`. Source status: `{source['status'] or 'clean'}`. Production `lib/` is unchanged from integration `403ea7cdeddc7b263bd88bc62cc1c7558cbe884b`. Final report/evidence publication is a documentation-only bridge; the source manifest retains every tracked/untracked unignored file hash.", '',
f"Host: {source['hardware']}, {source['platform']}, {source['logical_cpus']} logical CPUs; OCaml 5.3.0 Flambda, release/O3. Recorded one-minute host load {min(load):.2f}–{max(load):.2f}. Task-owned builds/tests finished before timing; the shared host was not isolated.", '',
'[Frozen protocol](evidence/american-workloads/protocol.md), [all summaries](evidence/american-workloads/summary.json), [raw logs, process records and source snapshot](evidence/american-workloads/raw.tar.gz), [SHA-256 manifest](evidence/american-workloads/manifest.json). Five fresh processes per workload/shape/phase, 245 in total. Each time sample has one warmup and one measured execution, with an untimed full major collection between them. Method order reverses each round. Zero-duration observations are retained as below clock resolution, without inferring infinite throughput. Compilation samples average 50 repetitions. Parent `wait4` supplies each individual child’s RSS; peaks include harness qualification and the whole process, not one isolated priced row.', '',
'Four positions × two scenarios make eight portfolio rows; tiles and workers each sweep 1/2/4. Singleton has one position, one scenario and one worker. The ordinary 64×64/tolerance=1 and strict 1e-12 configurations are fixed engineering workloads, not equal-accuracy comparisons with the earlier 128-grid scalar reports. Cash, exercise dates, piecewise knots, quotes, limits and Greek targets remain fixed. Scalar input rolls are constructed separately from planner rolls.', '',
'## Outcomes and singleton cost', '',
'Every process checks complete ordered payloads against direct scalar calls before measurement. All fixed/planner configurations agree. This is compatibility evidence, not an independent numerical accuracy result. Counts below refer to portfolio quantities; delta/gamma cases request sixteen quantities across eight rows. All refusal costs stay visible.', '',
'| Workload | Accepted / failed / unavailable quantities | Outcome | Reused singleton scalar ms, median (range) |', '| --- | ---: | --- | ---: |']
for c in case_order:
 e=summary[f'{c}/4/time'];check=e['check'];statuses=sorted({s for r in e['statuses'].values() for s in r['statuses']})
 lines.append(f"| {c} | {check['accepted']} / {check['failed']} / {check['unavailable']} | {', '.join(statuses)} | {fmt(summary[f'{c}/1/time']['samples']['scalar/0/1']['wall_s'],1000)} |")
lines+=['','IV costs in this corpus are resource-limit refusals; strict price costs are arithmetic-unresolved refusals. Mixed portfolios retain their refused rows. No failed row counts as successful pricing throughput. Earlier independently qualified IV results remain in [the inverse report](results-american-iv-optimization.md); this campaign does not replace them.','','## Eight-row execution and worker/tile choice','','All values are median whole-portfolio milliseconds. “Lowest observed” selects from nine configurations and is descriptive, not a validated automatic policy. Scalar and fixed batching return arrays; planner execution includes a minimal row-counting sink and first-row clocks, with no transport or durable storage. Compilation is excluded here and retained separately in the machine-readable summary. Across workloads, per-case median compile costs are 3.18–8.94 μs for singleton fixed batches and 7.14–12.22 μs for singleton tile1 planners; eight-row costs are 20.72–66.00 μs and 17.08–34.04 μs respectively.','','| Workload | Scalar | Fixed batch | Planner tile1/worker1 | Lowest observed tile/workers | Lowest observed ms (range) | First row ms at that setting | Accepted quantities/s |','| --- | ---: | ---: | ---: | --- | ---: | ---: | ---: |']
for c in case_order:
 e=summary[f'{c}/4/time']['samples'];best=min((k for k in e if k.startswith('planner/')),key=lambda k:e[k]['wall_s']['median'])
 lines.append(f"| {c} | {e['scalar/0/1']['wall_s']['median']*1000:.3f} | {e['batch/0/1']['wall_s']['median']*1000:.3f} | {e['planner/1/1']['wall_s']['median']*1000:.3f} | {'/'.join(best.split('/')[1:])} | {fmt(e[best]['wall_s'],1000)} | {e[best]['first_row_s']['median']*1000:.3f} | {summary[f'{c}/4/time']['check']['accepted']/e[best]['wall_s']['median']:.1f} |")
lines+=['','Accepted-quantity throughput divides accepted quantities by whole execution time, including failed work; refused quantities never enter the numerator. The summary retains every tile/worker result, first-row latency, CPU time, admission-only and end-to-end scalar measurement. More workers cannot create parallelism when too few logical tiles exist; larger waves also delay delivery until the wave joins. These results do not justify changing caller-selected defaults or sharing solver factors between rows. For example, flat-put four-worker execution has a 51.4 ms median but spans 48.1–196.1 ms on this shared host. Wider timing ranges preclude a stable latency guarantee; larger target portfolios and concurrent service traffic still need their own campaign.','','## Allocation and process memory','','Whole-program `Gc.stat` snapshots bracket each complete execution after workers join. Unlike coordinator `Gc.counters`, these include workers. Independent known-size allocations and per-domain counter deltas qualify the scope for 1/2/4 joined domains in both native and bytecode builds; replacing totals with coordinator counters fails that witness. `Gc.stat` forces full collections, so memory measurements run in separate fresh processes from ordinary latency. Snapshot/runtime overhead is included; managed bytes exclude untracked native memory. Collections include the forced snapshots and are not pause durations.','','Median cumulative MB per eight-row execution (decimal MB), distinct from live workspace and peak RSS:','','| Workload | Scalar total | Planner 1/1 total | Planner 1/4 total | Planner 1/4 coordinator only | Time-process RSS MB range | Memory-process RSS MB range |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for c in case_order:
 m=summary[f'{c}/4/memory'];e=m['samples'];t=summary[f'{c}/4/time']['rss'];r=m['rss']
 vals=[e['scalar/0/1']['total_bytes']['median'],e['planner/1/1']['total_bytes']['median'],e['planner/1/4']['total_bytes']['median'],e['planner/1/4']['coordinator_bytes']['median']]
 lines.append(f"| {c} | "+' | '.join(f'{v/1e6:.3f}' for v in vals)+f" | {t['minimum']/1e6:.2f}–{t['maximum']/1e6:.2f} | {r['minimum']/1e6:.2f}–{r['maximum']/1e6:.2f} |")
lines+=['','Parallel workers redistribute allocation; coordinator-only reductions must not be described as whole-request savings. This pass does not optimize allocation or claim that cumulative allocation is an acceptable deployment budget. The residual enclosure allocation question remains in #119.','','## Cancellation','','Five separate flat-put portfolio processes request cancellation after a nominal 5 ms controller sleep. The following ranges span all five rounds. Latency starts at the controller’s actual issuance timestamp, and controller delay is reported separately. These are small-sample observations, not request percentiles or an SLA; elapsed time alone does not establish the active solver phase. The deterministic #118 callback-count test separately verifies in-solver cancellation forwarding.','','| Tile/workers | Stops | Issue ms range | Return after issue μs range | Committed rows range |','| --- | --- | ---: | ---: | ---: |']
for k,e in summary['flat/4/cancel']['cancellation'].items():
 i=e['issued_s'];r=e['return_after_issue_s'];n=e['rows']
 lines.append(f"| {k} | {dict(e['stops'])} | {i['minimum']*1000:.3f}–{i['maximum']*1000:.3f} | {r['minimum']*1e6:.1f}–{r['maximum']*1e6:.1f} | {n['minimum']}–{n['maximum']} |")
lines+=['','## Validation and remaining work','','Development and release ordinary suites, package builds and format checks pass. Native and bytecode counter/collector controls pass. Collector negative controls cover malformed/truncated/duplicate/nonfinite records, inconsistent allocation scope, changed replay, classification mismatches, cancellation prefixes, unsuccessful children, failed startup and timeout/reaping. Small controls join the existing ordinary suite; the 245-process campaign is manual. No CI job or core-mutation selection changes. Production source is unchanged, so this harness-only pass does not requalify modified numerics or require new numerical mutants.','','This completes the bounded workload and worker-accounting portion of #119. Actual policy-matrix/tridiagonal/LAPACK crossover, residual scalar allocation decisions, backend adoption/defer evidence and deployment requirements remain open. No new numerical backend or cache is selected. #120 still owns final American integration qualification.','','## Reproduction','','```sh','opam exec --switch=morphiq-risk-ml -- dune build --profile release bench/american_workloads.exe bench/american_workloads.bc.exe','python3 scripts/test_american_workloads.py _build/default/bench/american_workloads.exe','python3 scripts/test_american_workloads.py _build/default/bench/american_workloads.bc.exe','# Finish task-owned validation before the manual campaign.','python3 scripts/measure_american_workloads.py \\','  --binary _build/default/bench/american_workloads.exe \\','  --output /tmp/american-workloads-new-run','```','']
(ROOT/'docs/results-american-workloads.md').write_text('\n'.join(lines))
# Retain original-project text and logs only. No executable or third-party source payloads.
with tarfile.open(DEST/'raw.tar.gz','w:gz') as tar:
 for p in sorted(RUN.iterdir()):
  if p.is_file():tar.add(p,arcname='campaign/'+p.name,recursive=False)
 for p in sorted(OUT.iterdir()):
  if p.is_file() and p.suffix in {'.log','.ml','.py','.json'} and p.name not in {'watch_merge.py','closeout.py'}:
   tar.add(p,arcname='qualification/'+p.name,recursive=False)
 for name in ['bench/american_workloads.ml','bench/dune','scripts/measure_american_workloads.py','scripts/test_american_workloads.py','docs/evidence/american-workloads/protocol.md']:
  tar.add(ROOT/name,arcname='source/'+name,recursive=False)
manifest={str(p.relative_to(DEST)):sha(p) for p in [DEST/'raw.tar.gz',DEST/'summary.json',DEST/'protocol.md']}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('published',len(records),'processes', (DEST/'raw.tar.gz').stat().st_size,'archive bytes')
