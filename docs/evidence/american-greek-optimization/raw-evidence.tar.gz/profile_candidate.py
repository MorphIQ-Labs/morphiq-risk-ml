from pathlib import Path
import hashlib,json,subprocess,os
root=Path('/tmp/morphiq-american-greek-optimization');out=Path('/tmp/morphiq-greek-optimization-evidence');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(root/'bench/american_greeks.ml').read_text().split('let () =\n')[0]
source+='''let () =
  if Array.length Sys.argv <> 3 then failwith "expected model quantity";
  let sites = Hashtbl.create 100 in
  let alloc (a : Gc.Memprof.allocation) =
    let key = Printexc.raw_backtrace_to_string a.callstack in
    let n = Option.value ~default:0 (Hashtbl.find_opt sites key) in
    Hashtbl.replace sites key (n + a.n_samples); None in
  let profile = Gc.Memprof.start ~sampling_rate:0.0001 ~callstack_size:32
    { Gc.Memprof.null_tracker with alloc_minor=alloc; alloc_major=alloc } in
  run Sys.argv.(1) Sys.argv.(2);
  Gc.Memprof.stop (); Gc.Memprof.discard profile;
  Hashtbl.to_seq sites |> List.of_seq
  |> List.sort (fun (_,a) (_,b) -> compare b a)
  |> List.iter (fun (stack,n) -> Printf.printf "SAMPLES %d ESTIMATED_BYTES_PER_TWO_CALL_RUN %.1f\\n%s\\n" n (float n *. 8. /. 0.0001) stack)
'''
p=out/'profile-driver.ml';p.write_text(source);exe=out/'profile-candidate'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
record=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_sha256={x:sha(root/x) for x in subprocess.check_output(['git','ls-files','lib','bench','dune','dune-project','morphiq_risk_ml.opam.locked'],cwd=root,text=True).splitlines()},profile_source_sha256=sha(p),scope='Memprof allocation sampling around unchanged Greek benchmark; two price/Greek calls per run plus setup/digest; profiled timings/GC counters are not acceptance evidence',sampling_rate=.0001,stack_depth=32,compiler=subprocess.check_output(['opam','exec','--switch=morphiq-risk-ml','--','ocamlopt','-config'],text=True),static_sha256={str(q.relative_to(root)):sha(q) for q in (root/'_build/default/lib').rglob('*') if q.suffix in ('.a','.cmxa')},rows=[],complete=False)
opam=['opam','exec','--switch=morphiq-risk-ml','--'];cmd=opam+['env','OCAMLPATH='+str(root/'_build/install/default/lib'),'ocamlfind','ocamlopt','-g','-O3','-package','morphiq_risk_ml,unix','-linkpkg','-o',str(exe),str(p)]
record['compile_command']=cmd;subprocess.run(cmd,cwd=out,check=True);record['binary_sha256']=sha(exe)
def save():(out/'profile-candidate.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for model in ('constant','piecewise','cash'):
 for quantity in ('price','all'):
  dest=out/f'profile-candidate-{model}-{quantity}.txt';command=[str(exe),model,quantity]
  with dest.open('w') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
  record['rows'].append(dict(command=command,output=dest.name,sha256=sha(dest)));save();print('allocation profile',model,quantity,'complete',flush=True)
bench=root/'_build/default/bench/american_greeks.exe';record['cpu_binary_sha256']=sha(bench);record['cpu']=[]
for model in ('piecewise','cash'):
 dest=out/f'cpu-candidate-{model}.txt';command=[str(bench),'--mode',model,'all']
 with (out/f'cpu-candidate-{model}.stdout').open('w') as f:
  process=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT)
  result=subprocess.run(['/usr/bin/sample',str(process.pid),'5','1','-file',str(dest)],capture_output=True,text=True)
  code=process.wait()
  record['cpu'].append(dict(command=command,sample_returncode=result.returncode,sample_stderr=result.stderr,process_returncode=code,raw_sha256=sha(dest)));save()
  assert result.returncode==0 and code==0
assert record['profile_source_sha256']==sha(p) and record['binary_sha256']==sha(exe)
for name,h in record['source_sha256'].items():assert sha(root/name)==h
record['complete']=True;save()
