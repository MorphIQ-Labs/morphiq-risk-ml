from pathlib import Path
import hashlib,json,tarfile,gzip,io
src=Path('/tmp/morphiq-greek-optimization-evidence')
dest=Path('/tmp/morphiq-american-greek-optimization/docs/evidence/american-greek-optimization')
allowed={'.json','.log','.txt','.tsv','.stderr','.stdout','.py','.ml','.sha256'}
skip={'all-rules.txt','runtest-rules.txt'}
files=[p for p in sorted(src.rglob('*')) if p.is_file() and p.suffix in allowed and p.name not in skip and not p.name.startswith('watch-')]
# Build artifacts/executables stay local; public raw evidence carries their hashes.
rows=[dict(path=str(p.relative_to(src)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
manifest=json.dumps(dict(schema=1,files=rows),indent=2).encode()+b'\n'
archive=dest/'raw-evidence.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,data in [('MANIFEST.json',manifest)]+[(r['path'],(src/r['path']).read_bytes()) for r in rows]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
record=dict(archive=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,file_count=len(rows),uncompressed_bytes=sum(r['bytes'] for r in rows))
(dest/'archive.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive) as tar:
 for row in rows:
  assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256']
print(json.dumps(record))
