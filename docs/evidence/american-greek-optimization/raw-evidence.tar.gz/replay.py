from pathlib import Path
import hashlib,json,os,subprocess
from collections import Counter
root=Path.cwd();out=Path('/tmp/morphiq-greek-optimization-evidence');prior=Path('/tmp/morphiq-greeks-evidence');env=dict(os.environ,MORPHIQ_AMERICAN_SNAPSHOT='1')
result=dict(complete=False,price=[],greeks=[],baseline='169c4b367f9a186973768a218668e38dadfc0794',build=json.loads((out/'candidate-build.json').read_text()))
def save():(out/'compatibility.json').write_text(json.dumps(result,indent=2)+'\n')
save()
for corpus,exe,script in [('piecewise','piecewise','check_american_piecewise.py'),('bermudan','bermudan','check_bermudan.py'),('plain','american_pricing','check_american_runtime.py'),('cash','american_cash','check_american_cash.py')]:
 for mode in ('primary','loose'):
  for refined in (False,True):
   name=f"{corpus}-{mode}-{'refined' if refined else 'initial'}";dest=out/'reference-candidate'/name
   cmd=['python3',str(root/'scripts'/script),'--executable',str(out/(exe+'-candidate')),'--mode',mode,'--output',str(dest)]
   if refined:cmd+=['--refined']
   subprocess.run(cmd,env=env,check=True)
   before=prior/'reference-candidate'/name
   assert (before/'stdout.tsv').read_bytes()==(dest/'stdout.tsv').read_bytes(),name
   a=json.loads((before/'results.json').read_text());b=json.loads((dest/'results.json').read_text());assert a['rows']==b['rows'],name
   result['price'].append(dict(campaign=name,rows=len(a['rows']),complete_output_identical=True,scores_identical=True));save();print(name,'identical',flush=True)
import sys
sys.path.insert(0,str(root/'scripts'))
from check_american_greeks import classify
cases=json.loads((root/'docs/evidence/american-greeks/cases-v1.json').read_text())['rows']
refs=json.loads((root/'docs/evidence/american-greeks/canonical-v1.json').read_text())['rows']
snapshot_env=dict(os.environ,MORPHIQ_GREEK_SNAPSHOT='1')
for grid in ('initial','refined'):
 for mode in ('primary','loose'):
  name=f'{grid}-{mode}';dest=out/f'qualified-{name}'
  cmd=['python3',str(root/'scripts/check_american_greeks.py'),'--executable',str(out/'greeks_runtime-candidate'),'--mode',mode,'--output',str(dest)]
  if grid=='refined':cmd+=['--refined']
  baseline=out/f'qualified-baseline-{name}'
  baseline_cmd=cmd.copy();baseline_cmd[baseline_cmd.index('--executable')+1]=str(out/'greeks_runtime-baseline');baseline_cmd[baseline_cmd.index('--output')+1]=str(baseline)
  subprocess.run(baseline_cmd,env=snapshot_env,check=True)
  subprocess.run(cmd,env=snapshot_env,check=True)
  assert (baseline/'stdout.tsv').read_bytes()==(dest/'stdout.tsv').read_bytes(),name
  assert (baseline/'stdout.tsv.stderr').read_bytes()==(dest/'stdout.tsv.stderr').read_bytes(),name+' full field replay'
  assert len((dest/'stdout.tsv.stderr').read_text().splitlines())==46,name+' missing snapshots'
  before=prior/f'qualified-{name}'
  assert (before/'stdout.tsv').read_bytes()==(dest/'stdout.tsv').read_bytes(),name
  a=json.loads((before/'results.json').read_text());b=json.loads((dest/'results.json').read_text());assert a['rows']==b['rows'],name
  canonical=classify((dest/'stdout.tsv').read_text(),cases,refs,mode)
  assert canonical==json.loads((before/'canonical-results.json').read_text())['rows']
  (dest/'canonical-results.json').write_text(json.dumps(dict(rows=canonical,counts=dict(Counter(r['comparison'] for r in canonical))),indent=2)+'\n')
  result['greeks'].append(dict(campaign=name,rows=len(a['rows']),complete_output_identical=True,independent_counts=b['counts'],canonical_counts=dict(Counter(r['comparison'] for r in canonical))));save();print(name,'Greek outcomes identical',flush=True)
assert sum(r['rows'] for r in result['price'])==572
assert sum(r['rows'] for r in result['greeks'])==920
for item in result['build']['binaries'].values():assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
result['complete']=True;save()
