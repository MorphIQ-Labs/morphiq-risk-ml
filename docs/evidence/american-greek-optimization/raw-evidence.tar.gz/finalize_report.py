from pathlib import Path
import json
out=Path('/tmp/morphiq-greek-optimization-evidence');root=Path('/tmp/morphiq-american-greek-optimization')
g=json.loads((out/'performance-native/results.json').read_text());p=json.loads((out/'performance-prices/results.json').read_text());assert g['complete'] and p['complete']
lines=['## Controlled performance','', '''The first complete 90-process boundary-only campaign **failed** the unchanged
latency criterion: piecewise all-five fell from 8.620 to 8.259 seconds (4.2%)
and cash from 5.236 to 5.074 seconds (3.1%). Allocation fell 29.3% and 23.8%.
Its source/build manifests, complete replay and every sample remain retained.
CPU evidence motivated the residual operation-graph experiment; neither
acceptance limits nor numerical targets changed.

The final 90-process campaign passes all frozen criteria. Five alternating
fresh-process pairs per model/request use the unchanged 128/128 driver, one
warmup and one measured call, release OCaml 5.3.0 Flambda on an Apple M1 Pro
(10 CPUs), macOS 27.0 arm64. All owned builds, tests, references and profiles
finished before timing. Every complete outcome digest and base price agrees.
Values below are medians; MB means decimal cumulative allocation, not live
workspace or RSS.
''','| Workload | Request | Baseline ms | Candidate ms | Latency change | Baseline MB | Candidate MB |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for r in g['summary']:
 a=r['baseline']['metrics'];b=r['candidate']['metrics'];t=a['seconds_per_call']['median'];u=b['seconds_per_call']['median'];x=a['allocated_bytes_per_call']['median'];y=b['allocated_bytes_per_call']['median']
 lines.append(f"| {r['model']} | {r['quantity']} | {t*1000:,.1f} | {u*1000:,.1f} | {(u/t-1)*100:+.2f}% | {x/1e6:,.3f} | {y/1e6:,.3f} |")
loads=[r['load'][0] for r in g['runs']];rss=[r['resources']['peak_rss_bytes']/1e6 for r in g['runs'] if r['variant']=='candidate']
lines+=['',f'''Both varying all-five workloads exceed the required 20% allocation and 10%
latency reductions: **29.33% / 22.06%** without cash and **23.78% / 21.82%**
with cash. Every simpler control passes its 5% allocation / 10% latency
regression ceiling. Constant all-five allocation rises only 26,032 bytes
(0.016%); the fixed residual wrapper is retained per solver, not per row.
Constant requests still decline delta at the frozen conservative screen:
spatial gives 2/3 estimates and all-five 4/5, while varying workloads give all
requested estimates. These are request costs, not five certified outputs.

Shared-host one-minute load ranged {min(loads):.2f}–{max(loads):.2f}; the initial
high preflight load and subsequent decline are retained. Piecewise all-five
baseline samples range 8.760–8.811 seconds and candidate 6.785–6.879 seconds;
cash ranges 5.325–5.351 versus 4.164–4.200 seconds. All raw samples remain
available. This is engineering evidence on a shared machine, not isolated-host
or deployment-tail latency. Candidate per-process peak RSS ranges
{min(rss):.2f}–{max(rss):.2f} MB across the nine workloads, separate from cumulative
allocation. Piecewise all-five minor/major collections fall 808/46 → 574/40;
cash falls 567/66 → 437/63.

The separate standalone campaign executes 60 fresh processes after the Greek
campaign, five alternating pairs for each American/Bermudan/piecewise cash/no-cash
price. Each process warms once and measures three calls. All six pass the
predeclared 5% allocation / 10% latency regression limits:
''','| Family | Cash | Baseline ms | Candidate ms | Latency change | Allocation change |','| --- | --- | ---: | ---: | ---: | ---: |']
for r in p['summary']:
 a=r['baseline'];b=r['candidate'];t=a['seconds_per_call']['median'];u=b['seconds_per_call']['median'];x=a['allocated_bytes_per_call']['median'];y=b['allocated_bytes_per_call']['median']
 lines.append(f"| {r['family']} | {r['mode']} | {t*1000:,.1f} | {u*1000:,.1f} | {(u/t-1)*100:+.2f}% | {(y/x-1)*100:+.4f}% |")
lines+=['','''## Decision and remaining scope

Adopt bounded boundary reuse and the operation-preserving residual kernel for
this measured scalar workload. No additional dependency or approximate
transcendental is introduced; the native code is original project work under
the existing license. Kernel finite-state controls, complete replay and
compiled faults support this change over their exercised domains, not a proof
for every admitted floating-point input.

The remaining **1.169 GB / 0.865 GB** of cumulative allocation per varying
all-five request is still substantial. Vega and rho still require six perturbed
prices each. This pass does not establish an acceptable deployment budget or
finish #119. Differentiated methods need their own derivation, kink/event and
independent-reference qualification; compiled workloads, tridiagonal backend
comparisons, alternative-engine evaluation and deployment acceptance remain
separate open work. #120 owns final source-artifact/multiplatform qualification.

The [evidence index](evidence/american-greek-optimization/README.md) identifies
original profiles, failed attempts, complete snapshots, validation, manifests
and reproducible collectors. The [archive](evidence/american-greek-optimization/raw-evidence.tar.gz)
has a [SHA-256 and size record](evidence/american-greek-optimization/archive.json)
and an internal manifest checked against every payload.
''']
f=root/'docs/results-american-greek-optimization.md';s=f.read_text();s=s[:s.index('## Controlled performance')]+'\n'.join(lines);s=s.replace('Candidate allocation profiles and CPU samples are retained too;', 'Boundary-only candidate allocation profiles and CPU samples are retained too;');f.write_text(s)
summary=dict(candidate=g['builds']['candidate']['revision'],baseline=g['builds']['baseline']['revision'],greeks=g['summary'],prices=p['summary'],greek_load_range=[min(loads),max(loads)],greek_candidate_peak_rss_mb=[min(rss),max(rss)],price_load_range=[min(r['load'][0] for r in p['runs']),max(r['load'][0] for r in p['runs'])])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
