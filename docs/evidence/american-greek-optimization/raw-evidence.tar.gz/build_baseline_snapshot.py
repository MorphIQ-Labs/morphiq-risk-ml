from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/morphiq-american-greek-optimization');baseline=Path('/tmp/morphiq-american-greeks');out=Path('/tmp/morphiq-greek-optimization-evidence');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=out/'baseline_snapshot.ml';source.write_bytes((root/'test/american_greeks.ml').read_bytes());exe=out/'greeks_runtime-baseline'
command=['opam','exec','--switch=morphiq-risk-ml','--','env','OCAMLPATH='+str(baseline/'_build/install/default/lib'),'ocamlfind','ocamlopt','-g','-O3','-package','morphiq_risk_ml,unix','-linkpkg','-o',str(exe),str(source)]
libs={str(p):sha(p) for p in (baseline/'_build/default/lib').rglob('*') if p.suffix in ('.a','.cmxa')}
subprocess.run(command,check=True,cwd=out)
assert libs=={p:sha(Path(p)) for p in libs}
record=dict(runtime_build=json.loads((out/'baseline-build.json').read_text()),instrumentation_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_sha256=sha(source),command=command,static_libraries=libs,binary_sha256=sha(exe),notes='Current public test driver adds complete Marshal.No_sharing snapshots; linked baseline library has no runtime edits.')
(out/'baseline-snapshot-build.json').write_text(json.dumps(record,indent=2)+'\n')
