from pathlib import Path
p=Path('lib/early_exercise.ml');s=p.read_text()
s=s.replace('''  let boundary c x =
    let v, e = enclosed x in
    c.boundary_error <- float_max c.boundary_error e;
    if e > c.local then fail "boundary arithmetic resolution";
    nonnegative "boundary value" v
''','''  let accept_boundary c v e =
    c.boundary_error <- float_max c.boundary_error e;
    if e > c.local then fail "boundary arithmetic resolution";
    nonnegative "boundary value" v

  let boundary c x =
    let v, e = enclosed x in
    accept_boundary c v e
''')
a=s.index('  (* Cache only successful scalar boundary values, not enclosures.')
b=s.index('  (* The price request owns preparation',a)
s=s[:a]+'''  type boundary_key = int64 * int64 * int64 option * int * int64 option

  type boundary_slot = {
    values : float array;
    errors : float array option;
  }

  type boundary_cache = {
    mutable remaining : int;
    mutable boundary_bytes : int;
    mutable entries : (boundary_key * boundary_slot) list;
    keep_errors : bool;
  }

  (* Ordinary prices keep the original successful-scalar cache. A Greek request
     can retain it across volatility shifts, whose boundary inputs are fixed.
     Each reusable value retains its own arithmetic indicator: another solve's
     context must recheck its local allowance and rebuild its own maximum.
     Slab keys retain original words, not rounded intermediate time values.
     The 256-byte entry charge covers keys, option/record/array headers. *)
  let boundary_values ?top ~max_steps cache earlier later next_exercise
      time_steps =
    if
      (cache.remaining = 0 && cache.entries = [])
      || time_steps > max_steps
      || time_steps > Sys.max_floatarray_length
    then None
    else
      let key =
        ( Int64.bits_of_float earlier,
          Int64.bits_of_float later,
          Option.map Int64.bits_of_float next_exercise,
          time_steps,
          Option.map Int64.bits_of_float top )
      in
      match List.assoc_opt key cache.entries with
      | Some values -> Some values
      | None ->
          let per_step = if cache.keep_errors then 16 else 8 in
          if cache.remaining < 256
             || time_steps > (cache.remaining - 256) / per_step then None
          else
            let charge = 256 + (per_step * time_steps) in
            let values =
              { values = Array.make time_steps nan;
                errors = if cache.keep_errors then Some (Array.make time_steps nan)
                         else None }
            in
            cache.remaining <- cache.remaining - charge;
            cache.boundary_bytes <- cache.boundary_bytes + charge;
            cache.entries <- (key, values) :: cache.entries;
            Some values

  let cached_boundary c slot i =
    match slot with
    | None -> nan
    | Some slot ->
        let value = slot.values.(i) in
        if Float.is_nan value then value
        else
          match slot.errors with
          | None -> value
          | Some errors -> accept_boundary c value errors.(i)

  let store_boundary c slot i x =
    let v, e = enclosed x in
    let value = accept_boundary c v e in
    (match slot with
    | None -> ()
    | Some slot ->
        slot.values.(i) <- value;
        Option.iter (fun errors -> errors.(i) <- e) slot.errors);
    value

''' +s[b:]
s=s.replace('''        let remaining, boundaries = !boundary_cache in
        if curves <> None && remaining >= 256 && n <= (remaining - 256) / 16''','''        let remaining = boundary_cache.remaining in
        if curves <> None && remaining >= 256 && n <= (remaining - 256) / 16''')
s=s.replace('boundary_cache := (remaining - charge, boundaries)', 'boundary_cache.remaining <- remaining - charge')
s=s.replace('''              let cached =
                match zero_values with None -> nan | Some vs -> vs.(j - 1)
              in''','''              let cached = cached_boundary c zero_values (j - 1) in''')
s=s.replace('''                      boundary c (E.mul (exact p.strike) (E.exp exponent))''','''                      store_boundary c zero_values (j - 1)
                        (E.mul (exact p.strike) (E.exp exponent))''')
s=s.replace('''                      boundary c
                        (E.mul (exact p.strike)
                           (exp_product (-.p.rate)''','''                      store_boundary c zero_values (j - 1)
                        (E.mul (exact p.strike)
                           (exp_product (-.p.rate)''')
s=s.replace('''                (match zero_values with
                | None -> ()
                | Some vs -> vs.(j - 1) <- value);
                value''','''                value''')
s=s.replace('''              let cached =
                match top_values with None -> nan | Some vs -> vs.(j - 1)
              in''','''              let cached = cached_boundary c top_values (j - 1) in''')
s=s.replace('''                  boundary c
                    (E.mul
                       (exact
                          (if side = Side.Call then x.(n - 1) else p.strike))''','''                  store_boundary c top_values (j - 1)
                    (E.mul
                       (exact
                          (if side = Side.Call then x.(n - 1) else p.strike))''')
s=s.replace('''                (match top_values with
                | None -> ()
                | Some vs -> vs.(j - 1) <- value);
                value)''','''                value)''')
s=s.replace('let price_with_curves ?curves ?observe ?(cancel', 'let price_with_curves ?curves ?observe ?boundary_reuse ?(cancel')
s=s.replace('''          let boundary_cache = ref (cache_bytes, []) in''','''          let fresh () =
            { remaining = cache_bytes; boundary_bytes = 0; entries = [];
              keep_errors = Option.is_some boundary_reuse }
          in
          let boundary_cache =
            match boundary_reuse with
            | None -> fresh ()
            | Some reuse ->
                let cache =
                  match !reuse with
                  | Some cache when cache.boundary_bytes <= cache_bytes ->
                      (* The previous solve's stencil snapshots are no longer
                         retained. Only the boundary entries cross this call. *)
                      cache.remaining <- cache_bytes - cache.boundary_bytes;
                      cache
                  | _ -> fresh ()
                in
                reuse := Some cache;
                cache
          in''')
s=s.replace('''                  let remaining, boundaries = !boundary_cache in
                  boundary_cache := (remaining + used, boundaries);''','''                  boundary_cache.remaining <- boundary_cache.remaining + used;''')
a=s.index('      let run ?curves a =',s.index('  let greeks_with_curves'))
s=s[:a]+'''      (* This pool belongs to this one admitted contract, side and fixed
         configuration. shift_greek preserves stock/strike, event/exercise
         objects and horizons. Rate/yield identities and the original slab
         partition must also match: rho must never borrow vega's boundaries. *)
      let boundary_reuse =
        if List.exists (fun (r : greek_request) -> r.quantity = Vega) requests
        then Some (ref None) else None
      in
      let original = inputs admitted and original_curves = curves in
'''+s[a:]
s=s.replace('''        match price_with_curves ?curves ~observe ~cancel cfg a side with''','''        let p = inputs a in
        let same_boundary_inputs =
          Int64.bits_of_float p.rate = Int64.bits_of_float original.rate
          && Int64.bits_of_float p.dividend_yield
             = Int64.bits_of_float original.dividend_yield
          && (match curves, original_curves with
             | None, None -> true
             | Some cs, Some original ->
                 cs.rates == original.rates && cs.yields == original.yields
                 && cs.knots == original.knots
             | _ -> false)
        in
        let reuse = if same_boundary_inputs then boundary_reuse else None in
        match price_with_curves ?curves ~observe ?boundary_reuse:reuse ~cancel cfg a side with''')
assert '!boundary_cache' not in s
p.write_text(s)
