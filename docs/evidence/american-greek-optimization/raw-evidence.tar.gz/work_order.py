from pathlib import Path
import subprocess,hashlib,json,os
root=Path('/tmp/morphiq-american-greek-optimization');out=Path('/tmp/morphiq-greek-optimization-evidence');old=Path('/tmp/morphiq-american-greeks')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
src=out/'work_order.ml';src.write_bytes((root/'test/american_work_order.ml').read_bytes())
records=[]
for variant,repo in [('baseline',old),('candidate',root)]:
 for backend in ('native','byte'):
  exe=out/('work-order-'+variant+'-'+backend)
  cmd=['opam','exec','--switch=morphiq-risk-ml','--','env','OCAMLPATH='+str(repo/'_build/install/default/lib'),'CAML_LD_LIBRARY_PATH='+str(repo/'_build/install/default/lib/stublibs'),'ocamlfind']
  cmd+=['ocamlopt','-O3'] if backend=='native' else ['ocamlc']
  cmd+=['-package','morphiq_risk_ml','-linkpkg','-o',str(exe),str(src)]
  libs={str(p):sha(p) for p in (repo/'_build/default/lib').rglob('*') if p.suffix in ('.a','.cmxa','.cma','.so')}
  subprocess.run(cmd,cwd=out,check=True)
  env=dict(os.environ,CAML_LD_LIBRARY_PATH=str(repo/'_build/install/default/lib/stublibs'))
  run=subprocess.run(['opam','exec','--switch=morphiq-risk-ml','--','env','CAML_LD_LIBRARY_PATH='+str(repo/'_build/install/default/lib/stublibs'),str(exe)],env=env,capture_output=True,check=True)
  (out/('work-order-'+variant+'-'+backend+'.txt')).write_bytes(run.stdout)
  records.append(dict(variant=variant,backend=backend,command=cmd,static_libraries=libs,binary_sha256=sha(exe),output_sha256=hashlib.sha256(run.stdout).hexdigest(),rows=len(run.stdout.splitlines())))
assert len({r['output_sha256'] for r in records})==1
assert all(r['rows']==54 for r in records)
(out/'work-order.json').write_text(json.dumps(dict(complete=True,source_sha256=sha(src),runs=records),indent=2)+'\n')
print('54 complete price, callback-count and row-budget traces identical in baseline/candidate native/bytecode installed clients')
