import hashlib,json,math,os,platform,signal,statistics,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/morphiq-american-compiled'); OUT=Path(__file__).resolve().parent
BIN=ROOT/'_build/default/bench/american_compiled.exe'
MODES={'scalar':5,'batch':5,'planner-1':5,'planner-2':5,'compile-batch':100,'compile-plan':100}
CASES={'call','put','greeks','iv','certified'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():
 files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0')
 return {p:sha(ROOT/p) for p in sorted(set(files)-{''}) if (ROOT/p).is_file()}
def parse(text):
 samples={};checks=set();cancel=None
 for line in text.splitlines():
  fields=line.split('\t')
  if fields[0]=='SAMPLE':
   if len(fields)!=10:raise ValueError('sample shape')
   _,case,mode,n,wall,cpu,alloc,first,minor,major=fields
   if case not in CASES or mode not in MODES or int(n)!=MODES[mode]:raise ValueError('sample identity')
   key=case+'/'+mode
   if key in samples:raise ValueError('duplicate sample')
   vals=[float(v) for v in [wall,cpu,alloc,first]]
   if not all(math.isfinite(v) and v>=0 for v in vals) or vals[0]<=0:raise ValueError('sample numeric')
   if mode.startswith('planner-') and vals[3]<=0:raise ValueError('first output missing')
   samples[key]=dict(zip(['wall_s','cpu_s','coordinator_bytes','first_row_s'],vals),minor=int(minor),major=int(major),iterations=int(n))
  elif fields[0]=='CHECK':
   if len(fields)!=3 or fields[1] not in CASES or fields[1] in checks or fields[2]!='8 accepted; scalar/fixed/1-worker/2-worker identical':raise ValueError('check')
   checks.add(fields[1])
  elif fields[0]=='CANCEL':
   if len(fields)!=5 or cancel is not None:raise ValueError('cancel shape')
   issued,returned=map(float,fields[1:3]);rows,slots=map(int,fields[3:])
   if not all(math.isfinite(x) and x>=0 for x in [issued,returned]) or issued<.005 or not 0<=rows==slots<8:raise ValueError('cancel numeric')
   cancel=dict(issued_s=issued,controller_delay_s=issued-.005,return_after_issue_s=returned,rows=rows,slots=slots)
  else:raise ValueError('unknown output')
 if len(samples)!=30 or checks!=CASES or cancel is None:raise ValueError('incomplete evidence')
 return dict(samples=samples,cancel=cancel)
def controls(valid):
 parsed=parse(valid)
 bad=[('', 'incomplete evidence'),(valid+'junk\n','unknown output'),(valid+next(l for l in valid.splitlines() if l.startswith('SAMPLE'))+'\n','duplicate sample'),(valid.replace('0.','nan',1),None)]
 # Explicit nonfinite wall, independent of the actual values.
 lines=valid.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('SAMPLE'));f=lines[i].split('\t');f[4]='nan';lines[i]='\t'.join(f)
 bad[-1]=('\n'.join(lines)+'\n','sample numeric')
 for text,why in bad:
  try:parse(text)
  except ValueError as e:
   assert str(e)==why,(str(e),why)
  else:raise AssertionError('invalid evidence accepted')
 return dict(rejections=[why for _,why in bad],valid_samples=len(parsed['samples']))
def child(args, prefix, seconds):
 start=time.monotonic();load=os.getloadavg();timed_out=False
 with (OUT/(prefix+'.log')).open('w') as stdout,(OUT/(prefix+'.stderr')).open('w') as stderr:
  p=subprocess.Popen(args,stdout=stdout,stderr=stderr,start_new_session=True)
  while True:
   pid,status,usage=os.wait4(p.pid,os.WNOHANG)
   if pid:break
   if time.monotonic()-start>seconds:
    timed_out=True;os.killpg(p.pid,signal.SIGKILL);pid,status,usage=os.wait4(p.pid,0);break
   time.sleep(.01)
  p.returncode=os.waitstatus_to_exitcode(status)
 return dict(command=args,exit=p.returncode,timed_out=timed_out,pid=p.pid,wall_s=time.monotonic()-start,load_before=load,load_after=os.getloadavg(),peak_rss_bytes=usage.ru_maxrss,user_cpu_s=usage.ru_utime,system_cpu_s=usage.ru_stime)
def child_controls():
 import sys
 checks=[]
 try:child(['/nonexistent/american-compiled'], 'control-start', 1)
 except FileNotFoundError:checks.append('failed startup rejected')
 else:raise AssertionError('startup accepted')
 failed=child([sys.executable,'-c','raise SystemExit(7)'],'control-exit',1)
 assert failed['exit']==7 and not failed['timed_out'];checks.append('nonzero exit recorded')
 timeout=child([sys.executable,'-c','import time;time.sleep(5)'],'control-timeout',.05)
 assert timeout['timed_out'] and timeout['exit']==-signal.SIGKILL
 try:os.waitpid(timeout['pid'],os.WNOHANG)
 except ChildProcessError:checks.append('timeout killed and reaped own child')
 else:raise AssertionError('timeout child not reaped')
 return dict(checks=checks,failure=failed,timeout=timeout)
def command(args):return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def run():
 guard=source();binary=sha(BIN)
 identity=dict(collected_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),python=platform.python_version(),logical_cpus=os.cpu_count(),commit=command(['git','rev-parse','HEAD']),status=command(['git','status','--porcelain']),files=guard,binary_sha256=binary,driver_sha256=sha(Path(__file__)),platform=platform.platform(),cpu=command(['sysctl','-n','machdep.cpu.brand_string']),memory=command(['sysctl','-n','hw.memsize']),compiler=command(['opam','exec','--switch=morphiq-risk-ml','--','ocamlopt','-config']))
 (OUT/'source-manifest.json').write_text(json.dumps(identity,indent=2)+'\n')
 records=[]
 for index in range(5):
  assert source()==guard and sha(BIN)==binary,'source/build changed'
  args=[str(BIN)]+(['--reverse'] if index%2 else [])
  record=dict(index=index,**child(args,f'round-{index}',600))
  records.append(record)
  (OUT/'processes.json').write_text(json.dumps(records,indent=2)+'\n')
  if record['exit'] or record['timed_out']:raise RuntimeError('process failed; raw evidence retained')
  record.update(parse((OUT/f'round-{index}.log').read_text()))
  (OUT/'processes.json').write_text(json.dumps(records,indent=2)+'\n')
  print('round',index,'passed',round(record['wall_s'],2),'seconds',flush=True)
 assert source()==guard and sha(BIN)==binary,'source/build changed'
 summary={}
 for key in records[0]['samples']:
  summary[key]={}
  for metric in ['wall_s','cpu_s','coordinator_bytes','first_row_s']:
   values=[r['samples'][key][metric] for r in records]
   summary[key][metric]=dict(median=statistics.median(values),min=min(values),max=max(values),samples=values)
 result=dict(processes=records,summary=summary,child_controls=child_controls(),controls=controls((OUT/'round-0.log').read_text()),source_unchanged=True)
 (OUT/'timing.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':run()
