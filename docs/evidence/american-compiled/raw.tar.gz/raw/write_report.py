from pathlib import Path
import json
root=Path('/tmp/morphiq-american-compiled');out=Path(__file__).resolve().parent
j=json.loads((out/'timing.json').read_text());s=j['summary'];identity=json.loads((out/'source-manifest.json').read_text())
cases=[('call','Estimated analytical call'),('put','Estimated general put'),('greeks','Put delta + gamma bundle'),('iv','Estimated call IV'),('certified','Certified call reduction')]
def median(case,mode,metric='wall_s'):return s[case+'/'+mode][metric]['median']
def cell(case,mode):
 v=s[case+'/'+mode]['wall_s'];return f"{v['median']*1000:.3f} ({v['min']*1000:.3f}–{v['max']*1000:.3f})"
rows='\n'.join('| '+label+' | '+' | '.join(cell(case,m) for m in ['scalar','batch','planner-1','planner-2'])+' |' for case,label in cases)
compile_rows='\n'.join(f"| {label} | {median(case,'compile-batch')*1e6:.2f} | {median(case,'compile-plan')*1e6:.2f} |" for case,label in cases)
mem_rows='\n'.join(f"| {label} | {median(case,'scalar','coordinator_bytes')/1e6:.3f} | {median(case,'batch','coordinator_bytes')/1e6:.3f} | {median(case,'planner-1','coordinator_bytes')/1e6:.3f} | {median(case,'planner-2','coordinator_bytes')/1e6:.3f} |" for case,label in cases)
first_rows='\n'.join(f"| {label} | {median(case,'planner-1','first_row_s')*1000:.3f} | {median(case,'planner-2','first_row_s')*1000:.3f} |" for case,label in cases)
load=[v for p in j['processes'] for v in [p['load_before'][0],p['load_after'][0]]]
text=f'''# Compiled American requests: qualification and costs (#118)

Adopt `Batch.American` and `Planner.American` as additive typed APIs on the
American integration branch. Fixed batches reuse immutable admissions; dated
plans stream bounded ordered outcomes with explicit rolls and assurance types.
On the fixed eight-row workload, two workers improve general put/Greek execution
by about 1.9× and call IV/certification by about 1.6×. Small analytical calls gain
little, and their first output arrives later with two workers. Fixed batching
primarily adds reusable admission and a stable contract; it does not accelerate
the underlying numerical method.

## Source, scope and correctness

The [protocol](evidence/american-compiled/protocol.md) was committed as `c7b45d0`
before runtime implementation; the concrete measurement matrix was frozen in
`3b9f3f4` before timing. Runtime implementation starts at `aca2224`. Qualification
includes the row-count fix `83d6a6bb05a5a55744a7e8d027f99073778a941b`.
Measured source is `{identity['commit']}`; its subsequent change from the
qualified runtime is documentation only. Exact tracked/untracked source hashes,
compiler configuration, driver hash and binary hash are in the
[source manifest](evidence/american-compiled/raw/source-manifest.json).

The original scalar numerical implementation and native policy kernels are
byte-identical to integration `ff4517b8632d0d866022570e9c0000e16141884c`.
No price algorithm, Greek definition, IV convergence policy, certificate limit,
operator cache or arithmetic backend changes. Scalar configurations gain private
read-only introspection for exact-word identity. New public contracts are in
[the API guide](american-compiled.md); the [example](../examples/american_batch.ml)
is built and executed by the ordinary suite.

- Complete development and release ordinary suites, install/build/format and
  installed native/bytecode contract consumers pass. The ordinary determinism
  digest remains `5ee6731f4b8a5674b949840d89e87346e18c300d99d9e863cad32185bedd8199`.
- Typed scalar/batch/plan equivalence covers constant, cash, Bermudan and
  piecewise prices/Greeks, supported certified reductions and estimated IV,
  and explicit unsupported/refusal paths. Per-quantity Greek failures stay typed.
- Separate numerical/precondition controls cover terminal payoffs before/after
  cash, no duplicate after-payment debit, today's Bermudan right, no invented
  future rights, active/future curve knots, frozen inputs and ACT/365F/ACT/360
  integer-day conversion. Explicit scalar inputs are constructed independently
  of the adapter. Replay equality supplies compatibility evidence, not an
  independent accuracy proof; scalar accuracy remains covered by its owning
  contracts and the existing ordinary reference suites.
- Repeated and concurrent immutable plan use, 1/2/3-worker ordered outcomes,
  fresh arrays, foreign tiles, count/workspace/schedule/buffer bounds, callback
  exceptions, in-solve scalar cancellation, cancelled prefixes, sink refusal and
  sink exceptions pass. The common executor's existing forced spawn/domain/tile
  failure and joining controls also pass. No new compiler-enforced ownership
  guarantee is claimed.
- Three negative type witnesses reject piecewise inverse requests, estimated
  prices used as certificates, and fabrication of private solver settings.
- All nine new optional compiled mutants have a clean baseline, successful
  mutated build and a designated numerical/precondition rejection: current cash,
  current right, active knot, tolerance identity, workspace cap, buffer cap,
  cancellation forwarding, sink prefix and cash snapshot ownership. Default CI
  remains five jobs/seven core mutants; the optional catalog is 176.

Review found a real integer-accounting edge case in both American and European
planners: five zero-output positions × 10^18 scenarios could pass calculation
and tile limits while overflowing the total row count. Independent row-product
checks now reject these plans. Both regression cases fail before their respective
fixes and pass afterward. This deliberately tightens structural admission;
ordinary pricing and existing numerical digests remain unchanged.

The first full attempt also found test-harness integration problems: a European
instrumentation locator matched the new executor, and generated wrappers needed
the encoding helper through the unstable internal surface. Both are corrected.
A mutation startup copied a tracked Dune stanza before its new untracked module
was staged; a separate startup encountered a Dune lock. Neither was scored as a
kill. Initial failures, the original cash-fixture correction, wrapper repairs and
final successful logs are retained in the raw archive. The manual 572-price/
920-Greek scalar optimization replay was not rerun: this change does not modify
those scalar numerical owners; final artifact-wide qualification remains #120.

## Fixed local performance campaign

Apple M1 Pro, 16 GiB RAM, `{identity['platform']}`, OCaml 5.3.0 with Flambda,
native release/O3. All task-owned builds/tests/mutations/installed checks finished
before measurement. This is a shared host; one-minute load samples range
{min(load):.2f}–{max(load):.2f}, including decay from earlier jobs. No isolated-host
or deployment SLA claim is made.

Four positions × two scenarios (spot 100/101) produce **eight rows per execution**.
K=100, r=.05, q=0, sigma=.2, one year, no cash, full American rights. Price settings
are 64×64, two domains, tolerance 1; Greeks request delta/gamma with tolerance 10.
Call IV uses the independently fixed quote from the existing reference corpus;
quotes stay fixed under the spot shock. Certification uses absolute limit 1e-9.
The complete limits and inverse settings are frozen in the protocol. These are
not the 128×128 scalar optimization workloads, so their times are not a new
before/after scalar speedup.

Five fresh processes alternate mode and workload order. Each execution mode has
two warmups and five measured executions per process. Compilation has two warmups
and 100 measured repetitions. Each process checks full scalar/fixed/one-worker/
two-worker outcomes outside timing; every requested quantity is accepted.
The sink retains no rows and records its first arrival using the same monotonic
clock. Numbers below are median process means, with minimum–maximum process means
in parentheses. Batch time divided by eight is amortized throughput cost, not
single-request latency.

| Eight-row workload | Explicit scalar, ms | Fixed batch, ms | Planner 1 worker, ms | Planner 2 workers, ms |
| --- | ---: | ---: | ---: | ---: |
{rows}

Compilation is separate from all execution measurements:

| Workload | Fixed batch compile, μs | Dated plan compile, μs |
| --- | ---: | ---: |
{compile_rows}

Fixed compilation takes pre-admitted scalar requests; dated compilation includes
base-model admission and schedule checks. Neither includes constructing the
caller's original records/scenario description. Dated execution includes fresh
scenario admission. No compilation timing includes numerical output acceptance.

## Allocation, GC, first output and cancellation

The following are **cumulative coordinator-domain counter deltas**, MB per
complete eight-row execution. With one worker they include all numerical work;
with two they omit worker bodies. OCaml's counters may include previous domain
ownership and are not a process-wide allocation API. The apparent halving in
the last column is not evidence of lower total allocation.

| Workload | Explicit scalar | Fixed batch | Planner 1 worker | Planner 2 workers, coordinator only |
| --- | ---: | ---: | ---: | ---: |
{mem_rows}

Fixed batches add approximately 456 bytes per eight-row execution in this corpus;
serial planning adds about 9.7 KB over the explicit pre-admitted scalar loop.
General-put cumulative allocation remains about 7.14 MB per row at these settings;
this feature does not resolve the remaining scalar enclosure-allocation work.
GC counts are retained as process-wide sampled diagnostics, outside any claim
of exact instantaneous allocation. No GC tuning was introduced.

Each fresh child's own `wait4` reports whole-process peak RSS, including workers,
all workloads and warmups. The five peaks are
{', '.join(f"{p['peak_rss_bytes']/1e6:.2f}" for p in j['processes'])} MB.
They are not path-specific peaks, live workspace or simultaneous deployment
memory. Reverse-order processes have higher peaks here; long-lived concurrent
memory still needs qualification.

| Workload | First row, 1 worker, ms | First row, 2 workers, ms |
| --- | ---: | ---: |
{first_rows}

Five separate in-solve cancellation probes requested cancellation after a 5 ms
controller delay. Actual issuance occurred 5.935–6.460 ms after launch; the extra
0.935–1.460 ms is controller scheduling/startup delay. Return occurred 77–152 μs after
actual issuance, with a zero-row/zero-calculation committed prefix and explicit
`Cancelled` each time. These are observations at this request/checkpoint size,
not a worst-case responsiveness guarantee. Interrupted work is excluded from
completed-request throughput.

The collector rejects incomplete, unknown, duplicate and nonfinite output and
checks its own failed-startup, nonzero-exit and kill/reap timeout controls.
No measured process failed, no requested output was dropped, and source/binary
hashes were unchanged across the campaign. All raw process means, CPU/GC/load
records, cancellation measurements and collector controls are retained.

## Disposition and remaining work

Use the compiled API for immutable request ownership, explicit date semantics,
reusable admission and bounded ordered streaming. Two workers help these eight-row
PDE/Greek/IV/certified workloads, but this does not choose a universal worker/tile
policy. Cross-row grid/operator/factor caching has not been added. Existing
scalar-owned compatible-grid/event/operator reuse continues with its qualified
dependency checks; solved value surfaces are never shared between shocked rows.

#119 retains cash/piecewise/hard-case batch campaigns, worker/tile sweeps,
whole-worker allocation collection, residual scalar allocation and actual-matrix/
backend crossover work. #120 retains final immutable source-artifact qualification,
independent-review/acceptance scope and platform-wide closeout. General American
certification, certified aggregates, settlement and economic P&L remain outside
this API. Neither issue nor the parent epic is completed by this campaign.

[Raw evidence archive](evidence/american-compiled/raw.tar.gz),
[SHA-256 manifest](evidence/american-compiled/manifest.json), and
[structured results](evidence/american-compiled/raw/timing.json).
'''
(root/'docs/results-american-compiled.md').write_text(text)
