open Morphiq_risk
module A = Early_exercise.Bsm
module P = A.Piecewise
let get = function Ok x -> x | Error _ -> failwith "installed API refused"
let v = get (Vol.lognormal 0.2)
let p = A.{spot=100.;strike=100.;rate=0.05;dividend_yield=0.;volatility=v;time_to_expiry=1.;opens_at=0.}
let limits=A.{max_nodes=4096;max_steps=458752;max_policy_solves=3670016;max_row_visits=2800000000;max_workspace_bytes=4194304;policy_iterations=64}
let cfg=get (A.configure ~tolerance:1. ~space_cells:32 ~time_steps:32 ~domain_expansions:2 ~limits)
let requests=get (A.configure_greeks (List.map (fun (q,tolerance)->get (A.request_greek ?bump:(if q=A.Vega || q=A.Rho then Some 0x1p-10 else None) ~tolerance q)) [A.Delta,0.02;A.Gamma,0.002;A.Vega,1.;A.Rho,1.;A.Theta,0.005]))
let show name (x:A.estimated_greeks) =
  assert(List.length x.greeks=5);
  List.iter (fun (_,g)->match g with A.Greek_estimate g->Printf.printf "%s %016Lx\n" name (Int64.bits_of_float g.value) | _->failwith "installed Greek unavailable") x.greeks
let () =
  show "constant" (get (A.greeks cfg requests (get (A.admit p)) Side.Call));
  let p=P.{spot=100.;strike=100.;opens_at=1.;time_to_expiry=1.;rate=get (Rate.create ~horizon:1. ~initial:0.05 ~changes:[|(0.5,0.08)|]);dividend_yield=get (Yield.create ~horizon:1. ~initial:0. ~changes:[||]);volatility=get (Volatility.create ~horizon:1. ~initial:v ~changes:[|(0.5,get(Vol.lognormal 0.3))|])} in
  show "piecewise" (get(P.greeks cfg requests (get(P.admit p)) Side.Call))
