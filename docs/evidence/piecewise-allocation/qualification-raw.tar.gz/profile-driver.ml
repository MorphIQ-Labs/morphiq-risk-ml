open Morphiq_risk

let get = function Ok x -> x | Error _ -> failwith "profile request failed"
let calls = ref 1
let mode = ref "cash"
let phase = ref "price"
let measure = ref false

let allocated_words () =
  let minor, promoted, major = Gc.counters () in
  minor +. major -. promoted

let () =
  Arg.parse
    [
      ("--calls", Arg.Set_int calls, "Number of American price calls");
      ("--mode", Arg.Set_string mode, "none, cash");
      ("--phase", Arg.Set_string phase, "admission, price, diagnostics");
      ("--measure", Arg.Set measure, "Measure without allocation profiling");
      ( "--",
        Arg.Rest (fun _ -> raise (Arg.Bad "unexpected positional argument")),
        "End options (no positional arguments accepted)" );
      ( "--version",
        Arg.Unit
          (fun () ->
            print_endline "piecewise-allocation-profile-v1";
            exit 0),
        "Print version" );
    ]
    (fun _ -> raise (Arg.Bad "unexpected argument"))
    "Estimated American allocation sampling";
  if !calls < 1 then (
    prerr_endline "calls must be positive";
    exit 2);
  let module A = Early_exercise.Bsm in
  let module P = A.Piecewise in
  let admission () =
    let rates, yields, vols = match !mode with
      | "none" -> [|0.25,0.08;0.75,-0.03|], [|0.5,0.06|], [|0.375,0.3|]
      | "cash" -> [|0.5,-0.03|], [|0.5,0.08|], [|0.5,0.35|]
      | _ -> invalid_arg "profile mode" in
    let inputs = P.{spot=100.;strike=100.;opens_at=0.;time_to_expiry=1.;
      rate=get (Rate.create ~horizon:1. ~initial:0.05 ~changes:rates);
      dividend_yield=get (Yield.create ~horizon:1. ~initial:0.02 ~changes:yields);
      volatility=get (Volatility.create ~horizon:1. ~initial:(get (Vol.lognormal 0.2))
        ~changes:(Array.map (fun (t,v)->t,get (Vol.lognormal v)) vols))} in
    if !mode="none" then get (P.admit inputs)
    else get (P.admit_cash inputs A.{valuation_side=Regular;opening_side=Regular;
      expiry_side=Regular;dividends=[|{time=0.5;amount=5.}|]})
  in
  let admitted = admission () in
  let cfg =
    get
      (A.configure ~tolerance:1. ~space_cells:128 ~time_steps:128
         ~domain_expansions:2
         ~limits:
           {
             max_nodes = 8192;
             max_steps = 131072;
             max_policy_solves = 1048576;
             max_row_visits = 1000000000;
             max_workspace_bytes = 8388608;
             policy_iterations = 64;
           })
  in
  let operation =
    match !phase with
    | "admission" -> fun () -> ignore (Sys.opaque_identity (admission ()))
    | "price" | "diagnostics" ->
        fun () ->
          ignore
            (Sys.opaque_identity
               (get
                  (P.price ~premium:(!phase = "diagnostics")
                     ~exercise_regions:(!phase = "diagnostics") cfg admitted
                     Side.Put)))
    | _ -> invalid_arg "phase"
  in
  operation ();
  Gc.full_major ();
  let before = Gc.quick_stat () and start = Unix.gettimeofday () in
  let words_before = allocated_words () in
  for _ = 1 to !calls do
    operation ()
  done;
  let elapsed = Unix.gettimeofday () -. start and after = Gc.quick_stat () in
  let allocated = 8. *. (allocated_words () -. words_before) /. float !calls in
  if !measure then (
    Gc.full_major ();
    let live = Gc.stat () in
    Printf.printf
      "{\"mode\":%S,\"phase\":%S,\"calls\":%d,\"seconds_per_call\":%.17g,\"allocated_bytes_per_call\":%.17g,\"minor_collections\":%d,\"major_collections\":%d,\"heap_words_after\":%d,\"live_words_after\":%d}\n"
      !mode !phase !calls
      (elapsed /. float !calls)
      allocated
      (after.minor_collections - before.minor_collections)
      (after.major_collections - before.major_collections)
      live.heap_words live.live_words;
    exit 0);
  Printf.printf "UNPROFILED_BYTES_PER_CALL %.1f\n%!" allocated;
  let sites = Hashtbl.create 100 in
  let alloc (a : Gc.Memprof.allocation) =
    let key = Printexc.raw_backtrace_to_string a.callstack in
    let n = match Hashtbl.find_opt sites key with Some n -> n | None -> 0 in
    Hashtbl.replace sites key (n + a.n_samples);
    None
  in
  let profile =
    Gc.Memprof.start ~sampling_rate:0.0001 ~callstack_size:24
      { Gc.Memprof.null_tracker with alloc_minor = alloc; alloc_major = alloc }
  in
  for _ = 1 to !calls do
    operation ()
  done;
  Gc.Memprof.stop ();
  Gc.Memprof.discard profile;
  Hashtbl.to_seq sites |> List.of_seq
  |> List.sort (fun (_, a) (_, b) -> compare b a)
  |> List.iter (fun (stack, n) ->
         Printf.printf "SAMPLES %d ESTIMATED_BYTES_PER_CALL %.1f\n%s\n" n
           (float n *. 8. /. 0.0001 /. float !calls)
           stack)
