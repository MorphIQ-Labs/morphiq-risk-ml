from pathlib import Path
import json,tarfile,hashlib,re,collections
root=Path('/tmp/morphiq-piecewise-allocation-evidence');out=Path('docs/evidence/piecewise-allocation')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
performance=json.loads((root/'performance/results.json').read_text());assert performance['complete']
compatibility=[]
for before in sorted((root/'reference-baseline').glob('*/results.json')):
 name=before.parent.name;after=root/'reference-candidate'/name/'results.json'
 a=json.loads(before.read_text());b=json.loads(after.read_text());assert a['rows']==b['rows']
 assert (before.parent/'stdout.tsv').read_bytes()==(after.parent/'stdout.tsv').read_bytes()
 compatibility.append(dict(campaign=name,count=len(a['rows']),counts=a['counts'],complete_outcomes_identical=True,baseline_stdout_sha256=sha(before.parent/'stdout.tsv'),candidate_stdout_sha256=sha(after.parent/'stdout.tsv')))
assert sum(c['count'] for c in compatibility)==572
profiles={}
for kind in ('baseline','candidate'):
 profiles[kind]={}
 for mode in ('none','cash'):
  raw=(root/f'profile-{kind}-{mode}.txt').read_text();c=collections.Counter()
  # The top evaluator's enclosure exponential is distinguishable from zero,
  # stencil and cash sites by source-line ranges recorded per revision.
  for b in raw.split('SAMPLES ')[1:]:
   n=int(b.split()[0]);c['stencil' if '.prepare ' in b else 'cash_mapping' if '.interpolate ' in b else 'other']+=n
  profiles[kind][mode]=dict(c)
logs=['baseline-build.log','candidate-build.log','baseline-build.json','candidate-build.json','dev-test.log','release-test.log','mutations.log','final-checks.log','collector-controls.log','focused-controls.log','compare-baseline.log','compare-candidate.log','profile-baseline.log','profile-candidate.log','allocation-profile-baseline.json','allocation-profile-candidate.json','profile-baseline-none.txt','profile-baseline-cash.txt','profile-candidate-none.txt','profile-candidate-cash.txt','profile-driver.ml','capture.py','compare.py','profile.py','package.py']
files=[root/n for n in logs]
files.extend(root.glob('aborted-large-controls*'))
files.extend(root.glob('invalid-overlap*.*'))
files.extend(p for p in (root/'invalid-overlap-performance').rglob('*') if p.is_file())
files.extend(root.glob('cpu-profile*'))
files.extend(p for p in (root/'iteration-1').rglob('*') if p.is_file() and p.suffix in ('.txt','.log','.json','.tsv','.stdout','.stderr') and 'profile-candidate' not in p.relative_to(root/'iteration-1').parts[:-1])
for folder in ('reference-baseline','reference-candidate','performance'):
 files.extend(p for p in (root/folder).rglob('*') if p.is_file())
manifest={str(p.relative_to(root)):sha(p) for p in sorted(files)}
with tarfile.open(out/'qualification-raw.tar.gz','w:gz') as arc:
 for p in sorted(files):arc.add(p,arcname=str(p.relative_to(root)))
record=dict(schema=1,complete=True,baseline=performance['builds']['baseline'],candidate=performance['builds']['candidate'],protocol_commit='4965425',compatibility=compatibility,profile_sample_categories=profiles,checks=['development ordinary suite','release ordinary suite','package build and installed native public profiling client','format','native and bytecode piecewise controls','19 affected compiled mutants','collector failure controls'],performance=performance,raw_sha256=sha(out/'qualification-raw.tar.gz'),raw_members_sha256=manifest)
(out/'qualification.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print('packaged',len(files),'files;',sum(c['count'] for c in compatibility),'identical complete outcomes')
