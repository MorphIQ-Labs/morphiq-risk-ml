from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/morphiq-piecewise-allocation-evidence');exe=root/'profile-candidate/profile';records=[]
for mode in ('none','cash'):
 out=root/f'cpu-profile-{mode}.txt';command=[str(exe),'--mode',mode,'--calls','12','--measure']
 with (root/f'cpu-profile-{mode}.stdout').open('w') as f:
  p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT)
  c=subprocess.run(['/usr/bin/sample',str(p.pid),'5','1','-file',str(out)],capture_output=True,text=True)
  code=p.wait()
  records.append(dict(command=command,sample_returncode=c.returncode,sample_stderr=c.stderr,process_returncode=code,raw_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
(root/'cpu-profile.json').write_text(json.dumps(records,indent=2)+'\n')
