import csv,json
from fractions import Fraction as F
from pathlib import Path
out=Path(__file__).resolve().parent;root=Path('/tmp/morphiq-american-forward-opt')
price=json.loads((out/'price-compatibility.json').read_text())['rows']
for d in sorted((out/'baseline-campaigns').iterdir()):
 def lines(p):return {l.split()[0]:l for l in p.read_text().splitlines()}
 a=lines(d/'stdout.tsv');b=lines(out/'candidate-campaigns'/d.name/'stdout.tsv')
 assert a.keys()==b.keys()
 for id in a:
  if a[id]!=b[id]:assert id in ['call-expiry-before','call-expiry-after'] and d.name.startswith('cash-'),(d.name,id)
for r in price:
 if not r['unchanged']:assert r['after']['comparison']['status']=='pass'
assert len(price)==572 and sum(r['unchanged'] for r in price)==564
refs={c[0]:(F(c[11]),F(c[12]),c[13]) for line in (root/'docs/evidence/american-iv/references.tsv').read_text().splitlines() if(c:=line.split())}
def load(p):
 outcomes={};roots={}
 for line in p.read_text().splitlines():
  c=line.split()
  if c and c[0]=='ROW':outcomes[c[1]]=(c[2],c[3])
  elif c and c[0]=='ROOT':roots[c[1]]=c[2:]
 assert outcomes.keys()==refs.keys()
 return outcomes,roots
rows=[];summary=[]
for config,width in [('initial',.05),('refined',.05),('tight',.005)]:
 old,ro=load(out/f'iv-baseline-{config}.log');new,rn=load(out/f'iv-candidate-{config}.log')
 counts=dict(config=config,before_accepted=0,after_accepted=0,changed=0)
 for id in refs:
  changed=old[id]!=new[id];counts['changed']+=changed
  if changed:assert id in ['cash-terminal-american','cash-terminal-bermudan'],(config,id)
  r=dict(config=config,id=id,before=old[id][0],after=new[id][0],changed=changed)
  for kind,outcomes,roots in [('before',old,ro),('after',new,rn)]:
   if outcomes[id][0]=='interval':
    lo,hi,n=roots[id];l,h=F(float.fromhex(lo)),F(float.fromhex(hi));rl,rh,_=refs[id];assert l<=rl<=rh<=h and h-l<=F(width)
    counts[kind+'_accepted']+=1;r.update({kind+'_lower':lo,kind+'_upper':hi,kind+'_calls':n,kind+'_lower_gap':str(rl-l),kind+'_upper_gap':str(h-rh)})
  rows.append(r)
 summary.append(counts)
(out/'iv-compatibility.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2)+'\n')
print(summary)
