from pathlib import Path
import os,subprocess,time,json,statistics,hashlib
from fractions import Fraction as F
out=Path(__file__).resolve().parent;root=Path('/tmp/morphiq-american-forward-opt')
ref=next(r for r in json.loads((root/'docs/evidence/american-forward-optimization/reference-v1/references.json').read_text())['rows'] if r['id']=='piecewise-after')
records=[];identities={k:hashlib.sha256((out/f'piecewise-{k}').read_bytes()).hexdigest() for k in ['baseline','candidate']}
for pair in range(5):
 for kind in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
  exe=out/f'piecewise-{kind}';assert hashlib.sha256(exe.read_bytes()).hexdigest()==identities[kind]
  record=dict(pair=pair,kind=kind,load_before=os.getloadavg());records.append(record)
  with (out/f'piecewise-{pair}-{kind}.log').open('w') as log,(out/f'piecewise-{pair}-{kind}.stderr').open('w') as err:
   p=subprocess.Popen([str(exe)],stdout=log,stderr=err,env=dict(os.environ,OCAMLRUNPARAM='v=0x400'));pid,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
  record.update(exit=p.returncode,rss_bytes=usage.ru_maxrss);assert p.returncode==0
  lines=(out/f'piecewise-{pair}-{kind}.log').read_text().splitlines();assert len(lines)==4
  c=lines[0].split();assert c[0]=='CHECK' and len(c)==4
  v,e=F(float.fromhex(c[1])),F(float.fromhex(c[2]));lo,hi=F(ref['lower']),F(ref['upper']);bound=max(abs(v-lo),abs(v-hi));assert bound<=F(1)
  if kind=='candidate':assert bound<=e
  samples=[]
  for i,line in enumerate(lines[1:],1):
   cells=line.split();assert cells[:4]==['TIME','piecewise-terminal/price',str(i),'1'];samples.append(dict(wall_ns=float(cells[4]),cpu_ns=float(cells[5]),allocation=float(cells[6])))
  record.update(samples=samples,value=c[1],error_upper=str(bound),load_after=os.getloadavg())
  (out/'piecewise-timing.json').write_text(json.dumps(dict(identities=identities,driver_sha256=hashlib.sha256((out/'piecewise_bench.ml').read_bytes()).hexdigest(),records=records),indent=2)+'\n')
print('piecewise 5 pairs complete')
