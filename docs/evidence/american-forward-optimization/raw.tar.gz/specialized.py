import json,struct,subprocess,hashlib
from pathlib import Path
root=Path('/tmp/morphiq-american-forward-opt');out=Path(__file__).resolve().parent
f=lambda x:struct.unpack('>d',bytes.fromhex(x))[0]
cases=json.loads((root/'docs/evidence/american-references/cases-v1.json').read_text())['rows']
selected=[];excluded=[];lines=[]
for p in cases:
 v={k:f(x) for k,x in p['inputs'].items()}
 if v['time']!=1 or v['opens']!=0 or v['rate']<0 or v['yield_']<0 or v['spot']<=0 or v['strike']<=0 or v['volatility']<=0:
  excluded.append(dict(id=p['id'],reason='evaluation restricted to positive spot/strike/volatility, nonnegative rate/yield, one year, full American window'));continue
 selected.append(p)
 for kind in ['fast','accurate','high']:
  lines.append(' '.join([p['id'],kind,p['side'],*[repr(v[k]) for k in ['spot','strike','rate','yield_','volatility','time']],'10']))
(out/'specialized-input.txt').write_text('\n'.join(lines)+'\n')
(out/'specialized-scope.json').write_text(json.dumps(dict(selected=selected,excluded=excluded,criteria='Research evaluation only. Score all eligible original cases against unchanged qualified independent intervals and epsilon; unresolved stays unresolved. Compare schemes without changing production. Require a separately derived error/work contract before adoption.'),indent=2)+'\n')
with (out/'specialized-input.txt').open() as inp,(out/'specialized.log').open('w') as log:
 p=subprocess.run([str(out/'canonical')],stdin=inp,stdout=log,stderr=subprocess.PIPE,text=True,timeout=600)
(out/'specialized.stderr').write_text(p.stderr);assert p.returncode==0
print(len(selected),'selected',len(excluded),'excluded')
