import subprocess,os,json
from pathlib import Path
root=Path('/tmp/morphiq-american-forward-opt');out=Path(__file__).resolve().parent
records=[]
for corpus,exe,script in [('piecewise','american_piecewise','check_american_piecewise.py'),('bermudan','bermudan','check_bermudan.py'),('plain','american_pricing','check_american_runtime.py'),('cash','american_cash','check_american_cash.py')]:
 for mode in ['primary','loose']:
  for refined in [False,True]:
   name=f'{corpus}-{mode}-'+('refined' if refined else 'initial');dest=out/'candidate-campaigns'/name
   cmd=['python3',str(root/'scripts'/script),'--executable',str(root/'_build/default/test'/(exe+'.exe')),'--mode',mode,'--output',str(dest)]+(['--refined'] if refined else [])
   with (out/'candidate-replay.log').open('a') as f:r=subprocess.run(cmd,env={**os.environ,'MORPHIQ_AMERICAN_SNAPSHOT':'1'},stdout=f,stderr=subprocess.STDOUT,timeout=1200)
   records.append(dict(name=name,exit=r.returncode));(out/'candidate-replay.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0
   print(name,'complete',flush=True)
