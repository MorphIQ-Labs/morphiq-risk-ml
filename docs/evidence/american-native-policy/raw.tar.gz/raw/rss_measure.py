from pathlib import Path
import os,json,subprocess,time,signal
out=Path(__file__).resolve().parent
records=[]
configs=[('mixed','all','all'),('reverse','all','all'),('forced','all','all'),('isolated','price','american-put'),('isolated','solve','american-put'),('isolated','price','cash-terminal-american'),('isolated','solve','cash-terminal-american'),('repeat','price','american-put'),('repeat','solve','american-put')]
for pair in range(3):
 for mode,operation,case in configs:
  for version in (['pre143','post143'] if pair%2==0 else ['post143','pre143']):
   name=f'{pair}-{version}-{mode}-{operation}-{case}'
   cmd=[str(out/('rss-'+version)),'/tmp/morphiq-american-forward-opt/docs/evidence/american-iv/references.tsv',mode,operation,case]
   with (out/('rss-'+name+'.log')).open('w') as f,(out/('rss-'+name+'.stderr')).open('w') as e:
    p=subprocess.Popen(cmd,stdout=f,stderr=e);deadline=time.monotonic()+300
    while True:
     pid,status,usage=os.wait4(p.pid,os.WNOHANG)
     if pid:break
     if time.monotonic()>deadline:
      p.kill();os.wait4(p.pid,0);raise TimeoutError(name)
     time.sleep(.1)
    p.returncode=os.waitstatus_to_exitcode(status)
   assert p.returncode==0,name
   gc=[]
   for line in (out/('rss-'+name+'.log')).read_text().splitlines():
    c=line.split()
    if c[0]=='GC':
     assert len(c)==11
     gc.append(dict(zip(['label','minor_words','promoted_words','major_words','minor_collections','major_collections','heap_words','live_words','free_words','top_heap_words'],[c[1],*map(int,c[2:])])))
   assert gc[-1]['label']=='final'
   records.append(dict(pair=pair,version=version,mode=mode,operation=operation,case=case,peak_rss_bytes=usage.ru_maxrss,gc=gc))
   (out/'rss.json').write_text(json.dumps(records,indent=2)+'\n')
   print(name,usage.ru_maxrss,flush=True)
