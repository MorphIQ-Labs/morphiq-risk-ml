from pathlib import Path
import os,subprocess,time,signal,json,hashlib,statistics,platform
out=Path(__file__).resolve().parent
roots={'baseline':Path('/tmp/morphiq-american-forward-opt'),'candidate':Path('/tmp/morphiq-american-native-policy')}
def identity(r):
 assert subprocess.check_output(['git','status','--porcelain'],cwd=r)==b''
 return dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),binary_sha256=hashlib.sha256((r/'_build/default/bench/american_allocation.exe').read_bytes()).hexdigest(),driver_sha256=hashlib.sha256((r/'bench/american_allocation.ml').read_bytes()).hexdigest())
ids={k:identity(r) for k,r in roots.items()};assert ids['baseline']['driver_sha256']==ids['candidate']['driver_sha256']
report=dict(identities=ids,platform=platform.platform(),records=[])
for pair in range(5):
 for mode in ['none','zero','cash','multiple']:
  for variant in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   root=roots[variant];assert identity(root)==ids[variant]
   stem=f'cash-{pair}-{mode}-{variant}'
   cmd=[str(root/'_build/default/bench/american_allocation.exe'),'--measure','--calls','3','--mode',mode,'--phase','price']
   load=os.getloadavg()
   with (out/(stem+'.log')).open('w') as f,(out/(stem+'.stderr')).open('w') as e:
    p=subprocess.Popen(cmd,stdout=f,stderr=e);deadline=time.monotonic()+180
    while True:
     pid,status,usage=os.wait4(p.pid,os.WNOHANG)
     if pid:break
     if time.monotonic()>deadline:p.kill();os.wait4(p.pid,0);raise TimeoutError(stem)
     time.sleep(.05)
    p.returncode=os.waitstatus_to_exitcode(status)
   assert p.returncode==0
   record=json.loads((out/(stem+'.log')).read_text())
   assert record['mode']==mode and record['phase']=='price' and record['calls']==3
   assert record['seconds_per_call']>0 and record['allocated_bytes_per_call']>0
   record.update(pair=pair,variant=variant,load_before=load,load_after=os.getloadavg(),peak_rss_bytes=usage.ru_maxrss,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime)
   report['records'].append(record)
   (out/'cash-timing.json').write_text(json.dumps(report,indent=2)+'\n')
   assert identity(root)==ids[variant]
   print(stem,flush=True)
report['summary']={}
criteria=[]
for mode in ['none','zero','cash','multiple']:
 report['summary'][mode]={}
 for field in ['seconds_per_call','allocated_bytes_per_call']:
  means={v:statistics.median(r[field] for r in report['records'] if r['variant']==v and r['mode']==mode) for v in roots}
  ratio=means['candidate']/means['baseline'];maximum=.8 if field=='seconds_per_call' else 1.05
  report['summary'][mode][field]=dict(**means,ratio=ratio)
  criteria.append(dict(mode=mode,metric=field,ratio=ratio,maximum=maximum,passed=ratio<=maximum))
report['criteria']=criteria
(out/'cash-timing.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(c['passed'] for c in criteria),criteria
print('Cash criteria pass',flush=True)
