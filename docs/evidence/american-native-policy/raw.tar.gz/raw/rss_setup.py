from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent
s=Path('/tmp/morphiq-american-forward-opt/bench/american_iv.ml').read_text()
s=s.replace('external monotonic : unit -> float = "morphiq_bench_monotonic"','''let mode = Sys.argv.(2)
let operation = Sys.argv.(3)
let snapshot label =
 let s = Gc.quick_stat () in
 Printf.printf "GC %s %.0f %.0f %.0f %d %d %d %d %d %d\\n%!" label
 s.minor_words s.promoted_words s.major_words s.minor_collections
 s.major_collections s.heap_words s.live_words s.free_words s.top_heap_words
let collected label = Gc.full_major (); snapshot label''')
a=s.index('let sample name');b=s.index('\nlet run fields',a)
s=s[:a]+'''let sample name n f =
 let suffix = List.hd (List.rev (String.split_on_char '/' name)) in
 if operation = "all" || operation = suffix then (
 snapshot (name ^ "/start");
 ignore (Sys.opaque_identity (f ()));
 for round = 1 to (if mode = "repeat" then 20 else 3) do
  collected (name ^ "/before-" ^ string_of_int round);
  for _ = 1 to n do ignore (Sys.opaque_identity (f ())) done;
  snapshot (name ^ "/after-" ^ string_of_int round)
 done;
 if mode = "forced" || mode = "repeat" then collected (name ^ "/final"))
''' + s[b:]
s=s.replace('let result = solve () in\n      if full () <> result then failwith "full solve mismatch";\n      Printf.printf "CHECK %s %h %h %d\\n%!" id\n        (Vol.to_float result.lower.volatility)\n        (Vol.to_float result.upper.volatility)\n        result.evaluations;', '''if operation = "all" then (
      let result = solve () in
      if full () <> result then failwith "full solve mismatch";
      Printf.printf "CHECK %s %h %h %d\\n%!" id
        (Vol.to_float result.lower.volatility)
        (Vol.to_float result.upper.volatility) result.evaluations);''')
a=s.index('\nlet () =');s=s[:a]+'''
let () =
 let c = open_in Sys.argv.(1) in
 let rows = ref [] in
 (try while true do
  let fields = String.split_on_char ' ' (input_line c) in
  if List.mem (List.hd fields) ["call-100-0.05-american";"american-put";"cash-terminal-american"] then rows := fields :: !rows
 done with End_of_file -> close_in c);
 let rows = if mode = "reverse" then !rows else List.rev !rows in
 snapshot "startup";
 List.iter (fun fields -> if Sys.argv.(4) = "all" || List.hd fields = Sys.argv.(4) then run fields) rows;
 collected "final"
'''
(out/'rss_client.ml').write_text(s)
records=[]
for name,root in [('pre143',Path('/tmp/morphiq-american-forward-baseline')),('post143',Path('/tmp/morphiq-american-forward-opt'))]:
 cmd=['opam','exec','--switch=morphiq-risk-ml','--','env','OCAMLPATH='+str(root/'_build/install/default/lib'),'ocamlfind','ocamlopt','-O3','-package','morphiq_risk_ml','-linkpkg','-o',str(out/('rss-'+name)),str(out/'rss_client.ml')]
 p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
 records.append(dict(name=name,source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary_sha256=hashlib.sha256((out/('rss-'+name)).read_bytes()).hexdigest(),command=cmd))
(out/'rss-build.json').write_text(json.dumps(dict(driver_sha256=hashlib.sha256(s.encode()).hexdigest(),builds=records),indent=2)+'\n')
