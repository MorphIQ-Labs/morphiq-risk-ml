from pathlib import Path
p=Path('/tmp/morphiq-american-forward-evidence');o=Path('/tmp/morphiq-american-native-evidence')
for name in ['validate.py','replay_candidate.py','qualify_installed.py','qualify_iv_installed.py']:
 s=(p/name).read_text().replace('/tmp/morphiq-american-forward-opt','/tmp/morphiq-american-native-policy')
 if name=='validate.py':s=s.replace("'bench/american_iv.exe',", "'bench/american_iv.exe','bench/american_allocation.exe',")
 (o/name).write_text(s)
s=(p/'qualify_campaigns.py').read_text().replace('/tmp/morphiq-american-forward-opt','/tmp/morphiq-american-native-policy')
s=s.replace("for kind in ['baseline','candidate']:","for kind in ['candidate']:")
s=s.replace("a=out/f'greeks-baseline-{name}'", "a=Path('/tmp/morphiq-american-forward-evidence')/f'greeks-candidate-{name}'")
s=s.replace("print('iv',name,'qualified',flush=True)","assert (out/f'iv-candidate-{name}.log').read_bytes()==(Path('/tmp/morphiq-american-forward-evidence')/f'iv-candidate-{name}.log').read_bytes(),name\n print('iv',name,'identical',flush=True)")
s += '''\nrows=0
for d in sorted((out/'candidate-campaigns').iterdir()):
 old=Path('/tmp/morphiq-american-forward-evidence/candidate-campaigns')/d.name
 for f in ['stdout.tsv','stdout.tsv.stderr']:
  if (old/f).exists(): assert (old/f).read_bytes()==(d/f).read_bytes(),(d.name,f)
 rows+=len((d/'stdout.tsv').read_text().splitlines())
(out/'price-replay.json').write_text(json.dumps(dict(rows=rows,identical=True))+'\\n')
print('price rows identical',rows,flush=True)
'''
(o/'qualify_campaigns.py').write_text(s)
s=Path('/tmp/morphiq-greek-optimization-evidence/work_order.py').read_text().replace('/tmp/morphiq-american-greek-optimization','/tmp/morphiq-american-native-policy').replace('/tmp/morphiq-greek-optimization-evidence','/tmp/morphiq-american-native-evidence').replace('/tmp/morphiq-american-greeks','/tmp/morphiq-american-forward-opt');(o/'work_order.py').write_text(s)
