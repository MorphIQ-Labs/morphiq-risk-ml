from pathlib import Path
import json,subprocess,os,time
root=Path('/tmp/morphiq-american-native-policy');out=Path(__file__).resolve().parent
start=time.monotonic()
while not (out/'release-build.json').exists():
 assert time.monotonic()-start<3600
 if (out/'development.json').exists():assert json.loads((out/'development.json').read_text())['exit']==0
 time.sleep(2)
assert json.loads((out/'release-build.json').read_text())['exit']==0
subprocess.run(['python3',str(out/'replay_candidate.py')],check=True)
records=[]
for mode in ['primary','loose']:
 for refined in [False,True]:
  name=f'{mode}-'+('refined' if refined else 'initial')
  for kind in ['candidate']:
   dest=out/f'greeks-{kind}-{name}';exe=out/'baseline/test-american_greeks.exe' if kind=='baseline' else root/'_build/default/test/american_greeks.exe'
   cmd=['python3',str(root/'scripts/check_american_greeks.py'),'--executable',str(exe),'--mode',mode,'--output',str(dest)]+(['--refined'] if refined else [])
   with (out/'greeks-replay.log').open('a') as log:
    p=subprocess.run(cmd,env=dict(os.environ,MORPHIQ_GREEK_SNAPSHOT='1'),stdout=log,stderr=subprocess.STDOUT,timeout=1800)
   assert p.returncode==0,(kind,name)
  a=Path('/tmp/morphiq-american-forward-evidence')/f'greeks-candidate-{name}';b=out/f'greeks-candidate-{name}'
  for file in ['stdout.tsv','stdout.tsv.stderr']:
   assert (a/file).read_bytes()==(b/file).read_bytes(),(name,file)
  rows=json.loads((b/'results.json').read_text())['rows'];records.append(dict(name=name,rows=len(rows),full_payload_identical=True));(out/'greeks-replay.json').write_text(json.dumps(records,indent=2)+'\n');print('greeks',name,'identical',flush=True)
for name,width,expansions in [('initial','.05','2'),('refined','.05','3'),('tight','.005','3')]:
 for kind in ['candidate']:
  exe=out/'baseline/test-american_iv.exe' if kind=='baseline' else root/'_build/default/test/american_iv.exe'
  with (out/f'iv-{kind}-{name}.log').open('w') as log:
   p=subprocess.run([str(exe),str(root/'docs/evidence/american-iv/references.tsv'),'all',width,expansions],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  assert p.returncode==0,(kind,name)
 assert (out/f'iv-candidate-{name}.log').read_bytes()==(Path('/tmp/morphiq-american-forward-evidence')/f'iv-candidate-{name}.log').read_bytes(),name
 print('iv',name,'identical',flush=True)
(out/'campaigns-complete.json').write_text(json.dumps(dict(complete=True))+'\n')

rows=0
for d in sorted((out/'candidate-campaigns').iterdir()):
 old=Path('/tmp/morphiq-american-forward-evidence/candidate-campaigns')/d.name
 for f in ['stdout.tsv','stdout.tsv.stderr']:
  if (old/f).exists(): assert (old/f).read_bytes()==(d/f).read_bytes(),(d.name,f)
 rows+=len((d/'stdout.tsv').read_text().splitlines())
(out/'price-replay.json').write_text(json.dumps(dict(rows=rows,identical=True))+'\n')
print('price rows identical',rows,flush=True)
