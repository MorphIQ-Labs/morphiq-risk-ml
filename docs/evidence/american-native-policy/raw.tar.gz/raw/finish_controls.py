from pathlib import Path
r=Path('/tmp/morphiq-american-native-policy')
p=r/'test/american_policy.ml';s=p.read_text();anchor='let () =\n  check (bands 3);'
add='''let independent_controls () =
  (* (1+2^-27)(1-2^-27)-1 = -2^-54 exactly. A fused
     policy decision distinguishes it from a rounded product, which is zero. *)
  let a = bands 5 and f = [| Array.make 5 false; Array.make 5 false |] in
  a.(0).(2) <- 0.; a.(1).(2) <- 0.;
  a.(2).(2) <- 1. +. 0x1p-27; a.(4).(3) <- 1. -. 0x1p-27;
  a.(3).(2) <- 1.; a.(4).(2) <- 0.; a.(5).(2) <- 0x1p-55;
  let state = [|0;1;0;17;0|] in
  expect "fused exact sign" (raw a f state 2 2 = 0 && not f.(0).(2));
  a.(0).(2) <- 1. +. 0x1p-27; a.(6).(1) <- 1.;
  a.(2).(1) <- 1. -. 0x1p-27; a.(6).(2) <- 1.;
  state.(0) <- 1;
  expect "separately rounded exact pivot" (raw a f state 2 2 = 0 && a.(6).(2) = 0.);
  (* Independent system with an identity obstacle row: solution (1,10,3).
     Its neighbours must retain coupling to that row, while the identity row
     has neither a lower nor an upper coefficient. *)
  let a = bands 5 and f = [|Array.make 5 false; Array.make 5 false|] in
  f.(0).(2) <- true;
  a.(6).(2) <- 1.;
  a.(7).(1) <- -0.5; a.(7).(2) <- 10.; a.(7).(3) <- 3.5;
  let k = wrapper a f in
  expect "mixed identity elimination" (K.run k K.Eliminate ~first:2 ~last:3 = 0);
  expect "mixed identity substitution" (K.run k K.Substitute ~first:3 ~last:1 = 0);
  List.iteri (fun i x -> expect "independent identity solution" (a.(8).(i+1) = x)) [1.;10.;3.];
  List.iter (fun (phase, band, row, x, code) ->
    let a = bands 5 and f = [|Array.make 5 false; Array.make 5 false|] in
    a.(band).(row) <- x;
    let state = [|phase;0;0;17;0|] in
    let first = if phase = 1 then 2 else 3 in
    expect "explicit failure outcome" (raw a f state first first = code);
    expect "failure consumes one row" (state.(4) = 1))
    [1,6,1,0.,2; 2,6,3,0.,5; 1,7,2,infinity,4]

let () =
  independent_controls ();
  check (bands 3);'''
assert anchor in s;s=s.replace(anchor,add);p.write_text(s)
p=r/'scripts/mutation/mutation.ml';s=p.read_text();s=s.replace('c.visits <- c.visits + visited;";\n      killer = "american_work_order";', 'c.visits <- c.cfg.limits.max_row_visits + visited;";\n      killer = "american_pricing";');p.write_text(s)
p=r/'docs/american-solver-design.md';s=p.read_text();a=s.index('Any future FFI uses');b=s.index('A vendor library cannot silently weaken these rules.',a)+len('A vendor library cannot silently weaken these rules.');s=s[:a]+'''Bounded internal C kernels may borrow rooted OCaml float arrays while holding
 the runtime lock, provided they never allocate, call back, retain pointers or
change the floating-point environment. The policy and residual owners validate
shapes and writable aliases before arithmetic. Calls visit at most 256 rows and
end before the next cancellation or work-budget boundary. OCaml owns outer
iteration, failures and accounting; each mutable workspace has one owner.

A vendor or blocking FFI instead uses stable C-layout float64 Bigarrays or copies
to owned native storage. Never retain a movable-array pointer across allocation
or runtime-lock release. Root storage for the whole call, check lengths/strides
and LP64 versus ILP64 integers, prohibit writable aliasing, and return no borrowed
scratch views. Include packing and residual costs in timing. A blocking LAPACK
call is cancellable only before/after that bounded call; if that fails the
latency budget, restrict N or keep the existing path.

The [arithmetic contract](numerical-backend-contract.md) still applies: nearest
even, gradual underflow, no implicit contraction/reassociation or fast math.
Internal policy kernels preserve the explicit FMA and separate product boundaries;
ordinary OCaml arithmetic continues using its existing multiplication owner.
A vendor backend must inspect/restore the thread's floating-point environment
on every exit and reject unsupported environments. Native/bytecode execution,
concurrent calls, malformed buffers and environment preservation require
executable witnesses. A vendor library cannot silently weaken these rules.''' +s[b:];s=s.replace('\n the runtime','\nthe runtime');p.write_text(s)
