open Morphiq_risk
module A = Early_exercise.Bsm
module I = A.Implied_volatility

let mode = Sys.argv.(2)
let operation = Sys.argv.(3)
let snapshot label =
 let s = Gc.quick_stat () in
 Printf.printf "GC %s %.0f %.0f %.0f %d %d %d %d %d %d\n%!" label
 s.minor_words s.promoted_words s.major_words s.minor_collections
 s.major_collections s.heap_words s.live_words s.free_words s.top_heap_words
let collected label = Gc.full_major (); snapshot label

let get = function Ok x -> x | Error _ -> failwith "benchmark refusal"
let vol x = get (Vol.lognormal x)

let pricing parts =
  get
    (A.configure ~tolerance:1. ~space_cells:128 ~time_steps:128
       ~domain_expansions:3
       ~limits:
         A.
           {
             max_nodes = 8192;
             max_steps = parts * 131072;
             max_policy_solves = parts * 1048576;
             max_row_visits = parts * 1000000000;
             max_workspace_bytes = 8388608;
             policy_iterations = 64;
           })

let words () =
  let a, b, c = Gc.counters () in
  a +. c -. b

let sample name n f =
 let suffix = List.hd (List.rev (String.split_on_char '/' name)) in
 if operation = "all" || operation = suffix then (
 snapshot (name ^ "/start");
 ignore (Sys.opaque_identity (f ()));
 for round = 1 to (if mode = "repeat" then 20 else 3) do
  collected (name ^ "/before-" ^ string_of_int round);
  for _ = 1 to n do ignore (Sys.opaque_identity (f ())) done;
  snapshot (name ^ "/after-" ^ string_of_int round)
 done;
 if mode = "forced" || mode = "repeat" then collected (name ^ "/final"))

let run fields =
  match fields with
  | [ id; _; side; s; k; r; q; t; opens; cash; quote; _; _; _ ] ->
      let f = float_of_string in
      let p =
        A.
          {
            spot = f s;
            strike = f k;
            rate = f r;
            dividend_yield = f q;
            time_to_expiry = f t;
            opens_at = f opens;
            volatility = vol 0.2;
          }
      in
      let admit () =
        get
          (if f cash = 0. then A.admit p
           else
             A.admit_cash p
               A.
                 {
                   valuation_side = Regular;
                   opening_side = After_cash;
                   expiry_side = After_cash;
                   dividends =
                     [| { time = p.time_to_expiry; amount = f cash } |];
                 })
      in
      let side = if side = "call" then Side.Call else Side.Put in
      let settings =
        get
          (I.configure ~pricing:(pricing 64) ~lower:(vol 0.05) ~upper:(vol 0.6)
             ~width:0.005 ~max_evaluations:64)
      in
      let admitted = admit () and quote_value = f quote in
      let quote = get (I.quote quote_value) in
      let solve () = get (I.solve settings admitted side quote) in
      let full () =
        get (I.solve settings (admit ()) side (get (I.quote quote_value)))
      in
      let pc = pricing 1 in
      let price () = get (A.price pc admitted side) in
      if operation = "all" then (
      let result = solve () in
      if full () <> result then failwith "full solve mismatch";
      Printf.printf "CHECK %s %h %h %d\n%!" id
        (Vol.to_float result.lower.volatility)
        (Vol.to_float result.upper.volatility) result.evaluations);
      let n = if id = "call-100-0.05-american" then 20 else 1 in
      sample (id ^ "/price") n price;
      sample (id ^ "/solve") n solve;
      sample (id ^ "/end-to-end") n full
  | _ -> failwith "fixture shape"

let () =
 let c = open_in Sys.argv.(1) in
 let rows = ref [] in
 (try while true do
  let fields = String.split_on_char ' ' (input_line c) in
  if List.mem (List.hd fields) ["call-100-0.05-american";"american-put";"cash-terminal-american"] then rows := fields :: !rows
 done with End_of_file -> close_in c);
 let rows = if mode = "reverse" then !rows else List.rev !rows in
 snapshot "startup";
 List.iter (fun fields -> if Sys.argv.(4) = "all" || List.hd fields = Sys.argv.(4) then run fields) rows;
 collected "final"
