from pathlib import Path
import subprocess,json,hashlib,sys
root=Path(sys.argv[1]);reports=[]
manifest=json.loads((root/'prepared.json').read_text())
for i in [0,1]:
 build=root/str(i);prefix=build/'installed';out=build/'bytecode';out.mkdir()
 for name in ['driver.ml','clock.c']:(out/name).write_bytes((build/name).read_bytes())
 cmd=['opam','exec','--switch=morphiq-risk-ml','--','env','OCAMLPATH='+str(prefix/'lib'),'CAML_LD_LIBRARY_PATH='+str(prefix/'lib/stublibs'),'ocamlfind','ocamlc','-custom','-package','morphiq_risk_ml,unix','-linkpkg','-o','runner','clock.c','driver.ml']
 with (out/'build.log').open('w') as log:subprocess.run(cmd,cwd=out,stdout=log,stderr=log,check=True)
 with (out/'trace.txt').open('w') as trace:subprocess.run([str(out/'runner'),'--trace'],stdout=trace,check=True)
 reports.append(dict(source=manifest['sources'][i],binary_sha256=hashlib.sha256((out/'runner').read_bytes()).hexdigest(),trace_sha256=hashlib.sha256((out/'trace.txt').read_bytes()).hexdigest(),command=cmd,scope='Installed public bytecode consumer with custom clock/runtime; dynamic root-stub loading separately covered by ordinary bytecode tests'))
assert (root/'0/bytecode/trace.txt').read_bytes()==(root/'1/bytecode/trace.txt').read_bytes()
(root/'bytecode-report.json').write_text(json.dumps(reports,indent=2)+'\n')
print('Installed bytecode: all 49,152 ordered benchmark outcomes match')
