Large homogeneous Bachelier scenario tiles currently pay scalar pricing cost for every shocked row. Route eligible ARM64 single-worker tiles through the compiled native Fast batch owner, with invocation-private preparation capped at 256 rows. Preserve original indices, admission/refusal priority, logical tiles, cancellation and sink boundaries. Mixed models, small tiles, unsupported targets and multiworker execution retain scalar evaluation; direct `evaluate_tile` also enables batching.

Third stage into `feature/fast-simd-integration`, following merged #122 and #123. Refs #8; deployment acceptance and automatic parallel native adoption remain open. Main is unchanged by this PR.

The numerical selector, scalar operation graph, served words and accuracy budgets are unchanged. A cheap model-owned routing hint cannot authorize native evaluation. No SLEEF dependency, certification change, version or release.

Validation:

- Full local development/release ordinary suites and build/format pass; six affected mutations detect their designated faults after clean baseline/builds. Default CI remains seven core mutants; optional catalog now 100.
- Native/bytecode planner controls cover chunk boundaries, original-input scalar outcomes, failures, cancellation, sink prefixes, concurrent reuse and fresh direct-tile arrays. Both installed consumer modes replay all 49,152 benchmark outcomes exactly.
- Independent 100/200-digit original-input references retain all 36,864 Bachelier rows, zero unresolved. Existing 8-ULP/4.3-epsilon gates pass; all 24,576 selected native rows match scalar words.
- Eight alternating fresh processes retain all 3,600 final samples. Eligible 4,096-position/four-scenario serial execution improves 24–27%, with about 9% less allocation. At tile 256: 3.438 → 2.506 ms reused execution; 9.508 → 8.610 ms compile-plus-execute. Mixed serial time is essentially unchanged; fallback-heavy time rises 1.0–2.4% and allocation 1.9–2.5%.

Multiworker native trials regressed inconsistently, so automatic adoption is serial-only. Final scalar parallel controls still fluctuate substantially on the shared M1 Pro (load 24–46); no parallel speedup or deployment SLA is claimed. All superseded and slower campaigns remain in `docs/evidence/native-planner/`, with exact source/toolchain/binary identities. See `docs/results-native-planner.md` for scope, spread, first-output costs and reproduction.
